/**
 * Board.java
 * 
 * Class that take care of board in the future
 * 
 * Created by Natthawat Tungruethaipak, 18 March 2020
 */
public class Board
{
	/**
	 * This method return name of image
	 * 
	 * @return Image name
	 */
	public String getBoardImage()
	{
		return "ScrabbleBoard.jpg";
	}
}
