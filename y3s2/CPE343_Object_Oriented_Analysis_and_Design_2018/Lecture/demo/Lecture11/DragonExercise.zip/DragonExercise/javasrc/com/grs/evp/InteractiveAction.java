/**
 *  InteractiveAction.java
 *   
 *     Created by S.Goldin
 *
 *    $Id: InteractiveAction.java,v 1.1 2004/03/09 10:20:08 rudahl Exp $
 *
 *    $Log: InteractiveAction.java,v $
 *    Revision 1.1  2004/03/09 10:20:08  rudahl
 *    Add graphing for interactively selected points
 *
 *
 */
package com.grs.evp;

import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.io.File;

public class InteractiveAction extends AbstractAction
{
    private EVP parentFrame = null;
    private JFileChooser chooser = new JFileChooser();

    /**
     * Create a menu item/action to turn interactive graphing
     * on and off.
     * @param parentFrame  Reference to the EVP on whose menu this resides
     */
    public InteractiveAction(EVP parentFrame)
        {
	super("Interactive Graphing");
	this.parentFrame = parentFrame;
	chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
        }

    public void actionPerformed(ActionEvent event)
	{
	String filename = null;
	if (parentFrame.isInteractiveGraph())
	    {
	    if (chooser.showSaveDialog(parentFrame) == JFileChooser.APPROVE_OPTION)
		{
		File file = chooser.getSelectedFile();
	        filename = file.getAbsolutePath();
		}
	    parentFrame.finishInteractiveGraph(filename);
	    }
	else
	    {
	    parentFrame.startInteractiveGraph();
	    }
	}
}

