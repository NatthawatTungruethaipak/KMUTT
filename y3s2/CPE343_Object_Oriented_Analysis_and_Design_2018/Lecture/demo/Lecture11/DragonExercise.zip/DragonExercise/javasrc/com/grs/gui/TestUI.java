package com.grs.gui;
import com.grs.dragon.common.*;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.io.*;

/**
 *  TestUI 
 * 
 *   This is a very simple subclass of JFrame to let us display
 *   the UI created by XmlToUiBuilder.java without using too much
 *   Dragon-specific code.
 *  
 *   Created by Sally Goldin 11 Nov 2017 for CPE 372 Exercise 
 */
public class TestUI extends JFrame implements ActionListener, WindowListener
{

    /**
     * Hashtable with all the UI components by ID
     */
    protected Hashtable masterTable = null;

      /**
       * Minimum size allowed for panel.
       */
    protected Dimension minSize = new Dimension(680, 600); 

      /** 
       * Desired dimensions of response panels.
       */
    protected Dimension rpSize = new Dimension(680, 380);

      /**
       * Area of the UI where response panels will show up.
       */
    protected JPanel rpArea = null;

     /**
       * Top part of the UI.
       */
    protected JPanel topPanel = null;
   
      /**
       * Inner panel with cardlayout so we can first show the
       * dummy rpArea then the real one.
       */
    protected JPanel switchPanel = null;

      /** 
       * Used to keep empty panel the same size.
       */
    protected DragonPanel emptyPanel = null;
    protected Dimension emptyPanelSize = null;

      /**
       * Panel ID of currently displayed panel.
       */
    protected String currentPanelID = null;

      /**
       * Dummy field that can be used by menu items to execute
       * callbacks. Initialized by the constructor.*/
    protected DFixedText dummyField = null;

    /**
     * Constructor sets the reference to the master table
     */
    public TestUI(String title, Hashtable master)
    {
       super(title);
       masterTable = master;
       topPanel = new JPanel(new BorderLayout()); 
       rpArea = new JPanel(new BorderLayout());
       rpArea.setPreferredSize(rpSize);
       topPanel.add(rpArea, BorderLayout.CENTER);
       getContentPane().add(topPanel,BorderLayout.NORTH);
       addWindowListener(this);
       dummyField = new DFixedText("dummy","dummy");
       dummyField.setParentComponent(this);

    }

    /**
     * Method from ActionListener interface.
     * Just show the panel if any associated with a menu item.
     */
    public void actionPerformed(ActionEvent e)
    {
        Object source = e.getSource();
	if (source instanceof JMenuItem)
	{
            String rpId = null;
            Callback callback = null;
	    DragonPanel panel = null;
	    String label = null;
	    String command = null;
            if (source instanceof DragonMenuItem)
	    {
  	        DragonMenuItem menuItem = (DragonMenuItem) source;
		rpId = menuItem.getInvokedPanelId();
		callback = menuItem.getCallback();
                label = menuItem.getName();
		command = menuItem.getCommandString();
		if (callback != null)
	        {
		    // communicate the name of the menu item via the
		    // dummy field. This is a bit of a hack.
		    dummyField.setLabelText(label);
		    callback.executeCallback(dummyField);
		}
		else if (rpId != null)
		{
		    panel = (DragonPanel) masterTable.get(rpId);
		    if (panel == null)
		    {
			System.out.println(
                         "ERROR: menu item references non-existent panel " + rpId);
			return;
		    }
		    panel.setPanelCommand(menuItem.getCommandString());
		    showPanel(panel);
		    currentPanelID = rpId;
		    //pack();
		    }
		else if (command != null)
		{
			/* Don't do anything */
		}
	    }
	}
    }

    /**
     * Factorization of the actionPerformed method, allows
     * us to display a panel under program control
     */
    protected void showPanel(DragonPanel panel)
    {
        Dimension panelSize;
	panelSize = panel.getPreferredSize();
	if (panelSize.height > 800)
	{
	    System.out.println("Error - panel is too big! Ignoring");
	    return;
	}
	rpSize.height = panelSize.height + 10;
	rpArea.setPreferredSize(rpSize);
	if (currentPanelID != null)
	{
	    Object current = masterTable.get(currentPanelID);
	    if ((current !=null) && (current instanceof DragonPanel))
	    {
		rpArea.remove((DragonPanel) current);
		rpArea.revalidate();
		rpArea.repaint();
	    }
	}
	rpArea.add(panel,BorderLayout.CENTER);
	pack();
    }
    

      /**
       * Traverses the entire menu
       * and associates the current class instance as action
       * listener for each menu item. This method is called
       * recursively.
       * @param element Top level menu bar for application.
       *                or current submenu.
       */
    public void setActionListener(MenuElement element)
        {
	if (element instanceof DragonMenuItem)
	    {
	    // we know that everything that implements DragonMenuItem
	    // is in fact a JMenuItem subclass.
	    JMenuItem item = (JMenuItem) element;
	    item.addActionListener(this);
	    return;
	    }
	MenuElement[] subElems = element.getSubElements();
	if (subElems != null) 
	    {
	    for (int i = 0; i < subElems.length; i++)
	         {
		 setActionListener(subElems[i]);
		 }
	    }
	return;
	}

    /* Window listener methods */
    public void  windowActivated(WindowEvent e) {};
    public void  windowClosed(WindowEvent e) 
        {
        System.exit(0);
        }
    public void  windowClosing(WindowEvent e) {System.exit(0);}
    public void  windowDeactivated(WindowEvent e) {}
    public void  windowDeiconified(WindowEvent e) {}
    public void  windowIconified(WindowEvent e) {}
    public void  windowOpened(WindowEvent e) {}

}