/* DbTaskRecord is an object which represents a record from the
 * tasks table.
 *
 * $Id: DbTaskRecord.java,v 1.2 2002/10/26 23:35:02 rudahl Exp $
 * $Log: DbTaskRecord.java,v $
 * Revision 1.2  2002/10/26 23:35:02  rudahl
 * clientdaemon almost done
 *
 * Revision 1.1  2002/10/16 23:04:04  rudahl
 * initial depost from closet-java1.4.1
 *
 */

package com.grs.nugget;

import java.sql.*;
import java.util.*;
import java.text.*;
import com.grs.dbi.*;

public class DbTaskRecord extends DbRecord
    {
    protected static int s_iLatestId; /* remember tID of most recent INSERT */

    public DbField tID = new DbField("tID","","Task", DbField.DBV_INT,"");
    public DbField tState 
	= new DbField("tState","","State",DbField.DBV_STRING,
		      "'r', 	-- ready to execute"
		      +" 'x',	-- executing (really, has been accepted)"
		      +" 's',	-- completed successfully"
		      +" 'e',	-- completed failed"
		      +" 'b',	-- blocked by prerequisite(s)"
		      +" 'd',	-- deferred start"
		      +" 'k'	-- zapped by taskKill");

	//	    -- The following columns, which define the task, 
	//	    -- are set by taskAdd and never change:
    public DbField tCommand 
	= new DbField("tCommand","","Command", DbField.DBV_STRING,
		      "the task to be executed");
    public DbField tSourceArg 
	= new DbField("tSourceArg","","SourceArg",DbField.DBV_STRING,
		      "optional input source");
    public DbField tDestArg 
	= new DbField("tDestArg","","DestArg",DbField.DBV_STRING,
		      "optional result destination");
    public DbField tErrorArg 
	= new DbField("tErrorArg","","ErrorArg",DbField.DBV_STRING,
		      "optional, where to put stderr");
    public DbField tTimeArg 
	= new DbField("tTimeArg","","Start At", DbField.DBV_TIMESTAMP,
		      "when task should begin, or NULL");
    public DbField tCreator 
	= new DbField("tCreator","","Creator",DbField.DBV_STRING,
		      "node which created task");
    public DbField tPreferredHost 
	= new DbField("tPreferredHost","","PrefHost",DbField.DBV_STRING,
		      "empty or name of a node or *");
    public DbField tCapabilities 
	= new DbField("tCapabilities","","Capabilities",DbField.DBV_STRING,
		      "special capabilities reqd");
		      // following init by taskAdd or server
		      // may change over time.
    public DbField tNewDate 
	= new DbField("tNewDate","","Created At", DbField.DBV_TIMESTAMP,
		      "when task was added. Never changes");
    public DbField tPriority 
	= new DbField("tPriority","","Priority", DbField.DBV_INT,
		      "integer value from 0 to 10");
    public DbField tDeadline 
	= new DbField("tDeadline","","Deadline", DbField.DBV_TIMESTAMP,
		      "when task must be completed");
    public DbField tLatePriority 
	= new DbField("tLatePriority","","Late Priority", DbField.DBV_INT,
		      "same vals as 'tPriority'");
    public DbField tMaxStartTime 
	= new DbField("tMaxStartTime","","Max Time Before Start",
		      DbField.DBV_INT,"seconds b4 first taskAccept");
    public DbField tMaxTime 
	= new DbField("tMaxtime","","Max Time", DbField.DBV_INT,
		      "max seconds a node is permitted after some node has "
		      +"executed taskAccept for the task");
    public DbField tNode 
	= new DbField("tNode","","Executing Node",DbField.DBV_STRING,
		      "name of node which is executing");
    public DbField tStart 
	= new DbField("tStart","","Processing Started At",
		      DbField.DBV_TIMESTAMP,"when node executed taskAcept");
    public DbField tEnd 
	= new DbField("tEnd","","Finished At",DbField.DBV_TIMESTAMP,
		      "when node executed taskRelease"
		      +" or when 'tMaxTime' was exceeded.");
    public DbField tCompletionCode 
	= new DbField("tCompletionCode","", "Completion Code", DbField.DBV_INT,
		      "set by taskRelease or other means:"
		      +" < 0 task error return"
		      +" 0   not yet accepted by any node. Initial value."
		      +" +1  task success"
		      +" +2  'tMaxTime' exceeded"
		      +" +3  'tDeadline' exceeded"
		      +" +4  some 'tPrerequisite' failed"
		      +" +10 to +100  node rejected task");
    public DbField tLog 
	= new DbField("tLog","","Log",DbField.DBV_STRING,
		      "URL where task log can be found.");
    public DbField tError 
	= new DbField("tError","","Error",DbField.DBV_STRING,
		      "URL where task errors can be found or error string.");

	/** This constructor, combined with init(ResultSet),
	 *   is used for reading from the DB
	 */
    public DbTaskRecord() throws DbiException  { super(); init(); } 

    public void init(ResultSet result) throws SQLException, DbiException
	{
	super.init(result);
	}

	/** This constructor is used for creating a record to INSERT
	 *  into the DB. It does not have a TaskID because that will
	 *  be generated automatically (and in fact, INSERT will complain
	 *  if this record has a TaskID > 0)
	 *  '**' => required arg.
	 */
    public DbTaskRecord(String sState,     	// tState 'r' or 'd' or 'b'
			String sCommand,	// the task to be executed
			String sSourceArg,	// optional input source
			String sDestArg, 	// optional result destination
			String sErrorArg, 	// optional where to put stderr
			Timestamp tTimeArg,	// time to begin, or null
			String sCreator,	// ** node which created task
			String sPreferredHost,	// '' or node or *
			String sCapabilities,	// special capabilities reqd
			int iPriority,		// ** integer val from 0 to 10
			Timestamp tDeadline,	// date when task must be done
			int iLatePriority,	// same vals as 'tPriority'
			int iMaxStartTime,	// seconds b4 first taskAccept
			int iMaxTime)	 	// max secs a node is permitted
		throws DbiException
	{
	init();
	if ((sCreator == null) || (iPriority < 0))
	    throw new DbiException("Unable to create INSERT record; missing args");
	tID.setIntValue(0); // flag that this ctor has been called
	this.tState.setStringValue(sState);
	this.tCommand.setStringValue(sCommand);
	this.tSourceArg.setStringValue(sSourceArg);
	this.tDestArg.setStringValue(sDestArg);
	this.tErrorArg.setStringValue(sErrorArg);
	this.tTimeArg.setTimeValue(tTimeArg);
	this.tCreator.setStringValue(sCreator);
	this.tPreferredHost.setStringValue(sPreferredHost);
	this.tCapabilities.setStringValue(sCapabilities);
	this.tPriority.setIntValue(iPriority);
	this.tDeadline.setTimeValue(tDeadline);
	this.tLatePriority.setIntValue(iLatePriority);
	this.tMaxStartTime.setIntValue(iMaxStartTime);
	this.tMaxTime.setIntValue(iMaxTime);
	}

	/** This constructor is used for creating a record to UPDATE
	 *  the DB. It MUST have a TaskID (and, UPDATE will complain
	 *  if this record doesn't have a TaskID)
	 */
    public DbTaskRecord(int iID,	// task to update
			String sState,	// null or new state
			int iPriority,	// -1 or new priority
			String sNode,	// null or node starting to process
			// Timestamp tStart, is sNode, sset tStart to now
			Timestamp tEnd,	// null or ending time
			int iCompletionCode, // 0 (ignored) or some pos or neg 
			String sLog,	// null or Log info
			String sError)	// null or Error info
		throws DbiException
	{
        init();
	tID.setIntValue(iID);
	if (sState != null)
	    tState.setStringValue(sState);
	if (iPriority >= 0)
	    tPriority.setIntValue(iPriority);
	if (sNode != null)
	    {
	    tNode.setStringValue(sNode);
	    if (sNode != "")
		tStart.setTimeValue(new java.util.Date().getTime());
	    }
	if (tEnd != null)
	    this.tEnd.setTimeValue(tEnd);
	if (iCompletionCode != 0)
	    tCompletionCode.setIntValue(iCompletionCode);
	if (sLog != null)
	    tLog.setStringValue(sLog);
	if (sError != null)
	    tError.setStringValue(sError);
	}

    public static Integer getLatestIntKey() { return new Integer(s_iLatestId);}

	/** Return a string which is the first part of an SQL query
	 *  appropriate to this class and associated DB table(s)
	 */ 
    public static String getQueryString() { return "SELECT * FROM tasks "; }

	/** Return a string which is the first part of an SQL query
	 *  appropriate to this class and associated DB table(s)
	 */ 
    public static String getDeleteString() { return "DELETE FROM tasks "; }

	/** Return a string which is the INSERT command for this record
	 *  and this class and associated DB table(s)
	 * Note that many fields may not be set, or are set automatically
	 * in processing this fn:
	 *     tID		NO: automatic by DB
	 *     tState		YES: initial state = 'r' or 'd'
	 *     tCommand 	YES: the task to be executed
	 *     tSourceArg 	YES: optional input source
	 *     tDestArg 	YES: optional result destination
	 *     tErrorArg 	YES: optional, where to put stderr
	 *     tTimeArg 	YES: time when task should begin, or NULL
	 *     tCreator 	YES: node which created task
	 *     tPreferredHost 	YES: empty or name of a node or *
	 *     tCapabilities 	YES: special capabilities reqd
	 *     tNewDate 	NO: automatic by this fn. to now()
	 *     tPriority 	YES: integer value from 0 to 10
	 *     tDeadline 	YES: date when task must be completed
	 *     tLatePriority 	YES: same vals as 'tPriority'
	 *     tMaxStartTime 	YES: seconds b4 first taskAccept
	 *     tMaxTime 	YES: max seconds a node is permitted
	 *     tNode 		NO: init to empty
	 *     tStart	 	NO: init to empty
	 *     tEnd  		NO: init to empty
	 *     tCompletionCode  NO: init to 0
	 *     tLog  		NO: init to empty
	 *     tError  		NO: init to empty
	 */ 
    public String getInsertString(AccessDb access) 
	throws DbiException, SQLException, ClassNotFoundException,
	       NoSuchMethodException

	{
	if (tID.getIntValue() != 0)
	    {
	    dump("Insert DbTaskRecord");
	    throw new DbiException("Invalid record to insert; "
				   +"has incorrect tID");
	    }
	s_iLatestId = 1+access.querySingleIntVal("select * from param;",
					       "latestTaskId");
	access.execute("UPDATE param SET latestTaskId="+s_iLatestId+";");
	System.out.println("retrieved "+s_iLatestId+" from latestTaskId");
	java.util.Date nowD = new java.util.Date();
	Timestamp now = new Timestamp(nowD.getTime());
	String retval = "INSERT INTO tasks(\n"
	    +"tID,tCommand,tState,tSourceArg,tDestArg,"
	    +"tErrorArg,tTimeArg,tCreator,tPreferredHost,"
	    +"\n   tCapabilities,tNewDate,tPriority,tDeadline,"
	    +"tLatePriority,tMaxStartTime,tMaxTime,"
	    +"\n   tNode,tCompletionCode,tLog,tError"
	    +")\n VALUES \n   ("+s_iLatestId+","
	    +"'"+tCommand.getValue()+"','r','"
	    +tSourceArg.getValue()
	    +"','"+tDestArg.getValue()
	    +"','"+tErrorArg.getValue()+"','"+tTimeArg.getValue()
	    +"','"+tCreator.getValue()+"','"+tPreferredHost.getValue()
	    +"',\n   '"+tCapabilities.getValue()+"','"+now+"',"
	    +tPriority.getIntValue()
	    +",'"+tDeadline.getValue()+"',"+tLatePriority.getIntValue()
	    +","+tMaxStartTime.getIntValue()+","+tMaxTime.getIntValue()
	    +",\n   '',0,'','');";

	return retval;
	}

	/** Return a string which is the UPDATE command for this record
	 *  and this class and associated DB table(s)
	 * Note the only fields which can be set are those which
	 * can be initialized via the UPDATE constructor
	 */
    public String getUpdateString() throws DbiException
	{
	if (tID.getIntValue() <= 0)
	    {
	    dump("Update DbTaskRecord");
	    throw new DbiException("Invalid record to update; "
				   +"missing valid tID");
	    }
	String sets = "";
	if (tState.getStrValue() != null)
	    sets += " tState = '"+tState.getStrValue()+"'," ;
	if (tPriority.getIntValue() > 0)
	    sets += " tPriority = "+tPriority.getIntValue()+",";
	if (tNode.getStrValue() != null)
	    sets += " tNode = '"+tNode.getStrValue()+"'," ;
	if (tStart.getTimeValue().getTime() > 0)
	    sets += " tStart = '"+tStart.getTimeValue()+"',";
	if (tEnd.getTimeValue().getTime() > 0)
	    sets += " tEnd = '"+tEnd.getTimeValue()+"',";
	if (tCompletionCode.getIntValue() != 0)
	    sets += " tCompletionCode = "+tCompletionCode.getIntValue()+",";
	if (tLog.getStrValue() != null)
	    sets += " tLog = '"+tLog.getStrValue()+"'," ;
	if (tError.getStrValue() != null)
	    sets += " tError = '"+tError.getStrValue()+"'," ;
	String retval = (sets.length() == 0) ? ""
	    : "UPDATE tasks set "+sets.substring(0,sets.length()-1)
	       + "\n  WHERE tID = "+tID.getIntValue()+";";

	return retval;
	}

    public void dump(String czTitle)
	{
	System.out.println("Dump of DbTaskRecord "+czTitle);
	System.out.println(toString());
	}
    }
