/****************************************************************
 *
 *          viewButtonPanel.java - java-based button panel for viewport
 *			 K.T. Rudahl
 *
 *          Copyright 2001 by Sally Goldin & Kurt Rudahl
 ****************************************************************
 *
 *   $Id: viewButtonPanel.java,v 1.54 2010/12/25 04:55:14 goldin Exp $
 *   $Log: viewButtonPanel.java,v $
 *   Revision 1.54  2010/12/25 04:55:14  goldin
 *   Don't show 5263M string in CUR, show =M instead
 *
 *   Revision 1.53  2008/09/27 03:50:09  goldin
 *   Adjust sizes of components
 *
 *   Revision 1.52  2008/09/06 11:43:07  goldin
 *   Trying to improve MEA panel sizing
 *
 *   Revision 1.51  2008/08/26 12:41:43  goldin
 *   Fix problem with F7 in MEA
 *
 *   Revision 1.50  2008/08/16 07:35:54  goldin
 *   Put buttons to the left of the text area for MEA and CUR
 *
 *   Revision 1.49  2008/08/16 06:29:36  goldin
 *   Working to pass arrow key events from button panel to Vp
 *
 *   Revision 1.48  2008/08/14 10:32:41  goldin
 *   add logging for key presses
 *
 *   Revision 1.47  2008/06/06 05:41:30  goldin
 *   Add position to create fn for legend, add size getters
 *
 *   Revision 1.46  2008/06/02 04:56:16  goldin
 *   Add keyboard accelerators directly to button panel buttons
 *
 *   Revision 1.45  2008/06/01 07:35:38  goldin
 *   Refresh the button panel and bring to the top whenever it changes
 *
 *   Revision 1.44  2008/05/03 10:04:19  goldin
 *   try to improve CUR and CLU table displays
 *
 *   Revision 1.43  2008/04/26 10:17:19  goldin
 *   change key for MEA F9
 *
 *   Revision 1.42  2008/03/16 12:09:57  goldin
 *   Make display area for CUR bigger
 *
 *   Revision 1.41  2008/03/16 08:03:23  goldin
 *   Remove F11
 *
 *   Revision 1.40  2008/03/01 12:28:17  goldin
 *   Further work on the Legend and Wedge
 *
*   Revision 1.39  2008/02/22 10:49:46  goldin
 *   Working on MEA
 *
 *   Revision 1.38  2008/02/22 09:17:39  goldin
 *   Add two more potential buttons
 *
 *   Revision 1.37  2008/02/17 11:44:47  goldin
 *   revisions
 *
 *   Revision 1.36  2008/02/17 08:33:43  goldin
 *   Allow up to 12 buttons on button panel - fix error
 *
 *   Revision 1.35  2008/02/17 08:03:26  goldin
 *   Allow up to 12 buttons on button panel
 *
 *   Revision 1.34  2008/01/04 08:09:30  goldin
 *   Working on CUR table resizing
 *
 *   Revision 1.33  2007/10/21 08:33:08  goldin
 *   Make help boxes respond to key presses
 *
 *   Revision 1.32  2007/10/20 12:05:10  goldin
 *   Create new function positionButtonPanel
 *
 *   Revision 1.31  2007/10/17 11:17:44  goldin
 *   Add Help Button to CUR
 *
 *   Revision 1.30  2007/01/07 11:34:05  goldin
 *   Change handling of CUR to display data window report
 *
 *   Revision 1.29  2007/01/07 05:29:43  goldin
 *   Changes for CUR
 *
 *   Revision 1.28  2005/12/30 10:33:34  goldin
 *   Make button panel text area shorter
 *
 *   Revision 1.27  2005/02/06 09:17:30  goldin
 *   Fix javadoc warnings
 *
 *   Revision 1.26  2002/07/25 22:35:00  goldin
 *   make sure that headings change in CUR
 *
 *   Revision 1.25  2002/05/16 00:29:18  goldin
 *   put MEA/CUR buttons on bottom
 *
 *   Revision 1.24  2002/05/03 15:14:49  goldin
 *   Optimize to improve speed
 *
 *   Revision 1.23  2002/03/08 03:14:50  rudahl
 *   added some keys to keyevent list
 *
 *   Revision 1.22  2002/02/08 20:25:04  rudahl
 *   improved CUR buttonpanel sizing and table
 *
 *   Revision 1.21  2001/11/28 17:08:30  rudahl
 *   added processing of Fn-key presses
 *
 *   Revision 1.20  2001/11/16 16:37:47  goldin
 *   Begin moving UI code to other packages as relevant
 *
 *   Revision 1.19  2001/11/15 20:46:40  rudahl
 *   moved viewport java files to their own package
 *
 *   Revision 1.18  2001/11/09 19:03:23  rudahl
 *   MEA text area and button sizing
 *
 *   Revision 1.17  2001/11/08 21:59:54  rudahl
 *    improvements in infoviewport
 *
 *   Revision 1.16  2001/11/07 18:48:51  rudahl
 *   add support for changing button labels, for MEA
 *
 *   Revision 1.15  2001/11/05 20:28:49  rudahl
 *   adapt to dragon.ui package *.java
 *
 *   Revision 1.14  2001/10/12 20:30:26  rudahl
 *   fixed numerous problems from dragsched.lst
 *
 *   Revision 1.13  2001/10/08 15:12:05  rudahl
 *   fixup U CUR table
 *
 *   Revision 1.12  2001/10/06 11:47:04  rudahl
 *   button id error
 *
 *   Revision 1.11  2001/10/01 15:41:04  rudahl
 *   refining the panels
 *
 *   Revision 1.10  2001/09/28 13:20:20  rudahl
 *   change to permit C++ to grab Java windows
 *
 *   Revision 1.9  2001/09/26 15:40:20  rudahl
 *   continued refinement of P&R, esp. for C/TRA
 *
 *   Revision 1.8  2001/09/25 20:57:39  rudahl
 *   further improvements to Jni Dialogs
 *
 *   Revision 1.7  2001/09/24 18:11:05  rudahl
 *   added JniDialog as base class, and improved or added its subclasses
 *
 *   Revision 1.6  2001/09/19 14:44:58  rudahl
 *   improved - but not yet final - dialogs
 *
 *   Revision 1.5  2001/09/17 15:51:43  rudahl
 *   checkpoint before making Java objects persistent within session
 *
 *   Revision 1.4  2001/09/14 14:06:15  rudahl
 *   improved (but not final) Java P&R
 *
 *   Revision 1.3  2001/09/11 16:01:30  rudahl
 *   improvements in buttonPanel implementation & use
 *
 *   Revision 1.2  2001/09/10 19:45:01  rudahl
 *   further improvements to ButtonPanel
 *
 ****************************************************************
 * history   
 */
package com.grs.dragon.viewport;

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;
import javax.swing.border.*;
import com.grs.util.*; /* Packerlayout */
import com.grs.gui.*;

public class viewButtonPanel extends JniDialog implements ActionListener,
							  KeyListener
    {
    protected static final int functionKeys[] = 
    {KeyEvent.VK_F1,KeyEvent.VK_F2,KeyEvent.VK_F3,KeyEvent.VK_F4,
     KeyEvent.VK_F5,KeyEvent.VK_F6,KeyEvent.VK_F7,KeyEvent.VK_F8,
     KeyEvent.VK_F9,KeyEvent.VK_F10,KeyEvent.VK_F11};

    protected javax.swing.Timer paintTimer = null;
    
    public void actionPerformed(ActionEvent e)
        {
	viewProg.logViewport("Key "+e.getActionCommand()+" pressed");
	viewProg.SendViewportEvent(e.getActionCommand());
	}

      /** construct a button panel containing all buttons and labels 
       *  All 12 buttons plus a text area are created.
       *  @param viewMsgs  source of keyed I18N'd messages
       *  @param czTitle   title line or key
       */
    public viewButtonPanel(I18NTextSource viewMsgs,String czTitle)
        {
	super(viewMsgs,czTitle);
	textDisplayArea = null;
	czTableContents = "</table>";
	czTableHeader = "";
	viewProg.logViewport("viewButtonPanel ctor");
	setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        // the JniDialog class sets a window listener, but we don't
        // want the user to be able to close the button panel!
        WindowListener listeners[] = getWindowListeners();
        for (int i = 0; i < listeners.length; i++)
            removeWindowListener(listeners[i]);

	//	addWindowListener(new ViewportWindowMonitor());
	Container cp = getContentPane();
	//Font font = new Font("LucidaSans",Font.PLAIN,12);
	//setFont(font);
	//cp.setLayout(new PackerLayout());
	//cp.setLayout(new FlowLayout());
	cp.setLayout(new BorderLayout());
	buttonsP.setLayout(new GridLayout(12,1));
	for (int i=0; i<12; i++)
	    {
	    button[i]= new JButton("F");
	    button[i].setActionCommand("F"+Integer.toString(i+1));
	    button[i].addActionListener(this);
            button[i].addKeyListener(this);
	    // don't need tooltips, since these aren't icons
	    //	    button[i].setToolTipText("button tooltip");
	    }
        // create the main text display area
	iButtonHt = button[0].getPreferredSize().height;
        textDisplayArea = new JEditorPane();
	textDisplayArea.addKeyListener(this);
        textDisplayArea.setContentType("text/html");
        textDisplayArea.setEditable(false);
	//        textDisplayArea.setPreferredSize(new Dimension(500,300));
	//pack();
	//     textDisplayArea.setPreferredSize(new Dimension(300,450));
        JPanel innerPanel = new JPanel(new BorderLayout());
        JScrollPane scroller = new JScrollPane(textDisplayArea,
			ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,
			ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
	//pack();
        innerPanel.add(scroller, BorderLayout.CENTER);
	//innerPanel.setPreferredSize(new Dimension(550,350));
        outerPanel = new JPanel(new BorderLayout());
        outerPanel.setBorder(BorderFactory.createMatteBorder(10,10,10,10,
                             getBackground()));
	//pack();
	outerPanel.add(innerPanel,BorderLayout.CENTER);
	m_OriginalDimension = getSize();
	m_OriginalCpDimension = cp.getPreferredSize();
	setKeyEventsToViewport(new String[]{"F1","F2","F3","F4","F5",
					    "F6","F7","F8","F9","F10",
					    "F11","F12",
					    "Insert","Delete","Escape",
					    "Up","Down","Left","Right",
	                                    "NumPad +","NumPad -","NumPad ."});
	}

      /** Set up a set of components for Question panel
       *  @param   czOperation  one of "CUR", "GCP", etc
       *  @param   czHeadings   actual or keyed column headings, or null
       *                        (If key search fails, use as actual)
       *                        The number and sequence of headings defines
       *                        the table layout
       *  @param   parentArea   screen coords occupied by parent VP,
       *                        or all zeroes
       */
    public void setupControls(String czOperation,
			      String[] czHeadings,
			      Rectangle parentArea) 
        {
	boolean bTextArea = false;   /* select one of two layouts */
	GridLayout gLayout = null;
	String[] jsButtonKeys = null;
        String[] jsButtonLabels = null;
	String[] jsHeadingLabels = null;
	int iRows = 0;
	int iCols = 0;
        int iRegionSize = 0;
	if (czOperation.equals("CUR"))
	    {
	    bTextArea = true;        /* enable text area display */
	    iCols = 1;
	    iRows = 3;
	    jsButtonKeys = jsCurButtonKeys;
	    if (jsCurButtonLabels == null)
	        {
	        jsCurButtonLabels = initializeLabels(jsButtonKeys);
	        }
	    jsButtonLabels = jsCurButtonLabels;
	    if (czHeadings != null)
	        {
                if ((curHeadingLabels == null) || (lastHeadings == null))
		    curHeadingLabels = initializeLabels(czHeadings);
		else if (differentArrays(lastHeadings,czHeadings))
		    curHeadingLabels = initializeLabels(czHeadings);
                lastHeadings = czHeadings;
		jsHeadingLabels = curHeadingLabels;
		}
            if (textDisplayArea != null)
  	        textDisplayArea.setText("<html><body></body></html>");
	    }
	else if (czOperation.equals("VEC"))
	    {
	    jsButtonKeys = jsVecButtonKeys;
	    if (jsVecButtonLabels == null)
	        {
	        jsVecButtonLabels = initializeLabels(jsButtonKeys);
	        }
	    jsButtonLabels = jsVecButtonLabels;
	    }
	else if (czOperation.equals("MEA"))
	    {
	    bTextArea = true;        /* enable text area display */
	    iCols = 1;
	    iRows = 7;
	    jsButtonKeys = jsMeaButtonKeys;
	    if (jsMeaButtonLabels == null)
	        {
	        jsMeaButtonLabels = initializeLabels(jsButtonKeys);
	        }
	    jsButtonLabels = jsMeaButtonLabels;
	    if (czHeadings != null)
	        {
                if (meaHeadingLabels == null)
		    meaHeadingLabels = initializeLabels(czHeadings);
		jsHeadingLabels = meaHeadingLabels;
		}
	    }
	else if (czOperation.equals("COO"))
	    {
	    jsButtonKeys = jsCooButtonKeys;
	    if (jsCooButtonLabels == null)
	        {
	        jsCooButtonLabels = initializeLabels(jsButtonKeys);
	        }
	    jsButtonLabels = jsCooButtonLabels;
	    }
	else if (czOperation.equals("GCP"))
	    {
	    jsButtonKeys = jsGcpButtonKeys;
	    if (jsGcpButtonLabels == null)
	        {
	        jsGcpButtonLabels = initializeLabels(jsButtonKeys);
	        }
	    jsButtonLabels = jsGcpButtonLabels;
	    }
	else if (czOperation.equals("COL"))
	  // no longer used 
	    {
	    jsButtonKeys = jsColButtonKeys;
	    if (jsColButtonLabels == null)
 	        {
	        jsColButtonLabels = initializeLabels(jsButtonKeys);
	        }
	    jsButtonLabels = jsColButtonLabels;
	    }
	else if (czOperation.equals("TRA"))
	    {
	    jsButtonKeys = jsTraButtonKeys;
	    if (jsTraButtonLabels == null)
 	        {
	        jsTraButtonLabels = initializeLabels(jsButtonKeys);
	        }
	    jsButtonLabels = jsTraButtonLabels;
	    }
	if (iRows == 0)
	    {
	    iRows = countButtonLabels(jsButtonLabels);
	    iCols = 1;
	    }

	//viewProg.logViewport("viewButtonPanel::SetupControls op="+czOperation
	//		     +" bText="+bTextArea);
	//viewProg.logViewport("            hdrs="+czHeadings
	//		     +" parentArea="+parentArea);
	Container cp = getContentPane();
	    // buttonsP only used if bTextArea
	gLayout = (GridLayout)	buttonsP.getLayout();
	gLayout.setColumns(iCols);
	gLayout.setRows(iRows);

	int iButtonCount = 0;
        int len = jsButtonLabels.length;
	for (int i=0; i<len; i++)
	    {
  	    if ((jsButtonLabels != null) && (jsButtonLabels[i] != null)
		  && (jsButtonLabels[i].length() > 0))
	        {
		button[i].setText(jsButtonLabels[i]);
		buttonsP.add(button[i]);
		iButtonCount++;
		}
	    }
        if ((czOperation.equals("MEA")) ||
            (czOperation.equals("CUR")))
            {
	    JPanel constraintPanel = new JPanel(new BorderLayout());
            constraintPanel.setBorder(new EmptyBorder(5,5,5,0));
            constraintPanel.add(buttonsP,BorderLayout.NORTH);
	    cp.add(constraintPanel,BorderLayout.WEST);
	    }
        else 
	    cp.add(buttonsP,BorderLayout.SOUTH);
	pack();
	if (bTextArea)
	    {
	    boolean bCurWindow = false;
	    StringBuffer buffer = new StringBuffer();
	    String initialText = null;
	    if (czHeadings != null) 
	        {
		len = jsHeadingLabels.length;
		buffer.append("<table align=center cellpadding=2><tr>");
		for (int i=0; i< len; i++)
		    {
		    buffer.append("<th nowrap style=\"font: 12pt\">");
                    buffer.append(jsHeadingLabels[i]+"&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;");
		    buffer.append("</th>");
		    }
		buffer.append("</tr>");
		czTableHeader = buffer.toString();
		buffer.append(czTableContents);
		initialText = buffer.toString();
		if ((initialText.indexOf("#") < 0) &&
		    (czOperation.equals("CUR")))
		    {
		    bCurWindow = true;
		    try
		       {
		       iRegionSize = Integer.parseInt(initialText.substring(0,1));
		       }
		    catch (NumberFormatException nfe)
			{
			iRegionSize = 9;
			}
		    }
                if (bCurWindow)
                    {
		    textDisplayArea.setText("");
		    }
		else
		    {
		    int pos = initialText.indexOf("$$m");
		    // remove weird file name and replace with '=M' 
		    if (pos >= 0)
			{
			StringBuffer temp = new StringBuffer();	
			temp.append(initialText.substring(0,pos));
			temp.append("=M");
			temp.append(initialText.substring(pos+4));
			initialText = temp.toString();
			}
		    textDisplayArea.setText(initialText);
		    }
		}
	    cp.add(outerPanel,BorderLayout.CENTER);
	    Dimension tdSize = textDisplayArea.getPreferredSize();
            if (bCurWindow)
	        {
		tdSize.width = Math.max((len-1) * iRegionSize * 20,450);
		tdSize.height = (iRegionSize + 1) * 25;
		}
	    else if (czOperation.equals("CUR"))
	        {
		tdSize.width += tdSize.width * 0.5;
		//tdSize.width -= tdSize.width/4;
		tdSize.height = 200;
		}
	    else  /* MEA */
	        {
		Dimension cpSize = cp.getPreferredSize();
                viewProg.logViewport("MEA button panel wants to be " +
				     cpSize.width + " by " +
				     cpSize.height);
		tdSize.width = 700;
		tdSize.height = cpSize.height + 40;
		}
	    setSize(tdSize);
	    //viewProg.logViewport("viewButtonPanel::SetupControls text setsize="
	    //+tdSize.width+","+tdSize.height);
	    }
	else
	    {
	    Dimension cpSize = cp.getPreferredSize();
	    int iHt = iButtonHt * iButtonCount; // + 65;
	    cpSize.width += cpSize.width/3;/* 1.3 * width */
	    setSize(cpSize.width,iHt); 
	    pack();
	    }
	setLocation((bTextArea) ? 2 : 1,parentArea);
	}

      /**
       * Factorization. Returns true if the two passed string
       * arrays have different contents, else false 
       * @param array1 First array to compare
       * @param array2 Second array to compare
       * @return True if arrays do NOT match, false if they do.
       */
    protected boolean differentArrays(String[] array1, String[] array2)
        {
	boolean bDifferent = false;
	if (array1.length != array2.length)
	    bDifferent = true;
	else
	    {
	    int len = array1.length;
	    for (int i = 0; i < len; i++)
	        {
		if (array1[i].compareTo(array2[i]) != 0)
		    {
		    bDifferent = true;
		    break;
		    }
		}
	    }
	return bDifferent;
        }

      /** display the button panel. This overrides
       * the superclass method in JniDialog
       */
    public void showIt()
        {
	PanelRepainter pr = new PanelRepainter(this);        
	paintTimer = new javax.swing.Timer(1000,pr);
        paintTimer.setRepeats(true);
	setVisible(true);
	requestFocus();
	paintTimer.start();
	}


      /* polite way to finish using panel.
       * Hides it, but also sets some global vars to null
       */
    void killPanel()
        {
	super.killDialog();
	Container cp = getContentPane();
	int count = cp.getComponentCount();
	//System.out.println("killPanel: cp has "+cp.getComponentCount()
	//		   +" components");
	buttonsP.removeAll();
	cp.removeAll();
        if (paintTimer != null)
            {
	    paintTimer.stop();
	    paintTimer = null;
	    }
	
	//System.out.println("killPanel: (ex) cp has "+cp.getComponentCount()
	//		   +" components");
	}

      /**
       * Factorization. Looks up the keys in the the keys array,
       * allocates the labels array and stores the strings there.
       * @param keys  Array of i18N keys - some likely blank or null
       * @return  Initialized array of xlated strings
       */
    protected String[] initializeLabels(String[] keys)
        {
	int len = keys.length;
	String[]labels = new String[len];
	for (int i = 0; i < len; i++)
	    {
	    String msg = "";
	    if ((keys[i] != null) && (keys[i].length() > 0))
	        {
	        msg = keys[i];
	        if (m_viewMsgs != null)
		      msg = m_viewMsgs.getI18NText(keys[i],
  					           keys[i]);
		}
	    labels[i] = msg;
	    }
        return labels;
	}

      /**
       * Figure out how many buttons are needed based on
       * how many non-empty labels are in the passed array.
       * @param labels  Array of labels for buttons
       * @return count of non-blank,non-null labels 
       */
    protected int countButtonLabels(String[] labels)
        {
	int count = 0;
	int len = labels.length;
	for (int i = 0; i < len; i++)
	    {
	    if ((labels[i] != null) && (labels[i].length() > 0))
	         count++;
	    }
	return count;
	}

    static String[] jsCurButtonKeys 
       = { "%h9900.12","","","%h9900.24","","","","", "%h9900.6","",
	   "","" } ; 
    static String[] jsVecButtonKeys 
       = { "%h9900.0","","%h9900.7","%h9900.24","",
	   "%h9900.2","%h9900.3","%h9900.4", "%h9900.5","%h9900.8",
	   "%h9900.26",""
         } ; 
      /* 9900.2/.10 and 9900.3/.11 share button */
    static String[] jsMeaButtonKeys 
       = { "%h9900.12","","","%h9900.24","",
	   "%h9900.10","%h9900.11","%h9900.9", "%h9900.5","",
	   "%h9900.26",""
         } ; 
    static String[] jsCooButtonKeys 
       = { "%h9900.0","","","%h9900.24","",
	   "","%h9900.3","", "%h9900.5","%h9900.8",
           "%h9900.26",""
          } ; 
    static String[] jsGcpButtonKeys 
       = { "%h9900.0","","","%h9900.24","", "","","", 
	   "%h9900.5","%h9900.8","","" } ; 
    static String[] jsColButtonKeys 
       = { "%h9900.0","","","","","","","", "","","","" } ; 
    static String[] jsTraButtonKeys 
       = { "%h9900.0","","","%h9900.24","",
	   "%h9900.13","","", "%h9900.5","%h9900.8","","" } ; 

    static String[] jsCurButtonLabels = null;
    static String[] jsVecButtonLabels = null;
    static String[] jsMeaButtonLabels = null;
    static String[] jsCooButtonLabels = null;
    static String[] jsGcpButtonLabels = null;
    static String[] jsColButtonLabels = null;
    static String[] jsTraButtonLabels = null;
    static String[] meaHeadingLabels = null;
    static String[] curHeadingLabels = null;
    static String[] lastHeadings = null;

      /* clear out local data before a new plot 
       */
    public void reinit()
        {
	czTableContents = "</table>";
	czTableHeader = "";
	textDisplayArea.setText("");
	setSize(m_OriginalDimension);
	getContentPane().setSize(m_OriginalCpDimension);
	}

    protected JPanel buttonsP = new JPanel();
    protected JButton[] button = new JButton[12];
      /* the table area */
    protected JEditorPane textDisplayArea = null;
    protected String czTableHeader = null;
    protected String czTableContents = null;
    protected JPanel outerPanel = null;
    protected int iButtonHt = 0;
    protected Dimension m_OriginalDimension = null;
    protected Dimension m_OriginalCpDimension = null;

      /** enable/disable one of the visible buttons
       *  @param  iButtonIndex   button number 0 to 11, matching F1 .. F12
       *  @param  bEnable        true => enable false => disable
       *  @param  pczLabel       text or key to display.
       */
    public void setButtonEnabled(int iButtonIndex, boolean bEnable,
				 String pczLabel)
        {
	if (m_viewMsgs != null)
	    {
	    String msg = m_viewMsgs.getI18NText(pczLabel,"Key = "+pczLabel);
	    button[iButtonIndex].setText(msg);
	    }
	button[iButtonIndex].setEnabled(bEnable);
        repaint();
        toFront();
        }
	/** NOTE - The labels are originally set from inside this
         * module - see the static string arrays at the end of this
	 * file. However, the viewport overrides these values 
	 * (above) because there are a few cases where the label changes
	 * depending on the viewport state.
	 */

      /** add a line of text to an already-existing table
       *  @param  czText   line of text already formatted as HTML
       *  @param  replaceFlag  if 1, replace contents rather than adding to
       *                   existing.
       */
    public void addTableLine(String czText, int replaceFlag)
        {
	//   outputToTemp(czText);
	if (textDisplayArea != null)
	    {
	    if (replaceFlag == 1)
                {
		setVisible(false);
		czTableContents = czText; // replace
		textDisplayArea.setText(czTableContents);
                Dimension dim = textDisplayArea.getPreferredSize();
                textDisplayArea.setSize(dim);
		pack();
		setVisible(true);
                }
            else
		{
		czTableContents = czText+czTableContents; // prefix new line
		textDisplayArea.setText(czTableHeader+czTableContents);
		}
	    viewProg.logViewport("viewButtonPanel::AddTableLine full table=\n"
                                 +czTableContents);
	    }
	}


    /* methods for KeyListener */
    /**
     * Implement function keys as alternate invokers
     * for buttons in the panel.
     * @param e   Key event that triggered the call of this function
     */
    public void keyPressed(KeyEvent e)
       {
       super.keyPressed(e);
       /*** 
      int code = e.getKeyCode();
       int index = findKeyCodeIndex(code);
       viewProg.logViewport("ViewProg::viewButtonPanel key pressed " +
           KeyEvent.getKeyText(e.getKeyCode()));
       if (index >= 0)
	  {
	  JButton candidateButton = button[index];
	  if (button[index].isEnabled())
	      button[index].doClick();
          }
       ***/  
       }

     /** 
      * Factorization of keyPressed method.
      * Looks up keycode in array to see if
      * it is one of the function keys that
      * we are looking for. If it is, returns
      * the appropriate index into the button array,
      * for the button that corresponds to this
      * function key.
      * @param code   Keycode that was pressed
      * @return  index into the button array, or -1 if
      *          not a relevant function key.
      */
    protected int findKeyCodeIndex(int code)
       {
       int found = -1;
       for (int i = 0; i < functionKeys.length; i++)
           {
	   if (functionKeys[i] == code)
               {
	       found = i;
	       break;
	       }
           }
       return found;
       }
 
    /**  Implemented by the parent class
    public void keyReleased(KeyEvent e)
       {
       }

    public void keyTyped(KeyEvent e)
       {
       }
    **/


    /** @link dependency */
    /*#JniDialog lnkJniDialog;*/

    public void outputToTemp(String outputString)
	{
        try
	    {
	    BufferedWriter writer = new BufferedWriter
	        (new FileWriter("javaout.tmp",true));
            writer.write("Time: " + new Date().toString() + " -- ");
	    writer.write(outputString);
	    writer.newLine();
            writer.close();
	    }
	catch (IOException ioe)
            {
	    Toolkit.getDefaultToolkit().beep();
            ioe.printStackTrace();
            }
	    
        }

     /** Inner class to redisplay the button panel periodically */
    class PanelRepainter implements ActionListener 
    {
       protected viewButtonPanel panel;

       public PanelRepainter(viewButtonPanel panel)
	  {
	  this.panel = panel;
	  }

        /**
          * Method from action listener 
          */
       public void actionPerformed(ActionEvent e)
          {
	  if (panel.isVisible())
	      panel.repaint();
          }
    }

    }

