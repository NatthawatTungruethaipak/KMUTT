/**
 *   ExecListener.java
 *   
 *     Created by S.Goldin
 *
 *    $Id: ExecListener.java,v 1.1 2004/02/24 12:25:11 rudahl Exp $
 *
 *    $Log: ExecListener.java,v $
 *    Revision 1.1  2004/02/24 12:25:11  rudahl
 *    Developing for Release 1
 *
 *
 */
package com.grs.evp;

/**
 * Interface to be used with generic SystemExcecutor class.
 * A class which implements this interface can be notified
 * when a command execution is complete.
 */
public interface ExecListener
    {
    /**
     *  Called by executor when command completes. 
     * @param     bOk   If true, command was successful.
     */
    public void notifyComplete(boolean bOk);
    }
