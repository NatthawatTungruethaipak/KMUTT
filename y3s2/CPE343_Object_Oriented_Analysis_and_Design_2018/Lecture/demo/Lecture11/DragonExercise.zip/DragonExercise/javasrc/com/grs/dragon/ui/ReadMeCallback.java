/* ReadMeCallback.java
 *
 *    ~~ Copyright 2010 Kurt Rudahl and Sally Goldin
 *
 *	All rights are reserved. Copying or other reproduction of
 *	this program except for archival purposes is prohibited
 *	without the prior written consent of Goldin-Rudahl Associates.
 *
 *			  RESTRICTED RIGHTS LEGEND
 *
 *	Use, duplication, or disclosure by the U.S. Government
 *	is subject to restrictions as set forth in
 *	paragraph (b) (3) (B) of the Rights in Technical
 *	Data and Computer Software clause in DAR 7-104.9(a).
 *
 *	The moral right of the copyright holder is hereby asserted
 *   ~~ EndC
 *
 * $Id: ReadMeCallback.java,v 1.1 2010/12/06 11:11:54 goldin Exp $
 * $Log: ReadMeCallback.java,v $
 * Revision 1.1  2010/12/06 11:11:54  goldin
 * New callback to display Readme file from Dragon menu
 *
 *
 */
package com.grs.dragon.ui;
import com.grs.gui.*;
import com.grs.dragon.common.ReadMe;

//********************************************************************
/** 
 *  This class implements the Callback interface. It has the effect
 *  of bringing up a web browser (the system default) showing the READMe file
 */
public class ReadMeCallback implements Callback 
    {
      /** Primary method of a callback class.
       *  Sends a command to the manreader, which should be running.
       * @param  field Field whose value will determine the
       *   effects of the callback.
       */
    public void executeCallback(DragonField field)
        {
	ReadMe htmlDisplay = 
           new ReadMe(ApplicationManager.getHomeDirectory());
	htmlDisplay.start();
	}

    protected static String cvsInfo = null;
    protected static void setCvsInfo()
        {
        cvsInfo = "\n@(#)  $Id: ReadMeCallback.java,v 1.1 2010/12/06 11:11:54 goldin Exp $ \n";
	}
    }

// End of ReadMeCallback.java

