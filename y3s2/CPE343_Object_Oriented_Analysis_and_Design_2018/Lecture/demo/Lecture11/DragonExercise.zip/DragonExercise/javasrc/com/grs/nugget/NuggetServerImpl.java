/* NuggetServerImpl is the implementation of rmi interface NuggetServer
 *
 * $Id: NuggetServerImpl.java,v 1.1 2002/10/26 23:34:25 rudahl Exp $
 * $Log: NuggetServerImpl.java,v $
 * Revision 1.1  2002/10/26 23:34:25  rudahl
 * initial deposit
 *
 *
 *-----------------------------------------------------------------
 */

package com.grs.nugget;

import java.sql.*;
import java.util.*;
import java.rmi.*;
import com.grs.dbi.*;


/** 
 * This class defines a remote interface for accessing the Nugget DB
 * See <a href="NuggetServerImpl.html">HostAuthImpl</a> 
 *  for the implementation of this interface.
 */

public class NuggetServerImpl 
         extends java.rmi.server.UnicastRemoteObject implements NuggetServer 
    {
    protected NuggetDaemon daemon = null;

    public NuggetServerImpl(NuggetDaemon daemon)
         throws java.rmi.RemoteException
	{
	super();  
	this.daemon = daemon;
	}

     /** Get from the DB a vector of ClientTasks which match the qualifiers,
      *  plus any other constraints the server my impose. 
      *  see <a href="NuggetDaemon.html">NuggetDaemon</a> for details.
      */
    public Vector taskSearch(int iPriority, String sPreferredNode,
			     String sClientNode)
	throws DbiException, SQLException, java.rmi.RemoteException
	{
	return daemon.taskSearch(iPriority,sPreferredNode,sClientNode);
	}
 
     /** Commit the client to performing the specified task, if the
      * task is still available.  The server will mark the task as being no
      * longer available (at least until a suitable timeout has occurred).
      *  see <a href="NuggetDaemon.html">NuggetDaemon</a> for details.
      */ 
    public boolean taskAccept(int iTaskId,String sClientNode)
	throws DbiException, SQLException, java.rmi.RemoteException
	{
	return daemon.taskAccept(iTaskId,sClientNode);
	}

     /* Indicates to the server that the client is finished with the
      * task.
      *  see <a href="NuggetDaemon.html">NuggetDaemon</a> for details.
      */
    public boolean taskRelease(int iTaskId,int iCompletionCode,
			       String sClientNode,
			       String sResult,String sLog)
	throws DbiException, SQLException, java.rmi.RemoteException
	{
	return daemon.taskRelease(iTaskId,iCompletionCode,
				  sClientNode,sResult,sLog);
	}

     /* This is equivalent to sending a 'Reject' for each task which the
      * client is currently marked as having accepted. Since client doesn't
      * need to know which tasks those are, this effectively serves as a reset
      * function, and should always be executed by client daemon on startup.
      */
    public void releaseAllTasks(String sClientNode,String explain)
	throws DbiException, SQLException, java.rmi.RemoteException
	{
	daemon.releaseAllTasks(sClientNode,explain);
	}

    }
