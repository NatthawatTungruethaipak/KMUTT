/**
 *  TiffImageFileWriter
 *
 *  Copyright 2002 by Goldin-Rudahl Associates
 *
 *  Created 3/7/2002 by Sally Goldin
 *  Tiff writing code adapted from dtk\tiff-wrt.c
 *
 *  $Id: TiffImageFileWriter.java,v 1.1 2002/03/08 00:39:05 goldin Exp $
 *  $Log: TiffImageFileWriter.java,v $
 *  Revision 1.1  2002/03/08 00:39:05  goldin
 *  Begin development of image file classes
 *
 */

package com.grs.imgfiles;
import java.awt.*;
import java.awt.image.*;
import javax.swing.*;
import java.io.*;

/**
 * This subclass of image file writer writes
 * the image data to a simple, one strip unmapped TIFF
 * file.
 */
public class TiffImageFileWriter extends ImageFileWriter
    {
     protected static final byte  TAG_NEWSUBFILE	= 254;	/* 5.0 */
     protected static final byte  TAG_SUBFILE	= 255;	/* obs */
     protected static final byte  TAG255		= 255;
     protected static final byte  TAG_IMWIDTH	= 256;
     protected static final byte  TAG_IMLENGTH	= 257;	/* x */
     protected static final byte  TAG_BITSPIX	= 258;	/* PR */
     protected static final byte  TAG_COMPRESS	= 259;	/* PR */
     protected static final byte  TAG_PHOTOBYTEERP= 262;	/* PR */
     protected static final byte  TAG_CELL_WIDTH	= 264;	/* obs */
     protected static final byte  TAG_CELL_LENGTH= 265;	/* obs */
     protected static final byte  TAG_FILLORD	= 266;	/* obs */
     protected static final byte  TAG_DOCNAME	= 269;
     protected static final byte  TAG_DESCR	= 270;
     protected static final byte  TAG_STRIP_OFFSET = 273;	/* x */
     protected static final byte  TAG_ORIENT	= 274;	/* obs? */
     protected static final byte  TAG_SAMPIX	= 277;	/* PR */
     protected static final byte  TAG_STRIP_BYTE = 279;	/* x */
     protected static final byte  TAG_ROW_STRIP	= 278;	/* x */
     protected static final byte  TAG_MINSAMP	= 280;	/* obs */
     protected static final byte  TAG_MAXSAMP	= 281;	/* obs */
     protected static final byte  TAG_XRES	= 282;	/* x */
     protected static final byte  TAG_YRES	= 283;	/* x */
     protected static final byte  TAG_PLANAR	= 284;	/* R */
     protected static final byte  TAG_XPOS	= 286;	/* dragon */
     protected static final byte  TAG_YPOS	= 287;	/* dragon */
     protected static final byte  TAG_GREYRES	= 290;
     protected static final byte  TAG_GREYCRV	= 291;
     protected static final byte  TAG_RESUNIT	= 296;	/* x */
     protected static final byte  TAG_COLORCRV	= 301;		/* ktr 9/88 */
     protected static final byte  TAG_SOFTWARE	= 305;
     protected static final byte  TAG_COLORMAP	= 320;	/* P, 5.0 */
     protected static final byte  TAG273	= TAG_STRIP_OFFSET;
     protected static final byte  TAG279	= TAG_STRIP_BYTE;
     protected static final byte  TAG_COUNT = 15;
     /* used to define size of array-must be EXACT */

     /*  TIFF definitions */
     protected static final byte TBYTE =	1;
     protected static final byte TASCII=	2;
     protected static final byte TSHORT=	3;
     protected static final byte TLONG=	4;
     protected static final byte TRATNL=	5;


     protected static int tagList[] = 
        {
	TAG_IMWIDTH,		
	TAG_IMLENGTH,		
	TAG_BITSPIX,		
	TAG_COMPRESS,		
	TAG_PHOTOINTERP,	
	TAG_STRIP_OFFSET,	
	TAG_SAMPIX,		
	TAG_ROW_STRIP,		
	TAG_STRIP_BYTE,		
	TAG_XRES,		
	TAG_YRES,		
	TAG_RESUNIT,		
	TAG_SOFTWARE,		
	} ;

     protected static byte headerBytes[] = 
     {0x49,0x49,0x2a,0,0x8,0,0,0,                  // offset 0
      0xD, 0,                                      // offset 8
	   TAG_IMWIDTH,0,TSHORT,0,1,0,0,0,0,0,0,0,       // fill in
	   TAG_IMLENGTH,0,TSHORT,0,1,0,0,0,0,0,0,0      // fill in
	   TAG_BITSPIX,0,TSHORT,0,1,0,0,0,8,0,0,0
	   TAG_COMPRESS,0,TSHORT,0,1,0,0.0.1,0,0,0
	   TAG_PHOTOINTERP,0,TSHORT,0,1,0,0,0,3,0,0,0,
	   TAG_STRIP_OFFSET,0,TLONG,0,1,0,0,0,0,0,0,0,  // fill in
	   TAG_SAMPIX,0,TSHORT,0,1,0,0,0,3,0,0,0,
	   TAG_ROW_STRIP,0,TSHORT,0,1,0,0,0,0,0,0,0,    // fill in 
	   TAG_STRIP_BYTE,0,TLONG,0,1,0,0,0,0,0,0,0,    // total # pix
	   TAG_XRES,0,TRATNL,0,1,0,0,0,0,0,0,0,    
	   TAG_YRES,0,TRATNL,0,1,0,0,0,0,0,0,0,    
	   TAG_SOFTWARE,0,TASCII,0,1,0,0,0,0,0,0,0,    
	   0,0,0,0,
	   0x80,0,0,0,1,0,0,0, // value for XRES
	   0x80,0,0,0,1,0,0,0, // value for YRES
           0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}; // value for software


      /**
       * Explicit constructor, just calls superclass
       */
    public TiffImageFileWriter(Image image, String filename)
        {
	super(image,filename);
	}

      /**
       * This is the primary method for this class. It
       * uses the filename passed in the constructor to
       * create three filenames, and writes the correct data
       * to each one. Since this is top to bottom, left to right
       * image, we can write all the data in a single
       * operation; we don't need to treat it row by row.
       * Returns true if ok, false if not.
       */
    public boolean writeImage()
        {
	boolean bOk = true;
	String fnameRoot = null;
	String fnameExt = null;
	int pos = imgFilename.lastIndexOf(".");
	if (pos >= 0)
	    {
	    fnameRoot = imgFilename.substring(0,pos);
	    fnameExt = imgFilename.substring(pos);
	    }
	else
	    {
	    fnameRoot = imgFilename;
	    fnameExt = ".GEN";
	    }
	String redFname = fnameRoot + "R" + fnameExt;  
	String greenFname = fnameRoot + "G" + fnameExt;  
	String blueFname = fnameRoot + "B" + fnameExt;  
	int datalen = imgPixels.length;
	createComponentArrays();  // base class method populates rBytes etc.
	try
	    {
	    BufferedOutputStream out = new BufferedOutputStream
                         (new FileOutputStream(redFname));
	    out.write(rBytes,0, datalen);
	    out.close();
	    out = new BufferedOutputStream
                         (new FileOutputStream(greenFname));
	    out.write(gBytes,0, datalen);
	    out.close();
	    out = new BufferedOutputStream
                         (new FileOutputStream(blueFname));
	    out.write(bBytes,0, datalen);
	    out.close();
	    }
	catch (IOException ioe)
	    {
            bOk = false;	      
	    }
	finally
	    {
	    return bOk;
	    }
	}


      /**
       * Begins the process of writing a 3-band TIFF file.
       * Writes the TIFF header.
       * Most of the header data is fixed, but we need 
       * to update a few fields.
       * @param filename Name of file to write data to.
       * @returns open BufferedOutputStream where writing is
       *         going on, or null for error.
       */
    protected BufferedOutputStream writeTiffHeader(String filename)
        {
	BufferedOutputStream outStream = null;
	try
	     {
	     outStream = new BufferedOutputStream(
			   new FileOutputStream(fileName));
	    
	     String softname = "com.grs.imgfiles.TiffImageFileWriter";

	     return outStream;
	     }
	catch (IOException ioe)
	     {
	     return null;
	     }
	}




      /**
       * Test driver method
       * Assumes input image file (jpg) and output name passed on cmd line
       */
    public static void main(String args[])
        {
	if (args.length < 2)
	    {
	    System.out.println(
              "Usage: java TiffImageFileWriter <inputJpg> <outputfile>");
	    System.exit(0);
	    }
	File testFile = new File(args[0]);
	if (!testFile.exists())
	    {
	    System.out.println("Input image file " + args[0] +
			       " does not exist.");
	    System.exit(0);
	    }
	Image baseImage = new ImageIcon(args[0]).getImage();
	if (baseImage == null)
	    {
	    System.out.println("Error reading image file");
	    System.exit(0);
	    }
	TiffImageFileWriter imgWriter = 
            new TiffImageFileWriter(baseImage,args[1]);
	if (!imgWriter.isInitialized())
	    {
	    System.out.println("Error in ImageFileWriter constructor");
	    System.exit(0);
	    }
	System.out.println("Image is " + imgWriter.getWidth() + " by " +
			   imgWriter.getHeight() + " pixels ");
	imgWriter.writeImage();
	System.out.println("Done");
	System.exit(0);
	}

      /**
       * Inner class for ImageFileDirectory structure.
       */
    class ImgFileDir
        {
	public int tagnum;
        public int fieldtype;
        public int fieldlen;
        public int  offset_rvalue;
        } 
    }
