/**
 * DirectoryNameDlg
 *
 * Copyright  2014 by Goldin-Rudahl Associates
 *
 * Created by Sally Goldin, 3/07/2014
 *
 *  $Id: DirectoryNameDlg.java,v 1.1 2014/03/07 13:09:41 goldin Exp $
 *  $Log: DirectoryNameDlg.java,v $
 *  Revision 1.1  2014/03/07 13:09:41  goldin
 *  Improvements to file chooser including ability to create new directories
 *
 */

package com.grs.gui;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import java.util.*;
import java.io.*;

/**
 * This class is a UI component to get the name of a new 
 * directory to be created in the currently selected directory.
 * All the functionality for doing this is encapsulated in this
 * class.
 */
public class DirectoryNameDlg extends JDialog implements ActionListener,
							 KeyListener
{

    /** parent file chooser that created this dialog */
    protected DragonFileChooser parentChooser = null; 

    /** Directory within which any new directory will be created 
     * This is the full path. 
     */
    protected String parentDir = null;  

    /** Reference to text source for translated labels. */
    protected I18NTextSource textSource = null;


    /** Text field to hold the filename typed */
    protected JTextField dirEntryField = null;

    /** Buttons */
    protected JButton okButton = null;
    protected JButton cancelButton = null;


    /** Constructor creates UI but does not show it.
     * @param parent                FileChooser that created this
     * @param currentDir            Directory in which new folder should be
     *                                created 
     * @param labelString           Text for dialog title
     * @param textSource            Supports internationalization of strings
     */
    public DirectoryNameDlg(DragonFileChooser parent,
			    String labelString, I18NTextSource textSource)
       {
       super(parent,labelString,true);
       parentChooser = parent;
       this.textSource = textSource;
       buildDialog();
       }


    /**
     * Factorization that creates the dialog UI
     */
    protected void buildDialog()
       {
       JPanel mainPanel = new JPanel(new BorderLayout());
       mainPanel.setBorder(new EmptyBorder(30,30,30,30));
       JPanel fieldPanel = new JPanel(new BorderLayout());
       dirEntryField = new JTextField(40);
       dirEntryField.setDocument(new FilenameDocument(true,false));
       dirEntryField.addKeyListener(this);
       fieldPanel.add(dirEntryField,BorderLayout.NORTH);
       mainPanel.add(fieldPanel,BorderLayout.CENTER);
       JPanel buttonPanel = new JPanel(new FlowLayout());
       buttonPanel.setBorder(new EmptyBorder(20,0,0,0));
       String label = textSource.getI18NText(TextKeys.OK, "OK");
       okButton = new JButton(label);
       okButton.addActionListener(this);
       buttonPanel.add(okButton);
       label = textSource.getI18NText(TextKeys.CANCEL, "CANCEL");
       cancelButton = new JButton(label);
       cancelButton.addActionListener(this);
       buttonPanel.add(cancelButton);
       mainPanel.add(buttonPanel, BorderLayout.SOUTH);
       this.add(mainPanel);
       pack();
       }


    /* Set visible, also setting the current directory
     * @param   currentDir    Directory where the new dir should be created
     */
    public void showDialog(String currentDir)
       {
       parentDir = currentDir;
       setLocationRelativeTo(parentChooser);
       dirEntryField.setText("");
       dirEntryField.repaint();
       this.setVisible(true);
       dirEntryField.requestFocus();
       }
     

      /**
       * Methods from the KeyListener interface.
       */
    public void keyPressed(KeyEvent ke)
        {
	int code = ke.getKeyCode();
	switch (code)
	    {
	    case KeyEvent.VK_F1:
	        if (okButton.isEnabled())
		    okButton.doClick();
                ke.consume();
		break;
	    case KeyEvent.VK_F10:
	    case KeyEvent.VK_ESCAPE:
                cancelButton.doClick();
		ke.consume();
	    default:
	        break;
	    }
	}

    public void keyReleased(KeyEvent ke)
        {
	}

    public void keyTyped(KeyEvent ke)
        {
        String fieldContents = dirEntryField.getText();
        if (fieldContents.length() > 0)
	    okButton.setEnabled(true);
        else 
            okButton.setEnabled(false);
	}



    /**
     * Handles the buttons. Cancel simply makes the dialog disappear.
     * Ok creates the new directory, calls refresh, then sets
     * the current directory to the new directory.
     */
    public void actionPerformed(ActionEvent e)
       {
       Object source = e.getSource();
       if (source == okButton)
	   {
	   File newDirFile = null;
	   String fieldContents = dirEntryField.getText();
	   String message = null;
	   String errorTitle = textSource.getI18NText(TextKeys.ERROR, "ERROR");
	   if (fieldContents.length() > 0)
	       {
	       newDirFile = new File(parentDir,fieldContents);
               if (!newDirFile.exists())
		   {
		   boolean bCreated = false;
		   try 
                      {
		      bCreated = newDirFile.mkdir();
		      }
		   catch (SecurityException se)
		      {
		      bCreated = false;	  
		      }
                   if (!bCreated)
		      {
		      /* error - could not create */
		      message = textSource.getI18NText(TextKeys.DIRCREATEERR, 
                            "ERROR CREATING NEW DIRECTORY");
		      JOptionPane.showMessageDialog(this,message,
						    errorTitle, 
						    JOptionPane.ERROR_MESSAGE);
		      }
                   else
		      {
		      /* refresh, then set parent current directory */ 
		      parentChooser.refresh(newDirFile.getAbsolutePath()); 
                      DragonFileChooser inFileChooser =
			  ApplicationManager.getInFileChooser();
                      if (inFileChooser != null)
                          inFileChooser.refresh(null);
		      this.setVisible(false);
		      }
		   }
	       else
		   {
		   /* directory already exists - error */    
	           message = textSource.getI18NText(TextKeys.FILEEXISTSERR, 
                            "DIRECTORY ALREADY EXISTS");
   	           JOptionPane.showMessageDialog(this,message,
						    errorTitle, 
						 JOptionPane.ERROR_MESSAGE);
		   }
               }
	   else
	       {
	       message = textSource.getI18NText(TextKeys.MISSINGREQUIRED, 
                            "MISSING REQUIRED VALUE");
	       JOptionPane.showMessageDialog(this,message,
					     errorTitle, 
					     JOptionPane.ERROR_MESSAGE);
	       }
	   }
       else if (source == cancelButton)
	   {
	   this.setVisible(false);
	   }
       }



    protected static String cvsInfo = null;
    protected static void setCvsInfo()
        {
        cvsInfo = "\n@(#)  $Id: DirectoryNameDlg.java,v 1.1 2014/03/07 13:09:41 goldin Exp $ \n";
	}

}

