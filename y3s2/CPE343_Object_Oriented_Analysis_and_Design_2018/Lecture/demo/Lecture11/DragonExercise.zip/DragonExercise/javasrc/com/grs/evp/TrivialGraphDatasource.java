/**
 *   TrivialGraphDatasource.java
 *   
 *     Created by S.Goldin
 *
 *    $Id: TrivialGraphDatasource.java,v 1.3 2007/01/05 07:41:57 rudahl Exp $
 *
 *    $Log: TrivialGraphDatasource.java,v $
 *    Revision 1.3  2007/01/05 07:41:57  rudahl
 *    added Whatis info
 *
 *    Revision 1.2  2004/04/04 08:27:23  rudahl
 *    Implement status display functionality
 *
 *    Revision 1.1  2004/02/24 12:25:11  rudahl
 *    Developing for Release 1
 *
 *
 */
package com.grs.evp;

import java.util.*;

/**
 *  This class implements the GraphDatasource interface.
 *  It is intended to test the ChannelData class.
 */

public class TrivialGraphDatasource implements GraphDatasource
    {

    private double data[] = {2.3, 4.5, 23.4, 12.5, 34.5,
				 6.7, 88.3, 12.7, 2.7, 12.2};
    private String dates[] = {"2004-02-16",
			      "2004-02-17",
			      "2004-02-18",
			      "2004-02-19",
			      "2004-02-20",
			      "2004-02-21",
			      "2004-02-22",
			      "2004-02-23",
			      "2004-02-24",
			      "2004-02-25"};

    private ArrayList channels = new ArrayList();	

    private int latestErrorNumber = 0;
    private String latestErrorMessage = null;

    public void init()
	{
	try
	    {
	    ChannelData column0 = new ChannelData();
	    column0.initMetaData("Date",ChannelData.DATE,"%Y-%m-%d");
	    column0.setOwner(this);
	    for (int i = 0; i < dates.length; i++)
	        {
	        column0.addValue(dates[i]);
	        }
	    channels.add(column0);
	    ChannelData column1 = new ChannelData();
	    for (int j = 0; j < data.length; j++)
	        {
	        column1.addValue(String.valueOf(data[j]));
	        }
	    channels.add(column1);
	    column1.initMetaData("Price",ChannelData.FLOAT,null);
	    column1.setOwner(this);
	    }
	catch (Exception e)
	    {
	    latestErrorMessage = e.getMessage();
	    latestErrorNumber = -1;
	    }
	}

    public ChannelData addChannel()
	{
	return null;
	}

    /**
     * Return number of channels (data columns) in
     * the data set. 
     * @return number of channels, or -1 if datasource is not initialized
     */
    public int getChannelCount()
	{
	return channels.size();    
	}

    public int getSampleCount()
	{
        return dates.length;
	}

    
    
    /**
     * Return the ChannelData object at specified index.
     * @param channelIndex   Index we're interested in
     * @return channel object or null if bad index or not initialized
     */
    public ChannelData getChannelData(int channelIndex)
	{
	ChannelData channel = null;
	if ((channelIndex < 0) || (channelIndex >= getChannelCount()))
	    {
	    latestErrorNumber = -2;
	    latestErrorMessage = "Bad channel index";	
	    }
	else
	    {
	    channel =  (ChannelData) channels.get(channelIndex); 
	    }
	return channel;
	}

    /**
     * Get latest error number (if any)
     * @return negative number of latest error, or 0 if no error
     */
    public int getLatestErrorNumber()
	{
	return latestErrorNumber;
	}

    /**
     * Get latest error message (if any)
     * @return error message associated with latest error, or null if no error
     */
    public String getLatestErrorMessage()
	{
	return latestErrorMessage;
	}

    public static void main(String args[])
	{
	int i;
	TrivialGraphDatasource ds = new TrivialGraphDatasource();
	ds.init();
	int num = ds.getLatestErrorNumber();
	if (num != 0)
	    {
	    System.out.println("Error: " + ds.getLatestErrorMessage());
	    }
	System.out.println("In the datasource there are " 
			   + ds.getChannelCount() 
			   + " channels");
	int colIndex = 0;
	for (colIndex = 0; colIndex < 3; colIndex++)
	    {
	    ChannelData channel = ds.getChannelData(colIndex);
	    if (channel == null)
	        {
		num = ds.getLatestErrorNumber();
		if (num != 0)
	            {
		    System.out.println("Error: " + ds.getLatestErrorMessage());
		    }
		}
	    else
	        {
		System.out.println("Channel " + colIndex + " name is " + channel.getName());
		System.out.println("Channel dataType is " + channel.getDataType());
		System.out.println("Channel format is " + channel.getDateFormat());
		try
		    {
		    if (channel.getDataType() == ChannelData.FLOAT)
	                {
			double values[] = channel.getNumericValues();
			for (i = 0; i < values.length; i++)
			    {
			    System.out.println("Value " + i + " = " + values[i]);
			    }
			}
		    else if (channel.getDataType() == ChannelData.DATE)
	                {
			for (i = 0; i < channel.getCount(); i++)
		            {
			    System.out.println("Value " + i + " = "
					       + channel.getValue(i));
			    }
			}
		    }
		catch (Exception e)
		    {
		    System.out.println("Exception thrown: " + e.getMessage());
		    }
		}
	    }
	}
    
    /** Return the symbol for the equity or other thingy that
     * this datasource represents
     */
    public String getSymbol ()
        {
        return "THINGY";
        }   
    

    protected static String cvsInfo = null;
    protected static void setCvsInfo()
        {
        cvsInfo = "\n@(#)  $Id: TrivialGraphDatasource.java,v 1.3 2007/01/05 07:41:57 rudahl Exp $ \n";
	}
    }
