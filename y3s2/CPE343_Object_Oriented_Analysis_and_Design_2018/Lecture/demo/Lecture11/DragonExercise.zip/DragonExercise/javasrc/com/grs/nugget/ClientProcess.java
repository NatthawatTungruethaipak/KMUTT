/* ClientProcess
 * execute a task on client machine
 * $Id: ClientProcess.java,v 1.1 2002/10/26 23:33:15 rudahl Exp $
 * $Log: ClientProcess.java,v $
 * Revision 1.1  2002/10/26 23:33:15  rudahl
 * initial deposit
 *
 */

package com.grs.nugget;

import java.sql.*;
import java.util.*;
import java.text.*;
import java.io.*;
import java.net.*;
import com.grs.dbi.*;

/** class to keep track of bookkeeping connecte with runningaa task
 *  Note that depending on the machine architecture, the ctor may not
 *       return until the spawned process has completed.
 */

public class ClientProcess
    {
    protected Runtime m_runtime = null;
    protected Process m_process = null;

    protected int m_iTaskId = 0;
    protected Timestamp m_tStart;	/* when supposed to start */
    protected int m_iPriority;
    protected int m_iMaxSeconds;
    protected String m_sCommand;
    protected URI m_SourceArg = null;
    protected URI m_DestArg = null;
    protected URI m_ErrorArg = null;

    protected BufferedReader m_stdout = null;
    protected BufferedWriter m_dest = null;
    protected BufferedReader m_stderr = null;
    protected BufferedWriter m_error = null;
    protected BufferedWriter m_stdin = null;
    protected BufferedReader m_source = null;

    protected int m_iRunState; /* 1=notready 2=running 3=doneOK
				* 4=IOException 5=timedout*/
    static final public int NOTREADY = 1;
    static final public int RUNNING = 2;
    static final public int DONE_OK = 3; /* completed, but maybe with errors */
    static final public int DONE_IOEXCEPTION = 4;
    static final public int DONE_TIMEDOUT = 5;
    static final protected String[] s_sStateNames = 
	    { "Undefeind","NOTREADY","RUNNING","DONE_OK","DONE_IOEXCEPTION",
	      "DONE_TIMEOUT"};

	/** create a process.
	 *  @param iTaskId	id used to generate temp filenames, and to 
	 *			identify the task to the DB for taskRelease.
	 *  @param tStart	if not null, wait until that time to
	 *			start; else start immediately
	 */
    public ClientProcess(int iTaskId, String cmd, int iPriority, 
			 int iMaxSeconds,
			 Timestamp tStart, String sSourceArg, String sDestArg,
			 String sErrorArg)
	{
	m_runtime = Runtime.getRuntime();
	m_iTaskId = iTaskId;
	m_sCommand = cmd;
	m_iPriority = iPriority;
	m_iMaxSeconds = iMaxSeconds;
	java.util.Date now = new java.util.Date();
	m_tStart = (tStart == null) ? new Timestamp(now.getTime()) : tStart;
	m_process = null;
	m_iRunState = NOTREADY;
	try
	    {
	    m_SourceArg = ((sSourceArg == null) || (sSourceArg.length() == 0))
		? null : new URI(sSourceArg);
	    }
	catch (URISyntaxException e){}
	try
	    {
	    m_DestArg = ((sDestArg == null) || (sDestArg.length() == 0))
		? null : new URI(sDestArg);
	    }
	catch (URISyntaxException e){}
	try
	    {
	    m_ErrorArg = ((sErrorArg == null) || (sErrorArg.length() == 0))
		? null : new URI(sErrorArg);
	    }
	catch (URISyntaxException e){}
	}

	/** create a process.
	 *  @param iTaskId	id used to generate temp filenames.
	 *			In this case (locally-specified tasks) it
	 *			may be negative, meaning it's not known to the 
	 *			DB
	 *  @param arglist	comma-sep string of (possibly quoted)
	 *			string arguments which more-or-less
	 *			match those of the other ctor, as follows:
	 *			args[0] is command string without redirections
	 *			args[1] is priority from 0 to 10. Default=6
	 *			args[2] is max time to execute.
	 *				0, the default, is infinity
	 *			args[3] is start time
	 *			    which may be expressed in various forms:
	 *				"" => not specified
	 *				yyyy-mm-dd hh:mm:ss.hhhh is the 
	 *					'official' format
	 *				+nn[smhd] is nn seconds/minutes/hours
	 *					or days from now 
	 */
    public ClientProcess(int iTaskId,String arglist)
	{
	m_runtime = Runtime.getRuntime();
	m_iTaskId = iTaskId;
	java.util.Date now = new java.util.Date();
	String[] args = arglist.split("[,\"]");
	int argcnt = args.length;
		System.out.println("found "+args.length+" tokens");
	m_sCommand = args[0];
	m_iPriority = ((argcnt < 2) || (args[1].length() == 0))
	    ? 6 : Integer.parseInt(args[1]);
	m_iMaxSeconds = ((argcnt < 3) || (args[2].length() == 0))
	    ? 0 : Integer.parseInt(args[2]);
	m_tStart = interpretTimestampString((argcnt < 4) ? null :  args[3]);
	try
	    {
	    m_SourceArg = ((argcnt < 5) || (args[4].length() == 0))
		? null : new URI(args[4]);
	    }
	catch (URISyntaxException e){}
	try
	    {
	    m_DestArg = ((argcnt < 6) || (args[5].length() == 0))
		? null : new URI(args[5]);
	    }
	catch (URISyntaxException e){ System.out.println("URISyntaxException "+e.getMessage()); }
	try
	    {
	    m_ErrorArg = ((argcnt < 7) || (args[6].length() == 0))
		? null : new URI(args[6]);
	    }
	catch (URISyntaxException e){}
	m_process = null;
	m_iRunState = NOTREADY;
	}


   protected String createTempOutname()
	{
	    return "fred";
	}

	/** run the command.
	 *  Calling fn should have first checked isReadyToRun()
	 *  This method sets up stdin, stdout, stderr in accordance with
	 *  SourceArg, DestArg, and ErrorArg, respectively and, if
	 *  SourceArg scheme is 'rcp', this executes that before running
	 *  the process (throwing an IOException if error). 
	 */
    public void run() throws IOException
	{
	if ((m_iRunState == NOTREADY) && isReadyToRun())
	    {
	    try
		{
		String sourceScheme = null;
		if (m_SourceArg != null)
		    {
		    sourceScheme = m_SourceArg.getScheme();
		    System.out.println("SRC='"+m_SourceArg
				       +"', s='"+m_SourceArg.getScheme()
				       +"', a='"+m_SourceArg.getAuthority()
				       +"', h='"+m_SourceArg.getHost()
				       +"', p='"+m_SourceArg.getPath()
				       +"', q='"+m_SourceArg.getQuery()
				       +"', f='"+m_SourceArg.getFragment()
				       +"'");
		    if (sourceScheme.compareTo("rcp")==0)
			{
			String localFile = m_SourceArg.getPath();
			String remoteFile = m_SourceArg.getFragment();
			Process p 
			    = m_runtime.exec("rcp "+remoteFile+" "+localFile);
			try { p.waitFor(); }
			catch (InterruptedException e)
			    {
			    throw new IOException("rcp "+remoteFile+" "
						  +localFile+" was interrupted");
			    }
			if (p.exitValue() != 0)
			    throw new IOException("Unable to rcp "+remoteFile
						  +" "+localFile);
			}
		    else if (sourceScheme.compareTo("file")==0)
		        {
			String fileNm = m_SourceArg.getPath();
			try
			    {
			    m_source 
				= new BufferedReader(new FileReader(fileNm));
			    }
			catch (FileNotFoundException f)
			    {
			    throw new IOException("Input file "+fileNm
						  +" not found: "
						  +f.getMessage());
			    }
			}
		    }
		String outFileName = null;
		String errFileName = null;
		if (m_DestArg != null) 
		    {
		    System.out.println("DEST='"+m_DestArg.toString()
				       +"', s='"+m_DestArg.getScheme()
				       +"', a='"+m_DestArg.getAuthority()
				       +"', h='"+m_DestArg.getHost()
				       +"', p='"+m_DestArg.getPath()
				       +"', q='"+m_DestArg.getQuery()
				       +"', f='"+m_DestArg.getFragment()
				       +"'");
		    if (m_DestArg.compareTo("CON") == 0)
			m_dest 
			    = new BufferedWriter(new PrintWriter(System.out));
		    else if ((m_DestArg.getScheme() != null)
			     && (m_DestArg.getScheme().compareTo("file")==0))
			outFileName = m_DestArg.getPath();
		    else if (m_DestArg.compareTo("NUL")!=0)
			outFileName = createTempOutname();
		    }
		else
		    outFileName = createTempOutname();
		if (outFileName != null)
		    {
		    try
			{
			m_dest 
			    = new BufferedWriter(new FileWriter(outFileName));
			}
		    catch (IOException f)
			{
			throw new IOException("Output file "+outFileName
						  +" creation error: "+
						  f.getMessage());
			}
		    }
		if (m_ErrorArg != null) 
		    {
		    if (m_ErrorArg.compareTo("CON") == 0)
			{
			m_error 
			    = new BufferedWriter(new PrintWriter(System.err));
			}
		    else if ((m_ErrorArg.getScheme() != null)
			     && (m_ErrorArg.getScheme().compareTo("file")==0))
			errFileName = m_ErrorArg.getPath();
		    else if (m_ErrorArg.compareTo("NUL")!=0)
			errFileName = createTempOutname();
		    }
		else
		    errFileName = createTempOutname();
		if (errFileName != null)
		    {
		    try
			{
			m_error
			    = new BufferedWriter(new FileWriter(errFileName));
			}
		    catch (IOException f)
			{
			throw new IOException("Error file "+errFileName
						  +" creation error: "+
						  f.getMessage());
			}
		    }
		m_process = m_runtime.exec(m_sCommand);
		m_iRunState = RUNNING;
		if (m_source != null) // else no intput to process
		    m_stdin = new BufferedWriter(new OutputStreamWriter(m_process.getOutputStream()));
		m_stdout = new BufferedReader(new InputStreamReader(m_process.getInputStream()));
		m_stderr = new BufferedReader(new InputStreamReader(m_process.getErrorStream()));
		}
	    catch (IOException e)
		{
		m_iRunState = DONE_IOEXCEPTION;
		throw e;
		}
	    }
	}

	/** create and return a Timestamp based on a more general 
	 *  interpretation of a String than supported by valueOf()
	 *  @param str	The time to be represented as a Timestamp, which may be
	 *			null or empty => current time
	 *			+nn[smhd] => current time + specified number
	 *				of seconds/minutes/hours/days
	 *			=hh.mm => specified (24-hour system) time
	 *				for today if possible else tomorrow
	 *			yyyy-mm-dd hh:mm:ss.ffff canonical format
	 *			etc
	 *  @return		always returns some valid Timestamp
	 */
    protected Timestamp interpretTimestampString(String str)
	{
	java.util.Date now = new java.util.Date();
	Timestamp retval = null;
	if ((str == null) || (str.length() == 0))
	    retval =  new Timestamp(now.getTime()); 
	else if (str.startsWith("+"))
	    {
	    String unit = str.substring(3);
	    int count = Integer.parseInt(str.substring(1,3)); 
	    //	    String old = now.toString();
	    if (unit.compareTo("s")==0)
		now.setSeconds(now.getSeconds()+count);
	    else if (unit.compareTo("m")==0)
		now.setMinutes(now.getMinutes()+count);
	    else if (unit.compareTo("h")==0)
		now.setHours(now.getHours()+count);
	    else if (unit.compareTo("d")==0)
		now.setDate(now.getDate()+count);
	    //String newT = now.toString();
	    //	    System.out.println("interpretTimeStamp: '"+old+"'+'"+str+"'='"+newT+"'");
	    retval = new Timestamp(now.getTime()); 
	    }
	else if (str.startsWith("="))
	    {
	    int hour = Integer.parseInt(str.substring(1,3)); 
	    int minute = Integer.parseInt(str.substring(4)); 
	    int nowHour = now.getHours();
	    int nowMinute = now.getMinutes();
	    if ((nowHour > hour)
		    || ((nowHour == hour) && (nowMinute > minute)))
		now.setDate(now.getDate()+1);
	    now.setMinutes(minute);
	    now.setHours(hour);
	    String newT = now.toString();
	    System.out.println("interpretTimeStamp: '"+str+"'='"+newT+"'");
	    retval = new Timestamp(now.getTime()); 
	    }
	else
	    retval = Timestamp.valueOf(str);
	return retval;
	}

    public void destroy()
	{
	if (m_process != null)
	    {
	    m_process.destroy();
	    }
	}

	/** @return process exit value if process completed else runState
	 */
    public int exitValue()
	{
	return (m_iRunState == DONE_OK) ? m_process.exitValue() : m_iRunState;
	}

	/** return Timestamp of when process started
	 */
    public Timestamp startTime()
	{
	return m_tStart;
	}

	/** return number of seconds since process started
	 */
    public int getRunningSeconds()
	{
	java.util.Date now = new java.util.Date();
	return ((int)((now.getTime() - m_tStart.getTime()) / 1000));
	}

	/** return whether it has started
	 */
    public boolean isStarted()
	{
	return (m_process != null);
	}

	/** return whether it has finished ( for whatever reason)
	 */
    public boolean isFinished()
	{
	boolean bFinished = false;    
	if (m_iRunState > RUNNING)
	    bFinished = true;
	else if (m_process != null)
	    {
	    try
		{
		bFinished = true;
		m_iRunState = DONE_OK;
		}
	    catch(IllegalThreadStateException e) {}
	    try
		{
		    //		while (System.in.ready())
		    //  {
		    // String s = System.in.readLine();
		    // m_stdin.write(s,0,s.length());
		    // m_stdin.newLine();
		    // }
		if (m_dest != null)
		    {
		    while (m_stdout.ready())
		        {
			String s = m_stdout.readLine();
			//System.out.println("Outputting '"+s+"'");
			m_dest.write(s,0,s.length());
			m_dest.newLine();
			}
		    }
		if (m_error != null)
		    {
		    while (m_stderr.ready())
		        {
			String s = m_stderr.readLine();
			//	System.out.println("Outputting '"+s+"'");
			m_error.write(s,0,s.length());
			m_error.newLine();
			}
		    }
		}
	    catch(IOException e) {}
	    }
	return bFinished;
	}

	/** return whether it has overrun its time
	 */
    public boolean isTimedOut()
	{
	boolean bRetval = ((m_iMaxSeconds > 0) 
			   && (getRunningSeconds() > m_iMaxSeconds));
	if (bRetval)
	    m_iRunState = DONE_TIMEDOUT;
	return bRetval;
	}

	/** return whether it is ready to run (i.e. we are past the target
	 *  start time but it has not yet been run)
	 */
    public boolean isReadyToRun()
	{
	java.util.Date now = new java.util.Date();
	return ((m_process == null) && (m_tStart.getTime() <= now.getTime()));
	}

    public int getTaskId() { return m_iTaskId; }
    public int getRunState() { return m_iRunState; }
    public String getRunStateName() { return s_sStateNames[m_iRunState];}

	/** close down all processes, remote connections, etc
	 */
    protected void finalize() throws Throwable
	{
	    //	    System.out.println("ClientProcess::finalize");
	cleanup();
	}

    public void cleanup()
	{
	if (m_process != null)
	    m_process.destroy();
	try
	    {
	    if (m_stdout != null)
		m_stdout.close();
	    }
	catch(IOException e) {}
	try
	    {
	    if (m_stdin != null)
		m_stdin.close();
	    }
	catch(IOException e) {}
	try
	    {
	    if (m_stderr != null)
		m_stderr.close();
	    }
	catch(IOException e) {}
	try
	    {
	    if (m_dest != null)
		{
		m_dest.flush();
		m_dest.close();
		}
	    }
	catch(IOException e) {}
	try
	    {
	    if (m_error != null)
		m_error.close();
	    }
	catch(IOException e) {}
	try
	    {
	    if (m_source != null)
		m_source.close();
	    }
	catch(IOException e) {}
	}
    }

