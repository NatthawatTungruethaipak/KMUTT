/**  
 *   ApplicationManager.java
 *
 *   ~~ Copyright  2001-2014  by Goldin-Rudahl Associates
 *   ~~ EndC
 *
 *   Created by Sally Goldin, 10/5/2001
 *
 *   Modified for standalone use in CPE372 execise, 11 Nov 2017
 *
 *   $Id: ApplicationManager.java,v 1.20 2014/02/09 04:33:20 rudahl Exp $
 *   $Log: ApplicationManager.java,v $
 *
 */

package com.grs.gui;
import com.grs.gui.*;
import java.util.*;
import java.io.*;

/**
 * This class provides an application neutral location to store
 * references to classes needed not only by DragonUI but also
 * by other classes such as the those used by the JNI-invoked
 * JVM in the viewport. It offers static methods to set and
 * get these references.
 */
public class ApplicationManager
    {
    protected final static String VERSION = "6.4";

      /**
       * Text source
       */
    protected static I18NTextSource textSource = null;

    protected static long timeOffset = 0;

    protected static String modulePrefix = "";
    protected static String readPath = "";
    protected static String writePath = "";
    protected static String tempPath = "";
    protected static String systemPath = "";
    protected static String colorFilePath = "";
    protected static String homeDirectory = "";
    protected static String country = "EN";
    protected static String logFileName = "ApplicationManager.log";
    protected static Logger errorLogger = null;
    protected static ErrorDisplay errorDisplay = null;
    protected static MessageDisplay messageDisplay = null;
    protected static boolean bLogging = false;
    protected static DragonFileChooser inFileChooser = null;
    protected static DragonFileChooser patternFileChooser = null;
    protected static DragonFileChooser multiInFileChooser = null;
    protected static DragonFileChooser importFileChooser = null;
    protected static DragonFileChooser outFileChooser = null;
    protected static DragonFileChooser pathChooser = null;
    protected static DragonFontChooser fontChooser = null;
    protected static FontProcessor fontProcessor = null;      

      /**
       * Is there a message or error dialog showing.
       */
    protected static boolean bMessageDialogVisible = false;

    public static void setTextSource(I18NTextSource source)
        {
        textSource = source;
	}
    public static I18NTextSource getTextSource()
        {
	return textSource;
	}

    public static void setTimeOffset(long value)
        {
        timeOffset = value;
	}
    public static long getTimeOffset()
        {
        return timeOffset;
	}

    public static String getModulePrefix()
        {
	return modulePrefix;
	}

    public static void setModulePrefix(String value)
        {
	modulePrefix = value;
	}

    public static String getReadPath()
        {
	return readPath;
	}

    public static void setReadPath(String value)
        {
	readPath = value;
	}

    public static String getWritePath()
        {
	return writePath;
	}

    public static void setWritePath(String value)
        {
	writePath = value;
	}

    public static String getTempPath()
        {
	return tempPath;
	}

    public static void setTempPath(String value)
        {
	tempPath = value;
	}

    public static String getColorFilePath()
        {
	return colorFilePath;
	}

    public static void setColorFilePath(String value)
        {
	colorFilePath = value;
	}

    public static String getSystemPath()
        {
	return systemPath;
	}

    public static void setSystemPath(String value)
        {
	systemPath = value;
	}

    public static String getCountry()
        {
	return country;
	}

    public static void setCountry(String value)
        {
	country = value;
	}

    public static String getHomeDirectory()
        {
	return homeDirectory;
	}

    public static void setHomeDirectory(String value)
        {
	homeDirectory = value;
	}

    public static String getLogFileName()
        {
	return logFileName;
	}

    public static void setLogFileName(String value)
        {
	logFileName = value;
	}

    public static Logger getErrorLogger()
        {
	return errorLogger;
	}

    public static void setErrorLogger(Logger errLog)
        {
	errorLogger = errLog;
	}

    public static ErrorDisplay getErrorDisplay()
        {
	return errorDisplay;
	}

    public static void setErrorDisplay(ErrorDisplay display)
        {
	errorDisplay = display;
	}

    public static MessageDisplay getMessageDisplay()
        {
	return messageDisplay;
	}

    public static void setMessageDisplay(MessageDisplay display)
        {
	messageDisplay = display;
	}

    public static void setLogging(boolean bFlag)
        {
	bLogging = bFlag;
	}

    public static boolean isLogging()
        {
	return bLogging;
	}

    public static String getVersion()
        {
	return VERSION;
	}

    public static DragonFileChooser getInFileChooser()
        {
        return inFileChooser;
	}

    public static void setInFileChooser(DragonFileChooser chooser)
        {
        inFileChooser = chooser;
	}

    public static DragonFileChooser getMultiInFileChooser()
        {
        return multiInFileChooser;
	}

    public static void setMultiInFileChooser(DragonFileChooser chooser)
        {
        multiInFileChooser = chooser;
	}

    public static DragonFileChooser getImportFileChooser()
        {
        return importFileChooser;
	}

    public static void setImportFileChooser(DragonFileChooser chooser)
        {
        importFileChooser = chooser;
	}

    public static DragonFileChooser getPatternFileChooser()
        {
        return patternFileChooser;
	}

    public static void setPatternFileChooser(DragonFileChooser chooser)
        {
        patternFileChooser = chooser;
	}

    public static DragonFileChooser getOutFileChooser()
        {
        return outFileChooser;
	}

    public static void setOutFileChooser(DragonFileChooser chooser)
        {
        outFileChooser = chooser;
	}

    public static DragonFileChooser getPathChooser()
        {
        return pathChooser;
	}

    public static void setPathChooser(DragonFileChooser chooser)
        {
        pathChooser = chooser;
	}

    public static DragonFontChooser getFontChooser()
        {
        return fontChooser;
	}

    public static void setFontChooser(DragonFontChooser chooser)
        {
        fontChooser = chooser;
	}

    public static FontProcessor getFontProcessor()
        {
        return fontProcessor;
	}

    public static void setFontProcessor(FontProcessor processor)
        {
	fontProcessor = processor;
	}

    public static void setMessageDialogVisible(boolean flag)
        {
        bMessageDialogVisible = flag;
	}

    public static boolean isMessageDialogVisible()
        {
	return bMessageDialogVisible;
	}


    protected static String cvsInfo = null;
    protected static void setCvsInfo()
        {
        cvsInfo = "\n@(#)  $Id: ApplicationManager.java,v 1.20 2014/02/09 04:33:20 rudahl Exp $ \n";
	}
    }


