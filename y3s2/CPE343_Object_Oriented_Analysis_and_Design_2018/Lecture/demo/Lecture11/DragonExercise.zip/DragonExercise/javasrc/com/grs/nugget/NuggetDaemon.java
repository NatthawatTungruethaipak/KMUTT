/* NuggetDaemon is a class to access the nugget Mysql DB
 *
 * $Id: NuggetDaemon.java,v 1.2 2002/10/26 23:35:02 rudahl Exp $
 * $Log: NuggetDaemon.java,v $
 * Revision 1.2  2002/10/26 23:35:02  rudahl
 * clientdaemon almost done
 *
 * Revision 1.1  2002/10/16 23:04:04  rudahl
 * initial depost from closet-java1.4.1
 *
 *
 *-----------------------------------------------------------------
 * following s from Nugget.spec (07-Oct-2002)
 *
 * Server Daemon API
 * =================
 * 
 * The server daemon will include, for all supported communication
 * protocols, at least the following (in language-neutral pseudocode):
 * 
 * 	taskList taskSearch(qualifiers)
 * 
 * This will return from the DB those tasks which match the qualifiers,
 * plus any other constraints the server my impose. The 'qualifiers' is a
 * set of values, as detailed below, which correspond to a subset of the
 * columns of the DB and which may have context- and column-specific
 * semantics. Each task will include its (globally-unique) 'task
 * identifier' ('tid');
 * 
 * Generally, each active node should call this at least once every
 * e.g. 5 minutes, in order to be able to respond to high-priority tasks.
 * 
 * Qualifiers includes (refer to DB definition below):
 * 
 *    Priority		will return task with priority >= to specified value.
 * 		 	The specified value may never be higher than 6,
 * 			and should generally reflect the priority of the
 * 			highest currently-executing task on the node.
 * 
 *    Node		Name of this node, if we want to get only tasks
 * 			which specify either this node or '*'.
 * 			Should be used only by nodes which have some
 * 			specialized capability.
 * 
 *    Capability	Similar to 'Node', but names the capability.
 * 			TBD.
 * 
 * The returned tasklist will be ordered first in order of descending
 * priority, second in order of descending age. It should never include a
 * task which has already been rejected by this node.
 * 
 * 
 * 	BOOL taskAccept(tid)    
 * 
 * This will commit the client to performing the specified task, if the
 * task is still available.  The server will mark the task as being no
 * longer available (at least until a suitable timeout has occurred).
 * 
 * Function returns FALSE if specified task is no longer
 * available. Client MUST check this value.
 * 
 * 	BOOL taskRelease(tid,completionCode,result,log)
 * 
 * This indicates to the server that the client is finished with the
 * task. The completion code indicates either Success (the task was
 * completed successfully), Failure (client was unable to complete task
 * due to errors; this may have a range of values such as anything less
 * than 0), or Reject (client was unable to complete task for a non-error
 * reason such as pre-emption or pending shutdown). 'Result' and 'log'
 * are strings comparable to stdout and stderr; 'Result' is ignored if
 * 'completionCode' is 'Reject', and 'log' records the reason for the
 * release.
 * 
 * Function returns TRUE unless, for whatever reason, the server revoked
 * the acceptance in which case 'result' and 'log' are ignored. Probably
 * the client ignores this return value.
 * 
 * 	void releaseAllTasks()
 * 
 * This is equivalent to sending a 'Reject' for each task which the
 * client is currently marked as having accepted. Since client doesn't
 * need to know which tasks those are, this effectively serves as a reset
 * function, and should always be executed by client daemon on startup.
 * 
 * 	tid taskAdd(params)
 * 
 * Add a task to the DB, and return the task id if successful. 'Params'
 * is all necessary parameters for the DB.
 * 
 * Params consists of the following, where an indicated default means
 * that (depending on the language binding) it is permitted to omit the
 * parameter:
 * 
 *    Command			task to execute
 *    SourceArg (default='')	where the data comes from
 *    DestArg (dafault='')		where the data goes to
 *    ErrorArg (dafault='')	where the data goes to
 *    PreferredHost (dafault='')	'', node name, or '*'
 *    Capabilities (dafault='')	Special required capabilities. TBD.
 *    Priority (default=2)
 *    LatePriority (default=6)	priority to raise to if MaxStarttime is passed
 *    Deadline (default='')	time/date when completion required
 *    MaxStartTime (default=0)	max elapsed seconds before LatePriority is set
 *    MaxTime (default=3600)	max elapsed seconds before assuming 
 * 				the (client) node has gone south.
 *    Defer (default=FALSE)	Create task with 'tState'='d'. Must then 
 *     				activaste with taskReleaseDefer()
 *    At (default='')		Date/time when task should begin executing
 * 
 * 	Only one of the following two sets may be specified
 *    Dependents (default='')	string listing tids of tasks which cannot
 * 				start until this is finished. The processing
 * 				actually records this information in the
 * 				records of the specified tids, not in this one.
 *    Prerequisites (default='')   string listing tids of tasks which must
 * 				complete successfully before this one will run.
 *    
 * 
 * 	void taskReleaseDefer(tid,...)
 * 
 * Change the 'tState' of all specified tasks from 'd' to 's' or 'b' by
 * examing the prerequisites.
 * 
 * 	int taskQuery(tid)
 * 
 * Return the current execution state of the task, for administrative
 * purposes. Possible values (to be defined) include whether it is
 * waiting, executing, or completed and, if completed, its error return
 * value, or posibly task not found. This needs to be elaborated.
 * 
 * 	int taskKill(tid)
 * 
 * Remove a task from the DB. If unable to, return reason similar to
 * taskQuery(). This actually just sets 'tStatus' to 'k'.
 * 
 * 	record queryDB(tid)    
 * 	records queryDB(queryString)
 * 
 * For administrative and debugging purposes, these allows a client to
 * obtain raw table data about one or more tasks. The first form is for a
 * single known task, the second allows performing a raw SQL query (but
 * not modification) to the DB.
 * 
 * 	string taskVacuum(bAll,bVerbose)
 * 
 * Remove dead records from DB, and possibly examine and report on old
 * tasks.  Removes all tasks whose 'tStatus' == 'k' AND who are not in
 * any prerequisite list, and all references to those tasks in the logging
 * DB. If 'bAll' is TRUE, does the same for tasks with 'tStatus' == 's'
 * or 'e'. If 'bVerbose' is TRUE, reports on all non-removed tasks older
 * than 24-hours plus all 'e' or 's' tasks removed.
 * 
 * Returns '' unless 'bVerbose' is TRUE. 
 * 
 */

package com.grs.nugget;

import java.sql.*;
import java.util.*;
import java.text.*;
import java.net.*; /* malformedurl */
import java.rmi.*;
import java.rmi.server.*;
import java.rmi.registry.LocateRegistry;
import com.grs.dbi.*;

public class NuggetDaemon
    {

    protected AccessDb access = null;

	/* For administrative and debugging purposes, these allows a client to
	 * obtain raw table data about one or more tasks. 
	 */ 
	/** get from DB all matching tasks with no filtering
	 *  @return 	null if no match, or Vector of DbTaskRecords
	 */
    public Vector queryDB(String queryString)
	throws DbiException, SQLException
        {
        Vector v = null;
	if (access == null)
	    access = new AccessDb();
	try
	    {
	    v = access.query(queryString,
			     "com.grs.nugget.DbTaskRecord");
	    }
	catch (ClassNotFoundException e)
	    {
	    throw new DbiException("queryDB ClassNotFoundException:\n   "
				       +e.getMessage());
	    }
	catch (NoSuchMethodException e)
	    {
	    throw new DbiException("queryDB NoSuchMethodException:\n   "
				       +e.getMessage());
	    }
	return v;
	}

	/** get from DB the specified task
	 *  @return 	null if no match, or the DbTaskRecord
	 */
    public DbTaskRecord queryDB(int iTaskId)
	throws DbiException, SQLException
        {
        Vector v = queryDB("tID="+iTaskId);
	DbTaskRecord rec = ((v != null) && (v.size() == 1)) 
	    ? (DbTaskRecord)v.elementAt(0) : null;
	return rec;
	}

	/** get from DB taskID of all tasks which match the query
	 *  @return 	null if no match, or int[] of TaskIDs
	 */
    protected int[] getMatchingTasks(String queryString)
	throws DbiException, SQLException
        {
        Vector v = queryDB(queryString);
	int[] retval = new int[v.size()];
	for (int i=0; i<v.size(); i++)
	    {
	    DbTaskRecord r = (DbTaskRecord)v.elementAt(i);
	    int iTaskId = r.tID.getIntValue();
	    retval[i] = iTaskId;
	    }
	return retval;
	}

	/** get from DB the IDs of all tasks which are Prerequisites of
	 *  specified task
	 *  @return 	int[] of matches
	 */
    protected int[] getPrerequisites(int iTaskId)
	throws DbiException, SQLException
        {
        Vector v = null;
	if (access == null)
	    access = new AccessDb();
	try
	    {
	    v = access.query("tID="+iTaskId,
			     "com.grs.nugget.DbPrereqRecord");
	    }
	catch (ClassNotFoundException e)
	    {
	    throw new DbiException("queryDB ClassNotFoundException:\n   "
				       +e.getMessage());
	    }
	catch (NoSuchMethodException e)
	    {
	    throw new DbiException("queryDB NoSuchMethodException:\n   "
				       +e.getMessage());
	    }
	int[] retval = new int[v.size()];
	for (int i=0; i<v.size(); i++)
	    {
	    DbPrereqRecord r = (DbPrereqRecord)v.elementAt(i);
	    retval[i] = r.prereqID.getIntValue();
	    }
	return retval;
	}

	/** get from DB the IDs of all tasks which have specified task 
	 *  as a prerequisite
	 *  @return 	int[] of matches
	 */
    protected int[] getDependents(int iTaskId)
	throws DbiException, SQLException
        {
        Vector v = null;
	if (access == null)
	    access = new AccessDb();
	try
	    {
	    v = access.query("prereqID="+iTaskId,
			     "com.grs.nugget.DbPrereqRecord");
	    }
	catch (ClassNotFoundException e)
	    {
	    throw new DbiException("queryDB ClassNotFoundException:\n   "
				       +e.getMessage());
	    }
	catch (NoSuchMethodException e)
	    {
	    throw new DbiException("queryDB NoSuchMethodException:\n   "
				       +e.getMessage());
	    }
	int[] retval = new int[v.size()];
	for (int i=0; i<v.size(); i++)
	    {
	    DbPrereqRecord r = (DbPrereqRecord)v.elementAt(i);
	    retval[i] = r.tID.getIntValue();
	    }
	return retval;
	}

	/** changes state of matching tasks
	 *  @return 	count of changes
	 */
    protected int changeState(String searchString, String newState)
	throws DbiException, SQLException
        {
        Vector v = queryDB(searchString);
	int iRetval = 0;
	for (int i=0; i<v.size(); i++)
	    {
	    DbTaskRecord r = (DbTaskRecord)v.elementAt(i);
	    r.tState.setStringValue(newState);
	    try
		{
		if (access.update(r,"com.grs.nugget.DbTaskRecord") == 1)
		    iRetval++;
		}
	    catch (ClassNotFoundException e)
		{
		throw new DbiException("changeState ClassNotFoundException:\n "
				       +e.getMessage());
		}
	    catch (NoSuchMethodException e)
		{
		throw new DbiException("changeState NoSuchMethodException:\n  "
				       +e.getMessage());
		}
	    }
	return iRetval;
	}

     /* Change the 'tState' of all specified tasks from 'd' to 's' or 'b' by
      * examing the prerequisites.
      */
    public void taskReleaseDefer(int[] iTasks)
		throws DbiException, SQLException
	{
	for (int i=0; i<iTasks.length; i++)
	    {
	    int[] iPrereqs = getPrerequisites(iTasks[i]);
	    changeState("tID="+iTasks[i],(iPrereqs.length > 0) ? "b" : "r");
	    }
	}

     /** Get from the DB a vector of ClientTasks which match the qualifiers,
      *  plus any other constraints the server my impose. The 'qualifiers' is a
      *  set of values, as detailed below, which correspond to a subset of the
      *  columns of the DB and which may have context- and column-specific
      *  semantics. Each task will include its (globally-unique) 'task
      *  identifier' ('tid');
      *
      *  This doesn't yet handle capabilities.
      * 
      * @param	iPriority	minimul acceptable priority
      * @param	sPreferredNode	null, '','*', or same as sClientNode
      * @param	sClientNode	node name of client requesting this info
      * @return 		The returned tasklist will be ordered 
      *				first in order of descending priority, 
      *				second in order of descending age. 
      *				It should never include a task which has 
      *				already been rejected by this node.
      */
    public Vector taskSearch(int iPriority, String sPreferredNode,
			     String sClientNode)
		throws DbiException, SQLException
        {
	if (access == null)
	    access = new AccessDb();
        Vector v = null;
	String search = "";
	if (iPriority > 0) // else ignore
		search += "t.tPriority >= "+iPriority+" AND ";
	if ((sPreferredNode != null) && (sPreferredNode != "")) // else ignore
	    {
	    if (sPreferredNode != "*")
		search += "(t.tPreferredHost='*' "
		    +" OR t.tPreferredHost='"+sPreferredNode+"') AND ";
	    else
		search += "t.tPreferredHost='"+sPreferredNode+"' AND ";
	    }
	search += "t.tState = 'r' AND ";
	    // this IS NULL is a MySql work around for NOT EXISTS
	    // see MySql book1.html 1.4.4.1 sub-selects
	search += "  ( (e.eCompletionCode < 10 AND e.eNodename='"
		+sClientNode+"') OR ";
	search += "e.eTaskId IS NULL) ";
	    //search += "\n  NOT EXISTS (SELECT * FROM logging_events e ";
	    //search += "  WHERE e.eTaskId=t.tID AND eCompletionCode >= 10";
	    //search += "     AND eNode='"+sClientNode+"') ";
	search += "\n  ORDER BY tPriority DESC, tNewDate ASC ";
	try
	    {
	    v = access.query(search,"com.grs.nugget.ClientTaskRecord");
	    System.out.println("found "+v.size()+" records on search=\n  '"
			       +search+"'");
	    }
	catch (ClassNotFoundException e)
	    {
	    throw new DbiException("taskSearch ClassNotFoundException:\n   "
				       +e.getMessage());
	    }
	catch (NoSuchMethodException e)
	    {
	    throw new DbiException("taskSearch NoSuchMethodException:\n   "
				       +e.getMessage());
	    }
	return v;
	}

	/* Commit the client to performing the specified task, if the
	 * task is still available.  The server will mark the task as being no
	 * longer available (at least until a suitable timeout has occurred).
	 * 
	 * @return 	FALSE if specified task is no longer available.
	 *		Client MUST check this value.
	 */ 
    public boolean taskAccept(int iTaskId,
			      String sClientNode)
		throws DbiException, SQLException
	{
	boolean bRetval = false;
	System.out.println("NuggetDaemon::taskAccept id="+iTaskId);
	if (access == null)
	    access = new AccessDb();
	try
	    {
	    access.execute("LOCK TABLES tasks WRITE");
	    Vector v = queryDB("tState='r' AND tID="+iTaskId);
	    //    Vector v = access.query("WHERE tState='r' AND tID="+iTaskId,
	    //			    "com.grs.nugget.DbTaskRecord");
	    DbTaskRecord rec = new DbTaskRecord(iTaskId,"x",-1,sClientNode,
						null,0,null,null);
	    if ((v.size() == 1) // must be 0 or 1
		  && (access.update(rec,"com.grs.nugget.DbTaskRecord")==1))
		{
		bRetval= true;
		access.execute("UNLOCK TABLES");
		String cmd = rec.tCommand.getValue();
		DbEventRecord evRec = new DbEventRecord(iTaskId,cmd,
							sClientNode);
		access.insert(evRec,"com.grs.nugget.DbEventRecord");
		}
	    }
	catch (ClassNotFoundException e)
	    {
	    throw new DbiException("taskSearch ClassNotFoundException:\n   "
				       +e.getMessage());
	    }
	catch (NoSuchMethodException e)
	    {
	    throw new DbiException("taskSearch NoSuchMethodException:\n   "
				       +e.getMessage());
	    }
	finally
	    {
	    access.execute("UNLOCK TABLES");
	    }
	return bRetval;
	}

     /* Indicates to the server that the client is finished with the
      * task. The completion code indicates either Success (the task was
      * completed successfully), Failure (client was unable to complete task
      * due to errors; this may have a range of values such as anything less
      * than 0), or Reject (client was unable to complete task for a non-error
      * reason such as pre-emption or pending shutdown). 'Result' and 'log'
      * are strings comparable to stdout and stderr; 'Result' is ignored if
      * 'completionCode' is 'Reject', and 'log' records the reason for the
      * release.
      *
      * If completion code is either success or failure (but not reject),
      * then visit all tasks for which specified task was a prerequisite,
      * removing the PrerequisiteRecord and if appropriate
      * set the dependent task state to 'r' or '?'
      * 
      * @param iCompletionCode	<0 => error
      *				+1 => success
      *				>= 10 => rejected
      * @return			TRUE unless, for whatever reason, 
      *				the server revoked the acceptance in which 
      *				case 'result' and 'log' are ignored.
      */
    public boolean taskRelease(int iTaskId,int iCompletionCode,
			       String sClientNode,
			       String sResult,String sLog)
		throws DbiException, SQLException
	{
	boolean bRetval = false;
	System.out.println("NuggetDaemon::taskRelease id="+iTaskId);
	if (access == null)
	    access = new AccessDb();
	try
	    {
	    String state = (iCompletionCode == 1) ? "s" 
		: (iCompletionCode >= 10) ? "r" : "e" ;
	    java.util.Date nowD = new java.util.Date();
	    Timestamp now = new Timestamp(nowD.getTime());
	    DbTaskRecord rec = new DbTaskRecord(iTaskId,state,-1,null,
						now,iCompletionCode,
						sResult,sLog);
	    rec.dump("taskRelease");
	    Vector v = access.query("tState='x' AND tID="+iTaskId,
				    "com.grs.nugget.DbTaskRecord");
	    System.out.println("NuggetDaemon::taskRelease query count="
			       +v.size());
	    if ((v.size() == 1) // must be 0 or 1
		    && (access.update(rec,"com.grs.nugget.DbTaskRecord")==1))
		{
		bRetval = true;
		DbTaskRecord origRec = (DbTaskRecord)v.elementAt(0);
		Timestamp tStart = origRec.tStart.getTimeValue();
		long lDif = nowD.getTime() - tStart.getTime();
		DbEventRecord evRec = new DbEventRecord(iTaskId,sClientNode,
							(int)(lDif / 1000),
							iCompletionCode,sLog);
		evRec.dump("recording release");
		access.update(evRec,"com.grs.nugget.DbEventRecord");
		if (iCompletionCode < 10)
		    {
		    int[] iDependents = getDependents(iTaskId);
		    for (int i=0; i<iDependents.length; i++)
			{
			access.delete("tID="+iDependents[i]
				      +" AND prereqID="+iTaskId,
				      "com.grs.nugget.DbPrereqRecord");
			int[] iOtherPrereqs = getPrerequisites(iDependents[i]);
			if (iCompletionCode < 0)
			    {
			    for (int j=0; j<iOtherPrereqs.length; j++)
				access.delete("tID="+iDependents[i]
				      +" AND prereqID="+iOtherPrereqs[j],
				      "com.grs.nugget.DbPrereqRecord");
			    taskRelease(iDependents[i],+4,sClientNode,
					sResult,sLog);
			    }
			else if (iOtherPrereqs.length == 0)
			    changeState("tID="+iDependents[i],"r");
			}

		    }
		}
	    }
	catch (ClassNotFoundException e)
	    {
	    throw new DbiException("taskSearch ClassNotFoundException:\n   "
				       +e.getMessage());
	    }
	catch (NoSuchMethodException e)
	    {
	    throw new DbiException("taskSearch NoSuchMethodException:\n   "
				       +e.getMessage());
	    }
	return bRetval;
	}

     /* This is equivalent to sending a 'Reject' for each task which the
      * client is currently marked as having accepted. Since client doesn't
      * need to know which tasks those are, this effectively serves as a reset
      * function, and should always be executed by client daemon on startup.
      */
    public void releaseAllTasks(String sClientNode,String explain)
	throws DbiException, SQLException
	{
	if (access == null)
	    access = new AccessDb();
	try
	    {
	    Vector v = access.query("tState='x' AND "
				    +"tNode='"+sClientNode+"'",
				    "com.grs.nugget.DbTaskRecord");
	    for (int i=0; i<v.size(); i++)
		{
		DbTaskRecord r = (DbTaskRecord)v.elementAt(i);
		int iTaskId = r.tID.getIntValue();
		taskRelease(iTaskId,99,sClientNode,explain,null);
		}
	    }
	catch (ClassNotFoundException e)
	    {
	    throw new DbiException("taskSearch ClassNotFoundException:\n   "
				       +e.getMessage());
	    }
	catch (NoSuchMethodException e)
	    {
	    throw new DbiException("taskSearch NoSuchMethodException:\n   "
				       +e.getMessage());
	    }
	}

     /* Add a task to the DB, and return the task id if successful. 'Params'
      * is all necessary parameters for the DB.
      * 
      * Params consists of the following, where an indicated default means
      * that (depending on the language binding) it is permitted to omit the
      * parameter:
      * 
      * @param	bDefer 		Create task with 'tState'='d'.
      * @param	sCommand (REQ)	task to execute
      * @param	sSourceArg 	null or where the data comes from
      * @param	sDestArg	null or where the data goes to
      * @param	sErrorArg	null or where the data goes to
      * @param 	tTimeArg	Date/time when task should begin executing
      *	@param  sCreator (REQ)	node name of creator
      * @param	sPreferredHost	null,'', node name, or '*'
      * @param	sCapabilities 	null or Special required capabilities
      * @param	iPriority 	0 to 10
      * @param	tDeadline	null|time/date when completion required
      * @param	iLatePriority	priority to raise to if MaxStarttime is passed
      * @param	iMaxStartTime	max elapsed seconds before LatePriority is set
      * @param	iMaxTime	max elapsed seconds before assuming 
      * 			the (client) node has gone south.
      * 	Only one of the following two sets may be specified
      * @param 	Dependents[] 	null or int array of tids of tasks which 
      * 			cannot start until this is finished. 
      * @param	Prerequisites[] null or int array of tids of tasks which must
      * 			complete successfully before this one will run.
      */
    public int taskAdd(boolean bDefer,     // tState initial state 'r' or 'd'
		       String sCommand,		// the task to be executed
		       String sSourceArg,	// optional input source
		       String sDestArg, 	// optional result destination
		       String sErrorArg, 	// optional where to put stderr
		       Timestamp tTimeArg,	// time to begin, or null
		       String sCreator,		// ** node which created task
		       String sPreferredHost,	// '' or node or *
		       String sCapabilities,	// special capabilities reqd
		       int iPriority,		// ** integer val from 0 to 10
		       Timestamp tDeadline,	// date when task must be done
		       int iLatePriority,	// same vals as 'tPriority'
		       int iMaxStartTime,	// seconds b4 first taskAccept
		       int iMaxTime,	 	// max secs a node is permitted
		       int[] Dependents,
		       int[] Prerequisites)
		throws DbiException, SQLException
	{
        int iRetval = -1;
	if (access == null)
	    access = new AccessDb();
	if ((Dependents != null) && (Prerequisites != null))
	    throw new DbiException("taskAdd cannot have both dependents and prerequisites");
	try
	    {
	    DbTaskRecord newRec 
		= new DbTaskRecord((bDefer) ? "d"
				   : (Prerequisites == null) ? "r" : "b",
				   sCommand,
				   sSourceArg,
				   sDestArg,
				   sErrorArg,
				   tTimeArg,
				   sCreator,
				   sPreferredHost,
				   sCapabilities,
				   iPriority,
				   tDeadline,
				   iLatePriority,
				   iMaxStartTime,
				   iMaxTime);
	    iRetval = access.insert(newRec,"com.grs.nugget.DbTaskRecord");
	    if (iRetval > 0)	// it is the new taskid
		{
		if (Dependents != null)
		    {
		    for (int i=0; i<Dependents.length; i++)
			{
			DbPrereqRecord pRec
			    = new DbPrereqRecord(Dependents[i],iRetval);
			access.insert(pRec,"com.grs.nugget.DbPrereqRecord");
			}
		    }
		else if (Prerequisites != null)
		    {
		    for (int i=0; i<Prerequisites.length; i++)
			{
			DbPrereqRecord pRec
			    = new DbPrereqRecord(iRetval,Prerequisites[i]);
			access.insert(pRec,"com.grs.nugget.DbPrereqRecord");
			}
		    }
		
		}
	    }
	catch (ClassNotFoundException e)
	    {
	    throw new DbiException("taskSearch ClassNotFoundException:\n   "
				       +e.getMessage());
	    }
	catch (NoSuchMethodException e)
	    {
	    throw new DbiException("taskSearch NoSuchMethodException:\n   "
				       +e.getMessage());
	    }
	return iRetval;
	}

     /* Remove a task from the DB. If unable to, return reason similar to
      * taskQuery(). This actually just sets 'tStatus' to 'k'.
      * @return		at present, just count of items changed
      */
    public int taskKill(int iTaskId)
		throws DbiException, SQLException
	{
	return (changeState("tID="+iTaskId,"k"));
	}

     /* Remove dead records from DB, and possibly examine and report on old
      * tasks.  Removes all tasks whose 'tStatus' == 'k' AND who are not in
      * any prerequisite list, and all references to those tasks in the logging
      * DB. If 'bAll' is TRUE, does the same for tasks with 'tStatus' == 's'
      * or 'e'. If 'bVerbose' is TRUE, reports on all non-removed tasks older
      * than 24-hours plus all 'e' or 's' tasks removed.
      * 
      * @return		 '' unless 'bVerbose' is TRUE. 
      */
    public String taskVacuum(boolean bAll,boolean bVerbose)
		throws DbiException, SQLException
	{
	String retval = "";
	try
	    {
	    int[] iDeadies = getMatchingTasks("tState='k'");
	    for (int i=0; i<iDeadies.length; i++)
		{
		int[] iDependents = getDependents(iDeadies[i]);
		if (iDependents.length == 0)
		    {
		    access.delete("tID="+iDeadies[i],
				  "com.grs.nugget.DbTaskRecord");
		    access.delete("eTaskId="+iDeadies[i],
				  "com.grs.nugget.DbEventRecord");
		    }
		}
	    if (bAll)
		{
		iDeadies = getMatchingTasks("tState='e' OR tState='s'");
		for (int i=0; i<iDeadies.length; i++)
		    {
		    int[] iDependents = getDependents(iDeadies[i]);
		    if (iDependents.length == 0)
			{
			access.delete("tID="+iDeadies[i],
				      "com.grs.nugget.DbTaskRecord");
			access.delete("eTaskId="+iDeadies[i],
				      "com.grs.nugget.DbEventRecord");
			if (bVerbose)
			    retval += "Removed "+iDeadies[i]+"\n";
			}
		    }
		}
	    if (bVerbose)
		{
		int[] iTiredies 
		    = getMatchingTasks("tNewDate<DATE_SUB(NOW(),INTERVAL 1 DAY)");
		for (int i=0; i<iTiredies.length; i++)
		    {
		    retval += "Didn't remove old task "+iTiredies[i]+"\n";
		    }
		}
	    }
	catch (ClassNotFoundException e)
	    {
	    throw new DbiException("taskSearch ClassNotFoundException:\n   "
				       +e.getMessage());
	    }
	catch (NoSuchMethodException e)
	    {
	    throw new DbiException("taskSearch NoSuchMethodException:\n   "
				       +e.getMessage());
	    }
	return retval;
	}

	/** constructor creates daemon and registers with rmi
	 */
    public NuggetDaemon()
	throws RemoteException, MalformedURLException// , NotBoundException
	{
	//System.out.println("Remote Workstation Server: Version "+VERSION_NUM);
	// Look for resource file 'nugget.properties'
        ResourceBundle bundle = ResourceBundle.getBundle("nugget");
        String portNum = bundle.getString("server.portnum");
        String hostName = bundle.getString("server.hostname");
        String clients = bundle.getString("server.authorizedClients");
	if (hostName == null)
            {
	    System.out.println("Host name must be specified in property file");
	    return;
	    }
	if (portNum == null)
            {
	    System.out.println("Port number not found in property "
			       +"file - using 11000");
	    portNum = "11000";
	    }
	LocateRegistry.createRegistry(Integer.parseInt(portNum));
	System.out.println( "Registry created on host computer "+hostName
			    +" on port "+portNum);

	// Create a remote NuggetServer object
	NuggetServer server = new NuggetServerImpl(this);
	System.out.println( "Nugget Server implementation object created" );
	String urlString = "//"+hostName+":"+portNum+"/"+"NuggetServer";
	Naming.rebind(urlString, server);
	}

    public static void main(String args[])
	{
	int iArgno = 0;
	boolean bExplain = false;
	NuggetDaemon nd = null;
	try
	    {
	    nd = new NuggetDaemon();
	    }

	catch ( RemoteException re )
            {
	    System.out.println( "ERROR:NOSTART Starting service\n  "
				+re.getMessage() );
	    }
	catch ( MalformedURLException mURLe )
            {
	    System.out.println( "ERROR:BADURL " + mURLe.getMessage() );
	    }
	/*
	catch ( java.rmi.UnknownHostException uhe )
	    {
	    System.out.println( "ERROR:BADHOST The server computer name "
				+hostName+" does not match actual server." );

	    }
	catch ( NotBoundException nbe )
            {
	    System.out.println( "ERROR:OBJNOTBND " + nbe.getMessage());
	    }
	*/
	//    set the security manager to the RMISecurityManager
	System.setSecurityManager( new RMISecurityManager() );
	if (nd == null)
	    System.exit(1);
	/*
	try
	    {
	    Vector v = nd.taskSearch(2,"*","closet");
	    System.out.println("found "+v.size()+" ClientTaskRecords");
	    for (int i=0; i<v.size(); i++)
		{
		DbRecord r = (DbRecord)v.elementAt(i);
		r.dump("NuggetDaemon test using ClientTaskRecord");
		}
	    String vac = nd.taskVacuum(true,true);
	    System.out.println("vac='"+vac+"'");
	    }
	catch (DbiException de)
	    {
	    System.out.println("NuggetDaemon main() DbiException:\n   "
			       +de.getMessage());
	    de.printStackTrace();
	    }
	catch (SQLException e)
	    {
	    System.out.println("NuggetDaemon main() SQLException:\n   "
			       +e.getMessage());
	    e.printStackTrace();
	    }

	Properties p = System.getProperties();
	//	p.list(System.out);
	try
	    {
	    AccessDb access = new AccessDb();
	    int st;
	    st = access.insert(new DbTaskRecord("r",
						"tstCom", // task to be exec
						null,   // opt. input src
						null,   // opt. result dest
						null,   // optional stderr
						null,   // time to begin, or null
						"closet", // node which created task
						"*",    // '' or node or *
						null,   // special capabi reqd
						6,      // int value from 0-10
						null,   // date task must be done
						8,	// latePriority
						300,	// secs b4 1st taskAcc
						3600),  //max secs node is perm
			  "com.grs.nugget.DbTaskRecord");
	    System.out.println("Insert status="+st);

	    Vector v = access.query("tID >= 0","com.grs.nugget.DbTaskRecord");
	    System.out.println("found "+v.size()+" records");

	    for (int i=0; i<v.size(); i++)
		{
		DbRecord r = (DbRecord)v.elementAt(i);
		//		r.dump("NuggetDaemon test using DbTaskRecord");
		}
	    st = access.delete("tID=89","com.grs.nugget.DbTaskRecord");
	    System.out.println("Delete status="+st);
	    }
        catch (Exception e)
	    {
            e.printStackTrace();
	    }
	*/
	}

    }
