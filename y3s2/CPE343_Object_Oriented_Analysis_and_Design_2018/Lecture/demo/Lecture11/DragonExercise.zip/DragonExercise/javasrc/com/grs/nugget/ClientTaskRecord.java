/* ClientTaskRecord is an object which represents 
 * the client view of a record from the tasks table.
 * It contains only a subset on DbTaskRecord; has no INSERT/UPDATE/DELETE,
 * but does reference the events table.
 *
 * $Id: ClientTaskRecord.java,v 1.2 2002/10/26 23:35:02 rudahl Exp $
 * $Log: ClientTaskRecord.java,v $
 * Revision 1.2  2002/10/26 23:35:02  rudahl
 * clientdaemon almost done
 *
 * Revision 1.1  2002/10/16 23:04:04  rudahl
 * initial depost from closet-java1.4.1
 *
 */

package com.grs.nugget;

import java.sql.*;
import java.util.*;
import java.text.*;
import com.grs.dbi.*;

public class ClientTaskRecord extends DbRecord
    {
    public DbField tID 
	= new DbField("tID","","Task", DbField.DBV_INT,"");
    public DbField tCommand 
	= new DbField("tCommand","","Command", DbField.DBV_STRING,
		      "the task to be executed");
    public DbField tSourceArg 
	= new DbField("tSourceArg","","SourceArg",DbField.DBV_STRING,
		      "optional input source");
    public DbField tDestArg 
	= new DbField("tDestArg","","DestArg",DbField.DBV_STRING,
		      "optional result destination");
    public DbField tErrorArg 
	= new DbField("tErrorArg","","ErrorArg",DbField.DBV_STRING,
		      "optional, where to put stderr");
    public DbField tTimeArg 
	= new DbField("tTimeArg","","Start At", DbField.DBV_TIMESTAMP,
		      "when task should begin, or NULL");
    public DbField tPreferredHost 
	= new DbField("tPreferredHost","","PrefHost",DbField.DBV_STRING,
		      "empty or name of a node or *");
    public DbField tCapabilities 
	= new DbField("tCapabilities","","Capabilities",DbField.DBV_STRING,
		      "special capabilities reqd");
    public DbField tMaxTime 
	= new DbField("tMaxtime","","Max Time", DbField.DBV_INT,
		      "max seconds a node is permitted after some node has "
		      +"executed taskAccept for the task");
		      // following init by taskAdd or server
		      // may change over time.
    public DbField tNewDate 
	= new DbField("tNewDate","","Created At", DbField.DBV_TIMESTAMP,
		      "when task was added. Never changes");
    public DbField tPriority 
	= new DbField("tPriority","","Priority", DbField.DBV_INT,
		      "integer value from 0 to 10");

	/** This constructor, combined with init(ResultSet),
	 *   is used for reading from the DB
	 */
    public ClientTaskRecord() throws DbiException  { super(); init(); } 

    public void init(ResultSet result) throws SQLException, DbiException
	{
	super.init(result);
	}

	/** Return a string which is the first part of an SQL query
	 *  appropriate to this class and associated DB table(s)
	 */ 
    public static String getQueryString() 
	{
	    // this LEFT JOIN is a MySql work around for EXISTS
	    // see MySql book1.html 1.4.4.1 sub-selects
	return "SELECT tID, tCommand, tSourceArg, tDestArg, tErrorArg,"
		+" tPreferredHost, tCapabilities, tMaxTime, tNewDate,"
	        +"tPriority "
	        +"\n  FROM tasks t "
	        +"LEFT JOIN logging_events e ON t.tID=e.eTaskId ";
	}

    public void dump(String czTitle)
	{
	System.out.println("Dump of ClientTaskRecord "+czTitle);
	System.out.println(toString());
	}
    }
