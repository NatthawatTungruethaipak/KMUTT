/**
 * CharacterMap.java
 *
 *  Copyright  2002-2007  by Goldin-Rudahl Associates
 *
 *  Created 6/13/02 by Sally Goldin
 *
 *  $Id: CharacterMap.java,v 1.2 2007/01/05 07:41:58 rudahl Exp $
 *  $Log: CharacterMap.java,v $
 *  Revision 1.2  2007/01/05 07:41:58  rudahl
 *  added Whatis info
 *
 *  Revision 1.1  2002/06/13 22:01:38  goldin
 *  New class to display chars in chosen font
 *
 */

package com.grs.i18n;
import com.grs.gui.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.util.*;

/**
 * This is a simple application that allows the user to select
 * a font and a starting value and then displays a table of
 * 256 characters in that font, starting with that number.
 */
public class CharacterMap extends JFrame
                          implements ActionListener
    {
    protected Vector columnNameVector = null;

      /**
       *  Font chooser to allow font selection
       */
    protected DragonFontChooser fontChooser = null;

      /**
       * Currently selected Font object
       */
    protected Font currentFont = null;

      /**
       * Button to select font.
       */
    protected JButton fontButton = null;
   
      /**
       * Button to update table
       */
    protected JButton updateButton = null;

      /**
       * Field for entering start of character range
       */
    protected JTextField startField = null;

      /**
       * Table for displaying the characters
       */
    protected JTable charTable = null;


    protected Vector tableRows = null;

      /**
       * Constructor builds the UI. The main method
       * displays it.
       */
    public CharacterMap()
        {
        super("Character Map Application");
	JPanel mainPanel = new JPanel(new BorderLayout());
	JPanel controlsPanel = new JPanel(new FlowLayout());
	fontButton = new JButton("Choose Font");
	fontButton.addActionListener(this);
	updateButton = new JButton("Update Table");
	updateButton.addActionListener(this);
	JPanel fieldPanel = new JPanel(new BorderLayout());
	fieldPanel.setBorder(BorderFactory.createEmptyBorder(20,20,20,20));
	fieldPanel.add(new JLabel("Start of character range"),
		       BorderLayout.NORTH);
	startField = new JTextField(5);
	startField.setText("0x20");
	fieldPanel.add(startField, BorderLayout.SOUTH);
	controlsPanel.add(fieldPanel);
	controlsPanel.add(fontButton);
	controlsPanel.add(updateButton);
	mainPanel.add(controlsPanel, BorderLayout.NORTH);
        fontChooser = new DragonFontChooser(this,
				  new I18NTextSource());
	setCurrentFont(fontChooser.getCurrentDefault());
	charTable = new JTable();
        JScrollPane scroller = new JScrollPane(charTable);
        scroller.setHorizontalScrollBarPolicy(
		   ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
        scroller.setVerticalScrollBarPolicy(
                   ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
	mainPanel.add(scroller, BorderLayout.CENTER);
        getContentPane().add(mainPanel,BorderLayout.CENTER);
        columnNameVector = new Vector(33);
	columnNameVector.add("Character Value");
	for (int i = 0; i < 32; i++)
	     {
	     String hexVal = Integer.toString(i,16).toUpperCase();
	     if (hexVal.length() == 1)
                 columnNameVector.add("0x0" + hexVal);
	     else
                 columnNameVector.add("0x" + hexVal);
	     }
	charTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        updateCharacterMap();

	}

       /**
	* Parse string to create/set currentFont object. String is
	* Family-Style-Size
	* @param fontString Description of font to set.
	*/
    protected void setCurrentFont(String fontString)
        {
	String family = "Lucida Sans Unicode";
	String style = "Plain";
	int size = 10;
	StringTokenizer tokenizer = new StringTokenizer(fontString,"-");
	int which = 0;
	while (tokenizer.hasMoreTokens())
	    {
	    String token = tokenizer.nextToken();
	    switch (which)
	        {
		case 0: family = token; break;
		case 1: style = token; break;
		case 2: size = Integer.parseInt(token); break;
	        }
	    which++;
	    }
	int styleIndex = 0;
	for (int i=0; i < DragonFontChooser.styles.length; i++)
	    {
	    if (style.compareTo(DragonFontChooser.styles[i]) == 0)
		{
		styleIndex = i;
		break;
		}
	    }
        currentFont = new Font(family,
			       DragonFontChooser.styleConstants[styleIndex],
			       size);
	}

	/**
	 * Method from ActionListener
	 */
    public void actionPerformed(ActionEvent ev)
        {
	Object source = ev.getSource();
	if (source == fontButton)
	    {
	    String newFont = fontChooser.chooseFont("Select Font");
	    if (newFont != null)  // might have cancelled
                setCurrentFont(newFont);
	    }
	else if (source == updateButton)
	    {
	    updateCharacterMap();
	    }
        }

       /**
        * Display the appropriate values in the character map
	* table 
	*/
    protected void updateCharacterMap()
        {
	int startingValue = 32;
	int index =0;
        if (tableRows == null)
	    tableRows = new Vector(10);
	else
            tableRows.clear();
        Vector rowVector = null;
        char cValue[] = new char[2];
        cValue[1] = 0x20;
	charTable.setFont(currentFont);
	String startText = startField.getText().toLowerCase();
        try   // allow either hex or decimal input
	    {
	    int pos = -1;
	    if ((pos = startText.indexOf("x")) >= 0)
	        startingValue = Integer.parseInt(
			     startText.substring(pos+1),16);
	    else
	        startingValue = Integer.parseInt(startText);
	    }
	catch (NumberFormatException nfe)
	    {
            
	    JOptionPane.showMessageDialog(this,
					  "Bad starting value; using 0x20");
	    startingValue = 32;
	    }

	for (index = startingValue; index < startingValue + 256; index++)
	    {
	    if ((index - startingValue) % 32 == 0)  // new row
	        {
		rowVector = new Vector(33);
		rowVector.add("0x" + Integer.toString(index,16));
		tableRows.add(rowVector);
		}
	    cValue[0] = (char) index;
	    rowVector.add(new String(cValue));
	    }
        charTable.setModel(new DefaultTableModel(tableRows,columnNameVector));
	FontMetrics fm = charTable.getFontMetrics(currentFont);
	charTable.setRowHeight(fm.getHeight());
	TableColumnModel tcm = charTable.getColumnModel();
	for (int col = 0; col < 33; col++)
	    tcm.getColumn(col).setMinWidth(
                 fm.stringWidth((String)columnNameVector.get(col)));
	}

    /**
     * Driver routine starts and displays the application.
     * Allow user to kill with the button at upper left of window.
     */
    public static void main(String Args[])
        {
	try
	    { 
	    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
	    }
	catch (Exception e)
   	    {
	    System.out.println("Error setting look and feel");
	    }

	CharacterMap cmap = new CharacterMap();
	cmap.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	cmap.setSize(700,350);
        Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
        cmap.setLocation((int)(screen.width * .4),(int)(screen.height * .4));
        cmap.setVisible(true);
	}


    protected static String cvsInfo = null;
    protected static void setCvsInfo()
        {
        cvsInfo = "\n@(#)  $Id: CharacterMap.java,v 1.2 2007/01/05 07:41:58 rudahl Exp $ \n";
	}
    }




