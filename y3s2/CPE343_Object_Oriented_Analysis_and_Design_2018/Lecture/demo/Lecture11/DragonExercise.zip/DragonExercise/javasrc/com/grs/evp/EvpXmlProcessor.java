/*
 *   EvpXmlProcessor
 *
 *     Created by S.Goldin
 *
 *    $Id: EvpXmlProcessor.java,v 1.2 2004/03/02 10:39:44 rudahl Exp $
 *
 *    $Log: EvpXmlProcessor.java,v $
 *    Revision 1.2  2004/03/02 10:39:44  rudahl
 *    convert XML to DOM, and output new data file
 *
 *    Revision 1.1  2004/02/24 12:25:11  rudahl
 *    Developing for Release 1
 *
 *     
 *
 */
package com.grs.evp;

import com.grs.util.XMLDomIO;
import java.io.*;
import java.util.*;
import java.net.*;
import org.jdom.*;
import org.xml.sax.*;
import org.xml.sax.helpers.*;

/**
 *
 */
class EvpXmlProcessor extends DefaultHandler
    {
    /**
     * String constants for elements and attributes in metaData
     */
    private static final String DATASET = "dataset";
	private static final String SYMBOL = "symbol";
	private static final String FIRSTSAMPLE = "firstSample";
	private static final String COUNT = "count";
    private static final String CHANNEL = "channel";
	private static final String COLUMN = "column";
	private static final String NAME = "name";
	private static final String TYPE = "type";
    private static final String DATESTR = "datestr";
	private static final String FORMAT = "format";
	private static final String MINAXIS = "minAxis";
	private static final String MAXAXIS = "maxAxis";
	private static final String MINVAL = "minVal";
	private static final String MAXVAL = "maxVal";
    private static final String FLOAT = "float";

    private GnuPlotGraphDatasource parentDatasource = null;

    protected Document xmlDocument = null;

    private ChannelData currentChannel = null;
    private String currentName = null;
    private int currentDataType = -1;
    private String currentDateFormat = null;
    /** Xerces main SAX parser class */
    //    private final static String PARSERCLASS = "org.apache.xerces.parsers.SAXParser";
    // private final static String PARSERCLASS = "javax.xml.parsers.SAXParser";

    /** constructor sets the parent data source 
     */
    EvpXmlProcessor(GnuPlotGraphDatasource parentDatasource) 
        {
	this.parentDatasource = parentDatasource;
	}

    /**
     * This method will be called to parse the xml from an input stream reader
     * The returned JDOM document will be saved in the xmlDocument instance
     * variable.
     * @param iStream  Holds the data to be parsed
     * @throws         IO or JDOM exception
     */
    public void parse(InputStreamReader iStream)
	throws JDOMException, IOException, Exception 
	{
	xmlDocument = XMLDomIO.parse(iStream);
	processDataset();
        }

    /**
     * Read through the document content and set all the
     * metadata.
     * @throw  An Exception if the document structure does not match
     *         what we expect.
     */
    private void processDataset() throws Exception
        {
	List topLevelChildren = xmlDocument.getContent();
	if (topLevelChildren == null)
	    {
	    throw new Exception("No content in document?");
	    }
	Object o = topLevelChildren.get(0);
	if (!(o instanceof Element)) 
	    {
	    throw new Exception("Top level of document is a " 
				+ o.getClass().getName() 
				+ " rather than an element");
 	    }
	Element dataset = (Element)o;
        if (!dataset.getName().equalsIgnoreCase(DATASET)) 
	    {
	    throw new Exception("Top level element of document is a '" 
				+ dataset.getName()
				+ "' rather than a 'dataset'");
	    }
	descendTree(dataset);
	}

    /**
     * Recursive method to descend through the tree,
     * calling processElement for each element found.
     * @param  o   Object to use for descent. Should be Element.
     * @throws     Exception if something bad occurred. 
     */
    private void descendTree(Object o) throws Exception
        {
	if (!(o instanceof Element))
	    return;
	Element element = (Element) o;
	processElementStart(element);
	List children = element.getChildren();
	if (children == null)
	    return;
	Iterator iterator = children.iterator();
	while (iterator.hasNext())
	    {
	    descendTree(iterator.next());
	    }
	processElementEnd(element);
        }
    
    /**
     * Process the current element and its attributes,
     * if it is one of the ones in which we are interested.
     * @param  element    The current element to be processed.
     */
    private void processElementStart(Element element)
        {
        String qName = element.getName();
        if (qName.equalsIgnoreCase(DATASET))
            {	
	    HashMap attributeMap = attributesToHash(element);
            String at = (String) attributeMap.get(SYMBOL);
            parentDatasource.setSymbol(at);
	    at = (String) attributeMap.get(FIRSTSAMPLE);
	    parentDatasource.setFirstSample(Integer.parseInt(at));
	    at = (String) attributeMap.get(COUNT);
	    parentDatasource.setSampleCount(Integer.parseInt(at));
	    }
	else if (qName.equalsIgnoreCase(CHANNEL))
	    {
	    HashMap attributeMap = attributesToHash(element);
	    String at = (String) attributeMap.get(COLUMN);
	    currentChannel = parentDatasource.getChannelData(
		Integer.parseInt(at));
	    currentName = null;
	    currentDataType = -1;
	    currentDateFormat = null;
	    at = (String) attributeMap.get(NAME);
	    currentName = at;
	    at = (String) attributeMap.get(TYPE);
	    if (at.equalsIgnoreCase(DATESTR))
	        {
		currentDataType = ChannelData.DATE;
		}
	    else if (at.equalsIgnoreCase(FLOAT))
	        {
		currentDataType = ChannelData.FLOAT;
		}
	    }
	else if (qName.equalsIgnoreCase(DATESTR))
	    {
	    HashMap attributeMap = attributesToHash(element);
	    String at = (String) attributeMap.get(FORMAT);
	    currentDateFormat = at;
	    at = (String) attributeMap.get(MINAXIS);
	    currentChannel.setMinAxis(at);
	    at = (String) attributeMap.get(MAXAXIS);
	    currentChannel.setMaxAxis(at);
	    } 
	else if (qName.equalsIgnoreCase(FLOAT))
	    {
	    HashMap attributeMap = attributesToHash(element);
	    String at = (String) attributeMap.get(MINAXIS);
	    currentChannel.setMinAxis(at);
	    at = (String) attributeMap.get(MAXAXIS);
	    currentChannel.setMaxAxis(at);
	    at = (String) attributeMap.get(MINVAL);
	    currentChannel.setMinVal(at);
	    at = (String) attributeMap.get(MAXVAL);
	    currentChannel.setMaxVal(at);
	    }
	}

    /**
     * Turn the attributes of an element into a hashmap,
     * keyed by the attribute names.
     * @param  element   Element whose attributes should be processed
     * @return           HashMap of all attributes; empty if no attributes
     */
    private HashMap attributesToHash(Element element)
        {
	HashMap map = new HashMap();
	List attributes = element.getAttributes();
	if (attributes != null)
	    {
	    Iterator it = attributes.iterator();
	    while (it.hasNext())
		{
		Attribute att = (Attribute) it.next();
		map.put(att.getName(),att.getValue());
		}
	    }
	return map;
	}

    /** 
     * This method is called to do any final processing before
     * we are done with an element.
     * @param  element    The current element to be processed.
     * @throws            Exception from channel processing
     */
    private void processElementEnd(Element element)
                                  throws Exception 
        {
	String name = element.getName();
        if (name.equalsIgnoreCase(CHANNEL))
            {
	    currentChannel.initMetaData(currentName,
					currentDataType,
					currentDateFormat);
	    }
	}

    public Document getXmlDocument()
        {
	return xmlDocument;
        }

    }
