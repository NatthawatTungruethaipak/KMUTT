/* SimpleExitCallback.java
 *
 *  Just exit the program.
 *  Created for CPE 372 demos by Sally Goldin, 13 Nov 2017
 *
 */

package com.grs.gui;

//********************************************************************
/** 
 *  This class implements the Callback interface. I
 *  It simply exits the current application
 * @author  goldin*/
public class SimpleExitCallback implements Callback 
    {

      /**
       * Constructor does nothing...
       */
    public SimpleExitCallback()
        {
 	}

      /** Primary method of a callback class.
       *  Puts up a confirmation dialog and exits if the user
       *   indicates that he or she does want to exit.
       * @param  field Field whose value will determine the
       *   effects of the callback.
       */
    public void executeCallback(DragonField field)
        {
	System.exit(0);
	}

    }


