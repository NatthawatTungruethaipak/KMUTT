/* dbEventRecord is an object which represents a record from the
 * logging_events table.
 *
 * $Id: DbEventRecord.java,v 1.2 2002/10/26 23:35:02 rudahl Exp $
 * $Log: DbEventRecord.java,v $
 * Revision 1.2  2002/10/26 23:35:02  rudahl
 * clientdaemon almost done
 *
 * Revision 1.1  2002/10/16 23:04:04  rudahl
 * initial depost from closet-java1.4.1
 *
 */

package com.grs.nugget;

import java.sql.*;
import java.util.*;
import java.text.*;
import com.grs.dbi.*;

public class DbEventRecord extends DbRecord
    {
    public DbField eTaskId 
	= new DbField("eTaskId","INT NOT NULL","Task",DbField.DBV_INT,
		      "task which was executed");
    public DbField eTaskCommand 
	= new DbField("eTaskCommand","varchar(255)","command",
		      DbField.DBV_STRING,"easier to look at cmds");
    public DbField eNode 
	= new DbField("eNodename","varchar(32)",
		      "Executed by",DbField.DBV_STRING,
		      "Node attempting execution");
    public DbField eStart
	= new DbField("eStart","DATETIME","Start at", DbField.DBV_TIMESTAMP,
		      "time node started on execution");
    public DbField eConsumed 
	= new DbField("eConsumed","INT default 0","Time Consumed",
		      DbField.DBV_INT,"time spent on execution");
    public DbField eCompletionCode 
	= new DbField("eCompletionCode","INT default 0",
		      "Completion code",DbField.DBV_INT,"");
    public DbField eLog 
	= new DbField("eLog","varchar(255)","Log",DbField.DBV_STRING,
		      "explanation for refusal, for example");

	/** This constructor, combined with init(ResultSet),
	 *   is used for reading from the DB
	 */
    public DbEventRecord() throws DbiException  { super(); init(); } 

    public void init(ResultSet result) throws SQLException, DbiException
	{
	super.init(result);
	}

	/** This constructor is used for creating a record to INSERT
	 *  into the DB.
	 */
    public DbEventRecord(int iTaskId,
			 String sCommand,	// the task to be executed
			 String sNode)
		throws DbiException
	{
	init();
	if ((iTaskId <= 0) || (sCommand == null) || (sNode == null))
	    throw new DbiException("Unable to create INSERT record; "
				   +"missing args");
	eTaskId.setIntValue(iTaskId);
	eTaskCommand.setStringValue(sCommand);
	eNode.setStringValue(sNode);
	eStart.setTimeValue(new java.util.Date().getTime());
	}

	/** This constructor is used for creating a record to UPDATE
	 *  the DB. It MUST have iTaskId, sNode, and CompletionCode
	 *  (UPDATE will complain if this record doesn't have id & node)
	 */
    public DbEventRecord(int iTaskId,	// task to update
			 String sNode,	// node starting to process
			 int iConsumed,	// seconds consumed
			 int iCompletionCode, //  some pos or neg 
			 String sLog)	// null or Log info
		throws DbiException
	{
        init();
	if ((iTaskId <= 0) || (sNode == null))
	    throw new DbiException("Unable to create INSERT record; "
				   +"missing args");
	eTaskId.setIntValue(iTaskId);
	eNode.setStringValue(sNode);
	eConsumed.setIntValue(iConsumed);
	eCompletionCode.setIntValue(iCompletionCode);
	if (sLog != null)
	    eLog.setStringValue(sLog);
	}

	/** Return a string which is the first part of an SQL query
	 *  appropriate to this class and associated DB table(s)
	 */ 
    public static String getQueryString() 
	{ return "SELECT * FROM logging_events "; }

	/** Return a string which is the first part of an SQL query
	 *  appropriate to this class and associated DB table(s)
	 */ 
    public static String getDeleteString() 
	{ return "DELETE FROM logging_events "; }

	/** Return a string which is the INSERT command for this record
	 *  and this class and associated DB table(s)
	 */ 
    public String getInsertString(AccessDb access) 
	throws DbiException, SQLException, ClassNotFoundException,
	       NoSuchMethodException

	{
	if ((eTaskId.getIntValue() <= 0) || (eNode.getStrValue().length() < 1))
	    {
	    dump("Insert DbEventRecord");
	    throw new DbiException("Invalid record to insert; "
				   +"has incorrect tID");
	    }
	String retval = "INSERT INTO logging_events(\n"
	    +"eTaskId,eNodename,eTaskCommand,eStart"
	    +")\n VALUES \n   ("
	    +eTaskId.getIntValue()+",'"
	    +eNode.getValue()+"','"
	    +eTaskCommand.getValue()+"','"
	    +eStart.getValue()
	    +"');";

	return retval;
	}

	/** Return a string which is the UPDATE command for this record
	 *  and this class and associated DB table(s)
	 * Note the only fields which can be set are those which
	 * can be initialized via the UPDATE constructor
	 */
    public String getUpdateString() throws DbiException
	{
	if ((eTaskId.getIntValue() <= 0) || (eNode.getStrValue().length() < 1))
	    {
	    dump("Update DbEventRecord");
	    throw new DbiException("Invalid record to update; "
				   +"missing valid task or node");
	    }
	String sets = "";
	sets += "eConsumed = "+eConsumed.getIntValue()+",";
	if (eLog.getStrValue() != null)
	    sets += " eLog = '"+eLog.getStrValue()+"'," ;
	sets += " eCompletionCode = "+eCompletionCode.getIntValue();
	String retval = "UPDATE logging_events set "+sets
	    + "\n  WHERE eTaskId = "+eTaskId.getIntValue()
	    + " AND eNodename = '"+eNode.getValue()+"';";

	return retval;
	}

    public void dump(String czTitle)
	{
	System.out.println("Dump of DbEventRecord "+czTitle);
	System.out.println(toString());
	}
    }
