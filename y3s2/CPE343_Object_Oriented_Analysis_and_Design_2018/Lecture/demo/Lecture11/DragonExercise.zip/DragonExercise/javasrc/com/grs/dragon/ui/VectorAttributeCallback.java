/* VectorAttributeCallback.java
 *
 *    ~~ Copyright 2010 Kurt Rudahl and Sally Goldin
 *
 *	All rights are reserved. Copying or other reproduction of
 *	this program except for archival purposes is prohibited
 *	without the prior written consent of Goldin-Rudahl Associates.
 *
 *			  RESTRICTED RIGHTS LEGEND
 *
 *	Use, duplication, or disclosure by the U.S. Government
 *	is subject to restrictions as set forth in
 *	paragraph (b) (3) (B) of the Rights in Technical
 *	Data and Computer Software clause in DAR 7-104.9(a).
 *
 *	The moral right of the copyright holder is hereby asserted
 *   ~~ EndC
 *
 *
 * Created by Sally Goldin, 27 Dec 2010
 *
 *  $Id: VectorAttributeCallback.java,v 1.1 2010/12/28 05:05:59 goldin Exp $
 *  $Log: VectorAttributeCallback.java,v $
 *  Revision 1.1  2010/12/28 05:05:59  goldin
 *  workingon Vector Import
 *
 *  Revision 1.1  2010/12/27 12:50:04  goldin
 *  Callback to disable unused fields if user chooses IMP/Describe
 *
 * *
 */

package com.grs.dragon.ui;
import com.grs.gui.*;
import javax.swing.*;

/** 
 *  This class implements the Callback interface. It has the effect
 *  of enabling or disabling the feature color field on the vector
 *  import tab depending on whether the user has selected an attribute.
 *
 * @author  goldin*/
public class VectorAttributeCallback implements Callback 
    {

      /** Primary method of a callback class.
       *  Enable or disable fields based on the passed field's value.
       * @param  field Field whose value will determine the
       *   effects of the callback.
       */
    public void executeCallback(DragonField field)
        {
	boolean bEnable = false;
	DragonPanel parent = field.getTopLevelPanel();
	if (parent == null)  
	    return;
	String value = field.getFieldValue();
        DragonField colorField = parent.getField("^COLOR");
	if (colorField == null)
	    return;
	if ((value == null) || (value.length() == 0) ||
	    (value.compareToIgnoreCase("-1") == 0))
	    bEnable = true;
	else
	    bEnable = false;
	/* enable the color field if the user entered -1 for the attribute */
	colorField.setEnabled(bEnable);		
	if (bEnable)
	    colorField.setFieldValue("211");
	}

    protected static String cvsInfo = null;
    protected static void setCvsInfo()
        {
        cvsInfo = "\n@(#)  $Id: VectorAttributeCallback.java,v 1.1 2010/12/28 05:05:59 goldin Exp $ \n";
	}
    }

// End of VectorAttributeCallback.java

