/* DbiException
 * 
 *
 * $Id: DbiException.java,v 1.2 2007/01/05 07:41:57 rudahl Exp $
 * $Log: DbiException.java,v $
 * Revision 1.2  2007/01/05 07:41:57  rudahl
 * added Whatis info
 *
 * Revision 1.1  2002/10/16 23:03:45  rudahl
 * initial depost from closet-java1.4.1
 *
 */

package com.grs.dbi;

public class DbiException extends Exception
    {
    public DbiException() { super(); }
    public DbiException(String description) { super(description); }

    protected static String cvsInfo = null;
    protected static void setCvsInfo()
        {
        cvsInfo = "\n@(#)  $Id: DbiException.java,v 1.2 2007/01/05 07:41:57 rudahl Exp $ \n";
	}
    }

