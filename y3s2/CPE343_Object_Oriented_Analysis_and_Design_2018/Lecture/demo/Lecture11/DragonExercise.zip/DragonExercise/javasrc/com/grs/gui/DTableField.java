/** 
 * DTableField.java
 *
 *    Table-like control to allow entry of multiple values per row.
 *       First implemented to handle new class names capability (name
         plus image value) 
 *
 *	Copyright  2007   Sally Goldin and Kurt Rudahl
 *
 *	All rights are reserved. Copying or other reproduction of
 *	this program except for archival purposes is prohibited
 *	without the prior written consent of Goldin-Rudahl Associates.
 *
 *			  RESTRICTED RIGHTS LEGEND
 *    
 *	Use, duplication, or disclosure by the U.S. Government
 *	is subject to restrictions as set forth in
 *	paragraph (b) (3) (B) of the Rights in Technical
 *	Data and Computer Software clause in DAR 7-104.9(a).
 *
 *	The moral right of the copyright holder is hereby asserted
 *
 * $Id: DTableField.java,v 1.8 2007/12/06 09:22:04 goldin Exp $
 * $Log: DTableField.java,v $
 * Revision 1.8  2007/12/06 09:22:04  goldin
 * Fix some problems with table focus handling
 *
 * Revision 1.7  2007/10/23 13:26:14  goldin
 * Fix null ptr exception if no labels to validate in HEA
 *
 * Revision 1.6  2007/09/01 09:17:11  goldin
 * Add code to support duplicate detection (by allowing values to be gotten as a vector
 *
 * Revision 1.5  2007/08/27 11:36:47  goldin
 * Add functionality to table including ability to sort
 *
 * Revision 1.4  2007/08/26 10:51:54  goldin
 * Enhancements to behavior of DTableField
 *
 * Revision 1.3  2007/08/26 08:53:01  goldin
 * Add validation capabilities to the DTableField control
 *
 * Revision 1.2  2007/08/19 12:51:33  goldin
 * Continue work on table control
 *
 * Revision 1.1  2007/08/19 11:18:43  goldin
 * New Table control (not yet working)
 *
 *
 */

package com.grs.gui;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;

/** Control that allows user to enter 
 * multiple, multipart parameters.
*   
* @author  goldin
*/
public class DTableField extends DragonField 
    implements ActionListener, ListSelectionListener, TableModelListener
    {
    protected JPanel mainPanel = null;
    protected JTable dragTable = null;
    protected JScrollPane tableScroller = null;
    protected JLabel tableLabel = null;
 
   /* buttons to control the list contents*/
    protected JButton addBtn = null;
    protected JButton removeBtn = null;
    protected JButton sortBtn = null;

   /* number of columns */
    int numColumns = 0;

    /* column to use for sorting - assume we can use straight lexical sort */
    int sortColumn = -1;

    /* maximum number of rows allowed */
    int maxRows = 0;

    /* Table model for this table */
    DefaultTableModel tableModel = null;

    /* An array to hold one row of data */ 
    /* Our table can only hold strings */
    String [] rowData = null;

    /* save column titles for cloning */
    String [] colTitles = null;

    /* indices of last changed row and column. Used in
     * validation, set by the TableModelListener method.
     */
    int changedRow = -1;
    int changedColumn = -1;

    /**
     * flag to suppress calling validator when we blank out
     * a value under program control.
     */ 
    boolean bValidate = true;

    /**
     * Comparator used for sorting rows
     */
    TableRowComparator rowComparator = null;


    //********************************************************************
      /**
       * Constructor creates the UI: the table and the 
       * add and remove buttons.
       * @param name  Name for new field
       * @param labelText   Label for entire control. Can be null.
       * @param numColumns  Number of columns 
       * @param colTitles   Array of column titles (already subjected to I18N)
       * @param maxRows     Maximum number of possible rows.
       * @param sortColumn  Column to use for sorting - use -1 for none.
       */
    public DTableField(String name, String labelText, int numColumns,
		      String[] colTitles, int maxRows, int sortColumn)
        {
	this.name = name;
        this.labelText = labelText;
        this.numColumns = numColumns;
        this.maxRows = maxRows;
        this.colTitles = colTitles;
	this.sortColumn = sortColumn;
        String addString = 
	    ApplicationManager.getTextSource().getI18NText("%h2B0.0.0","ADD");
        String removeString = 
	    ApplicationManager.getTextSource().getI18NText("%f7401.2","REM");
        String sortString = 
	    ApplicationManager.getTextSource().getI18NText("%f10000.11","SORT");
        rowData = new String[numColumns];
	tableModel = new DefaultTableModel(); 
        dragTable = new JTable(1,numColumns);
        dragTable.putClientProperty("terminateEditOnFocusLost", Boolean.TRUE);
        Object[][] allRows = new Object[1][numColumns];
        for (int i=0; i<numColumns; i++)
            {
	    allRows[0][i] = "AAABBBCCC";
            }
        tableModel.setDataVector(allRows,colTitles);
	tableModel.addTableModelListener(this);
        dragTable.setModel(tableModel);
        mainPanel = new JPanel(new BorderLayout());         
        tableScroller = new JScrollPane(dragTable);

        /** ~~~ TO DO - allow size to be set by constructor */
        tableScroller.setPreferredSize(new Dimension(400,300));
        mainPanel.add(tableScroller,BorderLayout.CENTER);
        dragTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        dragTable.setShowHorizontalLines(true);  
        ListSelectionModel listModel = dragTable.getSelectionModel();
        listModel.addListSelectionListener(this);
        if (labelText != null)
            {
	    tableLabel = new JLabel(labelText);
	    mainPanel.add(tableLabel, BorderLayout.NORTH);
            }        

        addBtn = new JButton(addString);
        addBtn.addActionListener(this);        
        addBtn.setEnabled(false);
        removeBtn = new JButton(removeString);
        removeBtn.addActionListener(this);
	removeBtn.setEnabled(false);
        sortBtn = new JButton(sortString);
        sortBtn.addActionListener(this);
        sortBtn.setEnabled(false);
        JPanel buttonPanel = new JPanel(new GridLayout(0,1));
        buttonPanel.setBorder(new EmptyBorder(10,10,0,0));
        buttonPanel.add(addBtn);        
        buttonPanel.add(removeBtn);        
	if (sortColumn >= 0)
            buttonPanel.add(sortBtn);
        JPanel outerButtonPanel = new JPanel(new BorderLayout());
        outerButtonPanel.add(buttonPanel,BorderLayout.NORTH);
        mainPanel.add(outerButtonPanel,BorderLayout.EAST);
	add(mainPanel,BorderLayout.WEST);
        //dumpModel();
	}

     private void dumpModel()
        {
	System.out.println("\nTable rows are " + dragTable.getRowCount());
	System.out.println("Table columns are " + dragTable.getColumnCount());
	for (int row = 0; row < dragTable.getRowCount(); row ++) 
	    {
	    if (row > 0)
		System.out.println();
	    for (int col = 0; col < dragTable.getColumnCount(); col++)
                {
		String cellValue = (String) dragTable.getValueAt(row,col);
                System.out.print(cellValue + "   ");
                } 
	    }
        }

    //********************************************************************
      /**
       * Create and return copy of the present object. Data items
       * that are set during the addition to a panel are not 
       * copied.
       */
    public DragonField makeClone()
        {
	DTableField clone = new DTableField(name,labelText,numColumns,
					    colTitles, maxRows, sortColumn);
        initializeClone(clone);
	clone.setSortColumn(sortColumn);
	return (DragonField) clone;
	}

    //********************************************************************
      /** Sets the field to be enabled or disabled depending
       *   on the value of the bEnabled argument.
       *   
       * @param  bEnabled Enablement flag
       */
    public void setEnabled(boolean bEnabled) 
        {
	dragTable.setEnabled(bEnabled);
        if (bEnabled == false)
	    {
	    addBtn.setEnabled(false);
	    removeBtn.setEnabled(false);
	    sortBtn.setEnabled(false);
            }
        else 
           checkButtonEnabling();
        }

      /** Calculates the minimum amount of space (in pixels) required
       * by the field's graphic components. This will usually be
       * based on things like the width of the label in the current font.
       * @return Minimum width of graphical components, in pixels.
       */
    public int calculateWidth()
        {
	/* for now, assume a fixed cell size of 36 chars 
         * and a constant font.
         */ 
	int btnWidth = 0;
	int controlWidth = 0;
        int tableWidth = 0;
	tableWidth = tableScroller.getPreferredSize().width + 50; 
	btnWidth = addBtn.getPreferredSize().width + 20;  /* add border */
        controlWidth = tableWidth + btnWidth;
        return controlWidth;
	}

      /** Calculates the minimum amount of vertical space (in pixels) required
       * by the field's graphic components. This will usually be
       * based on things like the width of the label in the current font.
       * @return Minimum height of graphical components, in pixels.
       */
    public int calculateHeight()
        {
	int controlHeight = 0;
        controlHeight = tableScroller.getPreferredSize().height + 100;  /* fudge factor */
        return controlHeight;
	}

      /**
       * Returns true if passed control is equivalent to present
       * control - that is, all values are the same.
       */
    public boolean equivalent(DragonField field)
        {
	if (!(field instanceof DTableField))
	    return false;
	if (!commonFieldsEqual(field))
	    return false;
	DTableField fField = (DTableField) field;
        if (fField.getMaxRows() != maxRows)
	    return false;
        if (fField.getNumColumns() != numColumns)
	    return false;
        String[] otherTitles = fField.getColTitles();
        for (int i = 0; i < numColumns; i++)
            {
	    if (otherTitles[i].compareTo(colTitles[i]) != 0)
		return false;
            }        
	return true;
	}


    //********************************************************************

    public void focusLost(FocusEvent fe)
        {
	    /* not sure what we need yet */
	}

      /** Tries to set the focus to the control associated
       *  with the field. Since each field subclass has different
       *  controls, this method must be implemented for each one.
       */
    public void requestFocus()
        {
            /* not sure what we need yet */
        } 

      /**
       * Method from the TableModelListener interface.
       * Called whenever table values changed, used to
       * validate the data entered.
       */
    public void tableChanged(TableModelEvent te)
	{
	boolean bValid = true;
	int changeType = te.getType();
        if ((changeType == TableModelEvent.UPDATE) &&
            (this.validator != null) && (bValidate))
            {
	    changedRow = dragTable.getEditingRow();
            changedColumn = dragTable.getEditingColumn();
            if ((changedRow >= 0) && (changedColumn >= 0))
                { 
                bValid = validator.isValid(this);
                if (!bValid)
		    {
		    bValidate = false;
		    validator.displayLastError();
		    tableModel.setValueAt("",changedRow,changedColumn); 
		    bValidate = true;
		    }
		}
	    }
        changedRow = -1;
        changedColumn = -1;
	}

      /**
       * Method from the actionListener interface. Called when the
       * browse button is clicked or the user hits return in the
       * inputField.
       */
    public void actionPerformed(ActionEvent e)
        {
        Object source = e.getSource();
        if (source.equals(addBtn))
            addEmptyRow();
        else if (source.equals(removeBtn))
            removeSelectedRow();
	else if (source.equals(sortBtn))
	    sortTable();
        checkButtonEnabling();
        }
	/**
	 * Method from listSelectionListener interface.
	 * Will be called when the user selects or deselects
	 * a table row.
	 */
    public void valueChanged(ListSelectionEvent le)  
	{
	Object source = le.getSource();
        if (!source.equals(dragTable.getSelectionModel()))
	    return;
	int selectedRow = dragTable.getSelectedRow();
	if (selectedRow >= 0)
	    removeBtn.setEnabled(true);
	else
	    removeBtn.setEnabled(false);    
	}

	/**
	 * Enable or disable add and
         * remove buttons depending on
	 * whether the table has rows in
	 * it and whether an row is selected.
	 */
    protected void checkButtonEnabling()
	{
	addBtn.setEnabled(false);
	removeBtn.setEnabled(false);
        sortBtn.setEnabled(false);
        if (tableModel.getRowCount() < maxRows)
            addBtn.setEnabled(true);
	if (dragTable.getSelectedRow() >= 0)
	    removeBtn.setEnabled(true);
	if ((tableModel.getRowCount() > 0) && (sortColumn >= 0))
	    sortBtn.setEnabled(true);
	}
    
    protected void addEmptyRow()
        {
        for (int i=0; i<numColumns; i++)
            rowData[i] = "";
        tableModel.addRow(rowData);
	checkButtonEnabling();
	//System.out.println("Called addEmptyRow, numRows is " + tableModel.getRowCount());
        }

    protected void removeSelectedRow()
        {
	int selectedRow = dragTable.getSelectedRow();
        //System.out.println("selected row is " + selectedRow);
        if (selectedRow >= 0)
	   tableModel.removeRow(selectedRow);
	checkButtonEnabling();
        }

    /* Sort the rows in the table based on the specified sort Column 
     * Make this public so that it can be called from the validator.
     */
    public void sortTable()
	{
	if (sortColumn < 0)
	    return;
	else
            {
	    if (dragTable.isEditing())
		dragTable.getCellEditor().stopCellEditing();
	    if (rowComparator == null)
		rowComparator = new TableRowComparator(sortColumn,numColumns);
            TreeSet<String[]> sortSet = new TreeSet<String[]>(rowComparator);
	    for (int row = 0; row < tableModel.getRowCount(); row ++) 
		{
		String[] tempRow = new String[numColumns];
		for (int col = 0; col < numColumns; col++)
                    {
		    String cellValue = (String) tableModel.getValueAt(row,col);
		    tempRow[col] = cellValue;
                    }
                sortSet.add(tempRow);
                } 
            clearField();
            // now read the rows back in order and add them to the table 
            Iterator<String[]> it = sortSet.iterator();
            while (it.hasNext())
                {
                String[] nextRow = it.next();
                if (!allBlank(nextRow))
                     tableModel.addRow(nextRow);
                }
	    }
	}


     /** 
      * Check to see if all the strings in an array are
      * blank or empty. If so, return true, else return
      * false.
      */
    protected boolean allBlank(String[] values)
       {
       boolean bBlank = true;
       int count = values.length;
       int i = 0;
       while ((bBlank == true) && (i < count))
           {
	   if (values[i].length() > 0)
	       {
	       for (int j = 0; j < values[i].length(); j++)
                   { 
		   if (values[i].charAt(j) != ' ')
		       bBlank = false;
		   }
               }
	   i++;
	   }  
       return bBlank;
       }

      /**
       * Method to clear the field - if this is relevant.
       * Gets rid of all rows
       */
    public void clearField()
        {
	int row;
        bValidate = false;
        for (row = tableModel.getRowCount()- 1; row >= 0; row--)
	    tableModel.removeRow(row);
	bValidate = true;
	removeBtn.setEnabled(false);
	}

  
    //********************************************************************
      /**
       * Override addMouseListener to add to all the subcontrols
       * as well.
       */
    public void addMouseListener(MouseListener listener)
        {
	addBtn.addMouseListener(listener);
	removeBtn.addMouseListener(listener);
        dragTable.addMouseListener(listener);
	addBtn.putClientProperty(DragonField.PARENT_FIELD,this);
	removeBtn.putClientProperty(DragonField.PARENT_FIELD,this);
	dragTable.putClientProperty(DragonField.PARENT_FIELD,this);
	}

      /**
       * Override addKeyListener to add to all the subcontrols
       * as well.
       */
    public void addKeyListener(KeyListener listener)
        {
	}

      /**
       * Return a string with concatenated pspecifiers plus
       * all the information in the table, with columns separated by
       * tilde delimiters 
       * @return Concatenated string. Returns empty string if 
       *         there are no items in the table.
       */
    public String getFieldValue()
        {
	String result = "";
        if (tableModel.getRowCount() > 0)
	    {
	    StringBuffer buffer = new StringBuffer(); 
	    for (int row = 0; row < tableModel.getRowCount(); row ++) 
		{
		if (row > 0)
                   buffer.append("\n ");
		buffer.append(getPSpecifier() + String.valueOf(row) + " ");
		buffer.append("\""); 
		for (int col = 0; col < numColumns; col++)
                    {
		    String cellValue = (String) tableModel.getValueAt(row,col);
                    if (col > 0)
                        buffer.append("~");
		    buffer.append(cellValue);
                    }
		buffer.append("\"" + " ");
                } 
	    result = buffer.toString();
	    }
	return result;
	}


      /**
       * Return an vector of vectors of strings with the current contents
       * of table.  
       * @return Vector of vectors. Returns null if no items in the table
       */
    public Vector<Vector> getFieldValueAsVector()
        {
	if (tableModel.getRowCount() <= 0)
            return null;
	Vector<Vector> rows = new Vector<Vector>(tableModel.getRowCount());
	for (int row = 0; row < tableModel.getRowCount(); row ++) 
	    {
	    Vector<String> oneRow = new Vector<String>(numColumns);
	    for (int col = 0; col < numColumns; col++)
               {
	       String cellValue = (String) tableModel.getValueAt(row,col);
	       oneRow.add(cellValue);
	       }
	    rows.add(oneRow);
	    } 
	return rows;
	}




      /** Allows the panel or other outside class to set the value of the
       *   field. Must be overridden in each subclass,
       * @param  value String to use to set value of the control.
       *    This should be in the following form:
       *         row0col1val~row0col2val~row0col3val<newline>
       *         row1col1val~row1col2val~row1col3val
       *  In other words, rows are separated by newlines,
       *  column values are separated by tildes.  
       */
    public void setFieldValue(String value)
       {
       clearField();
       //System.out.println("Value to parse is \n" + value);
       StringTokenizer lineTokenizer = new StringTokenizer(value,"\n");	   
       while (lineTokenizer.hasMoreTokens())
	   {
	   String line = lineTokenizer.nextToken();
           int i = 0;
           StringTokenizer colTokenizer = new StringTokenizer(line,"~");
           while ((colTokenizer.hasMoreTokens()) && (i < numColumns))
	       {
	       String colValue = colTokenizer.nextToken();
	       rowData[i] = colValue;
               //System.out.println("column value for column " + i + " is " + colValue);
               i++;
               } 
	   tableModel.addRow(rowData);
	   }
       checkButtonEnabling();
       }

    //********************************************************************
      /** * Get/Set Methods
       */
    public String[] getColTitles() 
        {
        return colTitles;
        }

     /**
      * This should not be called when there is data
      * in the table, because it will clear the current
      * data and set the table back to a single row.
      * @param titles  Array of column titles.
      */
    public void setColTitles(String[] titles)
        {
	colTitles = titles;
        }

    public int getRowCount()
        {
	return dragTable.getRowCount();
	}

    public int getMaxRows()
        {
	return maxRows;
	}

    public void setMaxRows(int rows)
        {
	maxRows = rows;
	}

    public int getNumColumns()
        {
        return numColumns;
	}
	/* cannot set numColumns after creation */


    public int getChangedRow()
        {
	return changedRow;
        }

    public int getChangedColumn()
        {
	return changedColumn;
        }

    public int getSortColumn()
        {
	return sortColumn;
        }
    public void setSortColumn(int column)
        {
	sortColumn = column;
        }

    /** 
     * Return the current table value at row,col.
     * Returns null if row or column number is invalid.
     */
    public String getValueAt(int row, int col)
        {
	if ((row < 0) || (row >= dragTable.getRowCount()) ||
            (col < 0) || (col >= dragTable.getColumnCount()))
            return null;
        else
            return (String) tableModel.getValueAt(row,col); 
        }

    protected static String cvsInfo = null;
    protected static void setCvsInfo()
        {
        cvsInfo = "\n@(#)  $Id: DTableField.java,v 1.8 2007/12/06 09:22:04 goldin Exp $ \n";
	}

	/**
         * Internal class used for sorting table rows based on a
         * specific sort column. If the values in the column can
         * are numbers, then we do a numerical sort. We signal that
	 * the column is numeric by passing a column number plus 100.
	 * Otherwise we do a lexigraphic sort. 
         */
    public class TableRowComparator implements Comparator<String[]>
    {
	int sortColumn = 0;  /* primary sort column */
        int numColumns = 0;  /* overall number of columns, for breaking ties */
	boolean bNumeric = false;

        /**
         * Constructor sets the sort column 
         */
        public TableRowComparator(int sortColumn,int numColumns)
	   {
	   if (sortColumn >= 100)
	       {
	       bNumeric = true;
	       this.sortColumn = sortColumn - 100;
	       }
	   else
	       this.sortColumn = sortColumn;
           this.numColumns = numColumns;
           }
     
        /** compares based on specified column value 
         * If two rows have the same value, compares the
	 * entire concatenated content of the row.
         * @param row1  First row to compare
	 * @param row2  Second row to compare
	 * @return -1 if first row should be first, 1 if second row should
	 *         be first, 0 if they are equal.
	 */
        public int compare(String[] row1, String[] row2)
	   {
	   boolean bOk = false;
           int retval = 0;
	   if (bNumeric)
               {
               try 
                   {
	           int v1 = Integer.parseInt(row1[sortColumn]);	   
	           int v2 = Integer.parseInt(row2[sortColumn]);
		   if (v1 < v2)
                       retval = -1;
                   else if (v1 > v2)
		       retval = 1;
                   bOk = true;
	           }
               catch (NumberFormatException nfe)
                   {
		   }    
               }
           if (!bOk)
	       retval = row1[sortColumn].compareTo(row2[sortColumn]);
           if (retval == 0)
               {
	       StringBuffer b1 = new StringBuffer();
	       StringBuffer b2 = new StringBuffer();
	       for (int i = 0; i < numColumns; i++)
                   {
		   b1.append(row1[i] + "~");    
		   b2.append(row2[i] + "~");    
                   } 
               retval = b1.toString().compareTo(b2.toString());
               }
            return retval;
           }
    }


    } 

// End of DTableField.java
