/**
 *   GraphDatasource.java
 *   
 *     Created by S.Goldin
 *
 *    $Id: GraphDatasource.java,v 1.2 2004/04/04 08:27:23 rudahl Exp $
 *
 *    $Log: GraphDatasource.java,v $
 *    Revision 1.2  2004/04/04 08:27:23  rudahl
 *    Implement status display functionality
 *
 *    Revision 1.1  2004/02/24 12:25:11  rudahl
 *    Developing for Release 1
 *
 *
 */
package com.grs.evp;

/**
 * This interface defines methods that allow us to get
 * at any data and/or meta data that might be used in a
 * plot.
 */
public interface GraphDatasource
    {

    /**
     * Return number of channels (data columns) in
     * the data set. 
     * @return number of channels, or -1 if datasource is not initialized
     */
    public int getChannelCount();

    /**
     * Return number of samples in the data set. 
     * @return number of samples, or -1 if datasource is not initialized
     */
    public int getSampleCount();
    
    /**
     * Return the symbol for the equity or other thingy that
     * this datasource represents
     */
    public String getSymbol();

    /**
     * Return the ChannelData object at specified index.
     * @param channelIndex   Index we're interested in
     * @return channel object or null if bad index or not initialized
     */
    public ChannelData getChannelData(int channelIndex);

    /**
     * Add a new channel to the data source.
     * The new channel must be initialized by calling initMetaData
     * as a separate operation.
     */
    public ChannelData addChannel();

    /**
     * Get latest error number (if any)
     * @return negative number of latest error, or 0 if no error
     */
    public int getLatestErrorNumber();

    /**
     * Get latest error message (if any)
     * @return error message associated with latest error, or null if no error
     */
    public String getLatestErrorMessage();
    }
