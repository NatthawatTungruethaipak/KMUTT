/* DbRecord is an abstract object which is 
 * the superclass of objects which represent the information in a DB record.
 *
 * $Id: DbRecord.java,v 1.2 2002/10/26 23:29:43 rudahl Exp $
 * $Log: DbRecord.java,v $
 * Revision 1.2  2002/10/26 23:29:43  rudahl
 * made serializable
 *
 * Revision 1.1  2002/10/16 23:03:45  rudahl
 * initial depost from closet-java1.4.1
 *
 */

package com.grs.dbi;

import java.io.*;
import java.sql.*;
import java.util.*;
import java.text.*;
import java.lang.reflect.*;

public class DbRecord extends Object implements Serializable
    {

	/** This constructor, combined with init(ResultSet), 
	 *  is used for reading from the DB
	 *  It starts by setting all ints to -1 and Timestamps to Date(0)
	 */
    protected DbRecord() throws DbiException { }

    protected void init() throws DbiException
	{
	Field[] fields = getClass().getFields();
	for (int i=0; i<fields.length; i++)
	    {
	    try
		{
		DbField fld = (DbField)fields[i].get(this);
		//		System.out.println("field # "+i+" of "+fields.length+" fld="+fld);
		if (fld.getValueType() == DbField.DBV_INT)
		    fld.setIntValue(-1);
		else if (fld.getValueType() == DbField.DBV_TIMESTAMP)
		    fld.setTimeValue(0);
		}
	    catch (IllegalAccessException iae)
		{ // ignore silently
		}
	    }
	}

	/** initialize those subclass fields which are public DbFields
	 *  silently ignore any other fields
	 *  This should be invoked from the same-named fn in the subclass,
	 *  which should handle all other fields.
	 */
    public void init(ResultSet result) throws SQLException, DbiException
	{
	Field[] fields = getClass().getFields();
	for (int i=0; i<fields.length; i++)
	    {
	    try
		{
		DbField fld = (DbField)fields[i].get(this);
		fld.setValue(result);
		}
	    catch (IllegalAccessException iae)
		{ // ignore silently
		}
	    }
	}

    public static String getQueryString() { return ""; }

    public static String getDeleteString() { return ""; }

    public static Integer getLatestIntKey() { return new Integer(-1); }

    public String getInsertString(AccessDb access) 
	throws DbiException, SQLException, ClassNotFoundException,
		       NoSuchMethodException

	{ return ""; }

    public String getUpdateString() throws DbiException { return ""; }

    public void dump(String czTitle) 
	{
	Field[] fields = getClass().getFields();
	String buf = czTitle+" type "+getClass().getName()
	    +" has "+fields.length+" fields:\n"+toString();
	System.out.println(buf);
	}

    public String toString() 
	{
	Field[] fields = getClass().getFields();
	String buf = "  ";
	int iLineLen = buf.length();
	for (int i=0; i<fields.length; i++)
	    {
	    try
		{
		DbField fld = (DbField)fields[i].get(this);
		if (fld.getValue().length() < 1)
		    continue;
		String buf1 = fld.getDisplayName()+"='"+fld.getValue()+"' ";
		if ((buf.length()-iLineLen > 0) 
		    && (buf.length() + buf1.length() - iLineLen > 80))
		    {
		    buf += "\n  ";
		    iLineLen = buf.length();
		    }
		buf += buf1;
		}
	    catch (IllegalAccessException iae)
		{
		buf += "Illegal Access Exception on field "+i+" ";
		}
	    }
	return buf;
	}

	/** DbField permits subclasses of DbRecord to consist of
	 *  almost nothing except data definitions of the database schema.
	 *  the DbField optionally includes sufficient information 
	 *  to permit creating the DB table directly from the DbRecord.
	 *  fields are: 'sqlName' is the column name in the DB table. REQD.
	 *		'sqlModifier' additional info which would be needed
	 *			in order to create the DB table. Optional.
	 *		'displayName' column name for dump and other display
	 *			purposes. If omitted, 'sqlName' is used
	 *		'description' info about purpose of field. Optional.
	 *		'iValueType' type of DB value (since SQL may have
	 *			different syntax for different datatypes)
	 *			one of DBV_STRING, DBV_INT, DBV_TIMESTAMP
	 */
    public class DbField extends Object implements Serializable
        {
	protected String sqlName;
	protected String sqlModifier;
	protected String displayName;
	protected String description;
	protected int iValueType; // 1=string (default) 1=int 2=Timestamp
	    // only one if the following is used
	protected String value;
	protected int intValue;
	protected Timestamp timeValue;

	static final public int DBV_STRING = 0;
	static final public int DBV_INT = 1;
	static final public int DBV_TIMESTAMP = 2;

	private DbField() {}
	public DbField(String sqlName, String sqlModifier,
		       String displayName, int iValueType,
		       String description)
	    {
	    this.sqlName = sqlName;
	    this.sqlModifier = sqlModifier;
	    this.displayName = displayName;
	    this.iValueType = iValueType;
	    this.description = description;
	    }

	public String getSqlName() { return sqlName; }
	public String getSqlModifier() { return sqlModifier; }
	public String getDisplayName() 
	    { return (displayName != null) ? displayName : sqlName; }
	public String getDescription() { return description; }
	public int getValueType() { return iValueType; }

	    // following fns assume caller knows what datatype it is
	public String getStrValue() { return value; }
	public int getIntValue() { return intValue; }
	public Timestamp getTimeValue() { return timeValue; }

	    /** fn assumes caller DOESN'T know what datatype it is
	     * @return	string
	     */
	public String getValue() 
	    { 
	    return ((iValueType == DBV_STRING) && (value != null)) ? value
		   : (iValueType == DBV_INT) ? Integer.toString(intValue)
		   : ((timeValue != null) && (timeValue.getTime() > 0)) 
		       ? timeValue.toString()
		   : "";
	    }

	public void setIntValue(int intValue) { this.intValue = intValue; } 

	public void setStringValue(String value) { this.value = value; } 

	public void setTimeValue(long timeValue) 
	    { this.timeValue = new Timestamp(timeValue); } 

	public void setTimeValue(Timestamp timeValue) 
	    { this.timeValue = timeValue; } 

	public void setValue(ResultSet result) 
	    throws IllegalAccessException, DbiException, SQLException
	    { 
	    if (iValueType == DBV_STRING) 
		this.value = result.getString(sqlName);
	    else if (iValueType == DBV_INT)
		this.intValue = result.getInt(sqlName);
	    else if (iValueType == DBV_TIMESTAMP)
		{
		timeValue = result.getTimestamp(sqlName);
		    //		String czTime = result.getString(sqlName);
		    //if (czTime != null)
		    //timeValue = Timestamp.valueOf(czTime);
		}
	    else
		throw new DbiException("Unknown field type");
	    }

        }

    }
