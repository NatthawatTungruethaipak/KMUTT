/* DescribeImportCallback.java
 *
 *    ~~ Copyright 2010 Kurt Rudahl and Sally Goldin
 *
 *	All rights are reserved. Copying or other reproduction of
 *	this program except for archival purposes is prohibited
 *	without the prior written consent of Goldin-Rudahl Associates.
 *
 *			  RESTRICTED RIGHTS LEGEND
 *
 *	Use, duplication, or disclosure by the U.S. Government
 *	is subject to restrictions as set forth in
 *	paragraph (b) (3) (B) of the Rights in Technical
 *	Data and Computer Software clause in DAR 7-104.9(a).
 *
 *	The moral right of the copyright holder is hereby asserted
 *   ~~ EndC
 *
 * Created by Sally Goldin, 27 Dec 2010
 *
 *  $Id: DescribeImportCallback.java,v 1.2 2010/12/28 05:05:59 goldin Exp $
 *  $Log: DescribeImportCallback.java,v $
 *  Revision 1.2  2010/12/28 05:05:59  goldin
 *  workingon Vector Import
 *
 *  Revision 1.1  2010/12/27 12:50:04  goldin
 *  Callback to disable unused fields if user chooses IMP/Describe
 *
 * *
 */

package com.grs.dragon.ui;
import com.grs.gui.*;
import javax.swing.*;

/** 
 *  This class implements the Callback interface. It has the effect
 *  of enabling or disabling most of the fields on the auto import
 *  or vector import tabs based on whether the user
 *  has chosen "Import" or "Describe"
 *
 * @author  goldin*/
public class DescribeImportCallback implements Callback 
    {

    protected DragonField flds[] = new DragonField[8];
    int fieldCount = 0;

      /** Primary method of a callback class.
       *  Enable or disable fields based on the passed field's value.
       * @param  field Field whose value will determine the
       *   effects of the callback.
       */
    public void executeCallback(DragonField field)
        {
	boolean bEnable = false;
	int i = 0;
	DragonPanel parent = field.getTopLevelPanel();
	if (parent == null)  
	    {
	    return;
	    }
	String value = field.getFieldValue();
	/* import image tab */
        if (field.getName().compareTo("^DESCRIBEI") == 0)
	    {
	    flds[0] = parent.getField("^OP");
	    flds[1] = parent.getField("^ECUTIL");
	    flds[2] = parent.getField("^RS");
	    flds[3] = parent.getField("^B");
	    fieldCount = 4;
	    }
	else
	    {
	    /* vector import */
	    flds[0] = parent.getField("^FVO");
	    flds[1] = parent.getField("^AT");
	    flds[2] = parent.getField("^SF");
	    flds[3] = parent.getField("^LXV");
	    flds[4] = parent.getField("^LYV");
	    flds[5] = parent.getField("^UXV");
	    flds[6] = parent.getField("^UYV");
	    flds[7] = parent.getField("^COLOR");
	    fieldCount = 8;
	    }
	for (i = 0; i < fieldCount; i++)
            {
	    if (flds[i] == null)
		return;  /* fail silently if we can't find a field */
	    }
	if ((value == null) || (value.length() == 0) ||
	    (value.compareToIgnoreCase("I") == 0))
	    bEnable = true;
	for (i = 0; i < fieldCount; i++)
            {
	    flds[i].setEnabled(bEnable);		
	    if (bEnable)
		flds[i].setFieldValue(flds[i].getDefaultValue());
	    }
	}

    protected static String cvsInfo = null;
    protected static void setCvsInfo()
        {
        cvsInfo = "\n@(#)  $Id: DescribeImportCallback.java,v 1.2 2010/12/28 05:05:59 goldin Exp $ \n";
	}
    }

// End of DescribeImportCallback.java

