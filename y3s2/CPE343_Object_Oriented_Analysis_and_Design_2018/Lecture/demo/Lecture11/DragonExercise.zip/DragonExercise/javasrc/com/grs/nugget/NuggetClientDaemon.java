/* NuggetClientDaemon
 * request and execute a task
 * $Id: NuggetClientDaemon.java,v 1.1 2002/10/26 23:33:15 rudahl Exp $
 * $Log: NuggetClientDaemon.java,v $
 * Revision 1.1  2002/10/26 23:33:15  rudahl
 * initial deposit
 *
 */

package com.grs.nugget;

import java.sql.*;
import java.util.*;
import java.text.*;
import java.net.*; /* malformedurl */
import java.io.*;
import java.rmi.*;
import java.rmi.server.*;
import java.rmi.registry.LocateRegistry;
import com.grs.dbi.*;

public class NuggetClientDaemon
    {

    protected ClientProcess[] m_proc = null;
    protected int m_iOperatingMode; 	/* 0=clientDaemon 
					 * 1=standAloneDaemon 2=test */ 
    protected int m_iCurrentPriority = -1; /* priority of highest task 
					    * currently running, or -1 */
    protected NuggetServer m_server = null;
    protected String m_sLocalHostName = null;
    protected String m_sServerName = null;

    public final static int CLIENT_DAEMON = 0;
    public final static int STANDALONE_DAEMON = 1;
    public final static int TEST_DAEMON = 2;

    public NuggetClientDaemon(String[] args)
	throws DbiException,java.net.UnknownHostException,NotBoundException,
	       MalformedURLException,SQLException,RemoteException
	{
	if (args.length > 0)
	    {
	    m_iOperatingMode = TEST_DAEMON; /* test mode */
	    m_proc = new ClientProcess[args.length];
	    int iProcessNo = 0;
	    for (int i=0; i<args.length; )
		{ // ignore opts for the moment
		m_proc[iProcessNo++] = new ClientProcess(-i-1,args[i]);
		i += 1;
		}
	    }
	else
	    {
	    m_iOperatingMode = CLIENT_DAEMON; /* clientDaemon mode */
	    m_proc = new ClientProcess[11]; // one / priority 	    
	    ResourceBundle bundle = ResourceBundle.getBundle("nugget");
	    String portNum = bundle.getString("server.portnum");
	    m_sServerName = bundle.getString("server.hostname");
	    m_sLocalHostName = InetAddress.getLocalHost().getHostName();
	    if (m_sServerName == null)
		{
		System.out.println("Server name must be specified in "
				   +"property file");
		return;
		}
	    if (portNum == null)
		{
		System.out.println("Port number not found in property "
			       +"file - using 11000");
		portNum = "11000";
		}
	    String url ="rmi://"+m_sServerName+":"+portNum+"/NuggetServer";
	    System.out.println("try to lookup '"+url+"'");
	    m_server = (NuggetServer)Naming.lookup(url);
	    System.out.println("lookup of '"+url+" returned "+m_server);
	    }
	}

	/** check if there are any new tasks to run.
	 *  If so, create them and add them to m_proc
	 */
    protected void checkForTasks()
	throws DbiException,SQLException,RemoteException
	{
		/* first see whether there is a new task with a priority
		 * higher than the one currently running
		 */
	String sPreferredNode = ""; /* "" or local or "*" */ 
	sPreferredNode = (m_iCurrentPriority > 8) ? m_sLocalHostName : "";
	Vector possibleTasks = m_server.taskSearch(m_iCurrentPriority+1,
						   sPreferredNode,
						   m_sLocalHostName);
	java.util.Date now = new java.util.Date();
	System.out.println(m_sLocalHostName+" retrieved "+possibleTasks.size()
			   +" tasks from "+m_sServerName+" at "+now);
	if (possibleTasks.size() > 0)
	    {
	    ClientTaskRecord rec 
		    = (ClientTaskRecord)possibleTasks.elementAt(0);
	    int iTaskId = rec.tID.getIntValue();
	    try
		{
		m_server.taskAccept(iTaskId,m_sLocalHostName);
		String cmd = rec.tCommand.getValue();
		int iPriority = rec.tPriority.getIntValue();
		int iMaxSeconds = rec.tMaxTime.getIntValue();
		Timestamp tStart = rec.tTimeArg.getTimeValue();
		String sSourceArg = rec.tSourceArg.getValue();
		String sDestArg = rec.tDestArg.getValue();
		String sErrorArg = rec.tErrorArg.getValue();
		m_iCurrentPriority = iPriority;
		m_proc[iPriority] = new ClientProcess(iTaskId,cmd,iPriority,
						      iMaxSeconds,tStart,
						      sSourceArg,sDestArg,
						      sErrorArg);
		}
	    catch (IOException e)
		{
		System.out.println( "ERROR:EXEC-IO " + e.getMessage() );
		m_server.taskRelease(iTaskId,11,m_sLocalHostName,
				     "IOException", "IOException");
		}
	    catch (Exception e)
		{
		System.out.println( "ERROR:EXEC-err " + e.getMessage() );
		m_server.taskRelease(iTaskId,11,m_sLocalHostName,"Exception",
				     "Exception");
		}
	    }
	}

	/** poll the array of processes checking each whether:
	 *  <ol><li>it exists; if not go to next process</li>
	 *  <li>it is ready to run; if so, run it and go to next process</li>
	 *  <li>it has finished; if so, go to next process</li>
	 *  <li>it has gone overtime; if so, kill it</li></ol>
	 *  @return		true if there are any processes 
	 *			not yet started or still running
	 */
    protected boolean poll()
	{
	boolean bSomeRemaining = false;
	for (int i=0; i<m_proc.length; i++)
	    {
	    if (m_proc[i] != null)
		{
		if (m_proc[i].isReadyToRun())
		    {
		    try
			{
			m_proc[i].run();
			bSomeRemaining = true;
			}
		    catch (IOException e)
			{
			System.out.println( "ERROR:EXEC-IO "
					    + e.getMessage());
			}
		    }
		else
		    {
		    int iCompletionCode = 0;
		    if (m_proc[i].isFinished())
			{
			int state = m_proc[i].getRunState();
			int iExitVal = m_proc[i].exitValue();
			if ((iExitVal > 0) && (state == ClientProcess.DONE_OK))
			    iExitVal *= -1; /* must be reported negative */
			iCompletionCode = (iExitVal == 0)
			    ? 1 
			    : (state == ClientProcess.DONE_TIMEDOUT)
			      ? 3 : iExitVal;
			}
		    else if (m_proc[i].isTimedOut())
			{
			iCompletionCode = 3;
			m_proc[i].destroy();
			}
		    else
			bSomeRemaining = true;
		    if (iCompletionCode != 0) /* OK or not, it's done */
			{
			String result = m_proc[i].getResult();
			String log = m_proc[i].getLog();
			int iTaskId = m_proc[i].getTaskId();
			if (iTaskId > 0) 
			    m_server.taskRelease(iTaskId,iCompletionCode,
						 m_sLocalHostName,result,log);

			}
		    }
		java.util.Date now = new java.util.Date();
		System.out.println("Process "+i+" state="
				   +m_proc[i].getRunState()+"="
				   +m_proc[i].getRunStateName()+" at "+now);
		}
	    }
	return bSomeRemaining;
	}

	/** examine the array of processes.
	 *  For any process which has completed (iRunState > RUNNING),
	 *  delete it.
	 */
    protected void cleanup() throws IOException
	{
	for (int i=0; i<m_proc.length; i++)
	    {
	    if ((m_proc[i] != null) 
		    && (m_proc[i].getRunState() > ClientProcess.RUNNING))
		{
		    //    System.out.println("cleanup killing proc "+i);
		m_proc[i].cleanup();
		m_proc[i] = null;
		}
	    }
	}

    protected static void usage()
	{
	System.out.println("Invoke as: \n"
			   +" java com.grs.nugget.NuggetClientDaemon [args]\n"
			   +"  argument alternatives are:\n"
			   +"	-?	show usage and exit\n"
			   +"	[opts-1] process-1 [opts-2] process-2 ...\n"
			   +"	where each process denotes a local process "
			   +"to start\n"
			   +"	  'process-n' is a comma-separated list of "
			   +"the following values\n"
			   +"		    command,priority,maxtime,starttime"
			   +"	  'opts-n' may consist of (at present):\n"
			   +"		-n # 	to start specified numbber of "
			   +"duplicate processes");
	}

	/** Called with no arguments, this simply starts the daemon
	 *	java com.grs.nugget.NuggetClientDaemon [args]
	 *  argument alternatives are:
	 *	-?	show usage and exit
	 *	[opts-1] process-1 [opts-2] process-2 ...
	 *	where each process denotes a local process to start
	 *	  'process-n' is a list of the following four values
	 *"		    command priority maxtime starttime
	 *	  'opts-n' may consist of (at present):
	 *		-n # 	to start specified numbber of duplicate 
	 *			processes
	 */
    public static void main(String[] args)
	{
	if ((args.length > 0) && (args[0] == "-?"))
	    {
	    usage();
	    /*
		}
	    else
		{
		ClientProcess[] proc = new ClientProcess[args.length];
		int iProcessNo = 0;
		for (int i=0; i<args.length; )
		    { // ignore opts for the moment
		    proc[iProcessNo++] = new ClientProcess(args[i]);
		    i += 1;
		    }
		boolean bSomeRemaining = true;
		while (bSomeRemaining)
		    {
		    bSomeRemaining = poll(procnnnnn);
		    try
			{
			Thread.sleep(10000);
			}
		    catch(InterruptedException e)
			{}
		    }
		}
	    */
	    System.exit(0);
	    }
	try
	    {
	    NuggetClientDaemon daemon = new NuggetClientDaemon(args);
	    boolean bExit = false;	/* how can it be set true? */
	    while (!bExit)
		{
		if (daemon.m_iOperatingMode != TEST_DAEMON)
		    {
		    daemon.checkForTasks();
		    }
		boolean bSomeRemaining = daemon.poll();
		daemon.cleanup();
		if (!bSomeRemaining 
		        && (daemon.m_iOperatingMode == TEST_DAEMON))
		    bExit = true;
		else
		    {
		    try
			{
			Thread.sleep(2000);
			}
		    catch(InterruptedException e)
			{}
		    }
		}
	    }
	catch ( NotBoundException nbe )
	    {
	    System.out.println( "ERROR:OBJNOTBND " + nbe.getMessage() );
	    }
	catch ( java.net.UnknownHostException uhe )
	    {
	    System.out.println( "ERROR:BADHOST The specified hostname "
				+"is unknown\n  "+uhe.getMessage());
	    }
	catch ( DbiException e)
	    {
	    System.out.println( "ERROR:DBI server database error\n  "
				+e.getMessage());
	    }
	catch ( MalformedURLException e)
	    {
	    System.out.println( "ERROR:URL malformed URL error\n  "
				+e.getMessage());
	    }
	catch ( SQLException e)
	    {
	    System.out.println( "ERROR:DB sql error\n  "
				+e.getMessage());
	    }
	catch (RemoteException e)
	    {
	    System.out.println( "ERROR:Remote error\n  "
				+e.getMessage());
	    }


	}

    }
