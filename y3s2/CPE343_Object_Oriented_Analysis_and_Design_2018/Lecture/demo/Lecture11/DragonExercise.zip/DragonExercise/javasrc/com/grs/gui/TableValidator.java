/* TableValidator.java
 *
 * Copyright  2007 by Sally Goldin and Kurt Rudahl
 *
 * $Id: TableValidator.java,v 1.2 2007/08/27 11:36:47 goldin Exp $
 * $Log: TableValidator.java,v $
 * Revision 1.2  2007/08/27 11:36:47  goldin
 * Add functionality to table including ability to sort
 *
 * Revision 1.1  2007/08/26 08:53:01  goldin
 * Add validation capabilities to the DTableField control
 *
 */

package com.grs.gui;
import javax.swing.*;
import java.awt.*;

/** 
 * This is a base class used for building table-specific validator 
 * classes. The notion is to allow different validations for each column
 * in the table. 
 */
public abstract class TableValidator implements Validator 
    {
    protected String lastErrorKey = null;
    protected String extraInfo = null;

    /** Returns true if current field value is valid, else false.
    * @param  field Field whose value is to be validated.
    */
    public boolean isValid(DragonField field)
        {
	boolean bValid = true;
	int changedRow = -1;
        int changedCol = -1;
	if (!(field instanceof DTableField))
            return bValid;
        DTableField tableFld = (DTableField) field;
        changedRow = tableFld.getChangedRow();
        if (changedRow >= 0)
            {
	    changedCol = tableFld.getChangedColumn();
            } 
        /* if changedRow and changedCol are negative, this
         * means that the validator was called on OK to
         * check table relationships.
	 */
	bValid = isValid(tableFld,changedRow,changedCol);
        return bValid;
	}
    
      /**
       * Asks the validator to display an error box showing
       * information on the last error.
       */
    public void displayLastError()
        {
	if (lastErrorKey == null)  // no error
	    return;
	Toolkit.getDefaultToolkit().beep();
	ErrorDisplay errDisplay = 
	    ApplicationManager.getErrorDisplay();
	errDisplay.showError(TextKeys.ERROR, lastErrorKey,extraInfo);
	lastErrorKey = null;
	}

      /**
       * Return true if there is an unreported error.
       */
    public boolean isErrorOutstanding()
        {
	return (lastErrorKey != null);
	}


     /**
      * Abstract method that knows how to validate each column
      * of a particular kind of table.
      * @param tableField   DTableField object used to get values
      * @param row          Row to check
      * @param col          Column to check
      * @return true if valid, false if not.
      */
    protected abstract boolean isValid(DTableField tableField, int row, int col); 

    protected static String cvsInfo = null;
    protected static void setCvsInfo()
        {
        cvsInfo = "\n@(#)  $Id: TableValidator.java,v 1.2 2007/08/27 11:36:47 goldin Exp $ \n";
	}
    }

// End of TableValidator.java

