/**
 * VecBackgroundInitializer 
 *
 * Copyright  2008  by Sally Goldin and Kurt Rudahl
 *
 * Created by Sally Goldin, 14 September 2008
 *
 *  $Id: VecBackgroundInitializer.java,v 1.1 2008/09/14 09:07:00 goldin Exp $
 *  $Log: VecBackgroundInitializer.java,v $
 *  Revision 1.1  2008/09/14 09:07:00  goldin
 *  Add new initialize to init window size conditionally on content of background file field
 *
 */

package com.grs.dragon.ui;
import com.grs.dragon.common.*;
import com.grs.gui.*;
import javax.swing.*;
import java.awt.*;

/**
 * This class implements the Initializer interface. It is used
 * to enable or disable the lines and pixels field on the
 * VEC form depending on whether there is a default value in 
 * the Background image field. 
 */
public class VecBackgroundInitializer implements Initializer
    {
      /**
       * Primary method enables or disables fields based on whether there
       * is any value in the ^FRV field.
       * @param field ^WSTXT, ^WNLN or ^WNPX field on the VEC panel.
       */
    public void setInitialValue(DragonField field)
        {
	DragonPanel parent = field.getTopLevelPanel();
	if (parent == null)  
	    {
	    return;
	    }
	DragonField fileField = parent.getField("^FRV");
	if (fileField == null)
            {
	    return;
	    }
        String value = fileField.getFieldValue();
        if ((value != null) && (value.length() > 0))
            {
	    field.setEnabled(false);
	    }
	else
	    {
	    field.setEnabled(true);
            if (field.getName().compareTo("^WSTXT") != 0)
	       field.setFieldValue(field.getDefaultValue());
	    }
        }

    protected static String cvsInfo = null;
    protected static void setCvsInfo()
        {
        cvsInfo = "\n@(#)  $Id: VecBackgroundInitializer.java,v 1.1 2008/09/14 09:07:00 goldin Exp $ \n";
	}
    }
