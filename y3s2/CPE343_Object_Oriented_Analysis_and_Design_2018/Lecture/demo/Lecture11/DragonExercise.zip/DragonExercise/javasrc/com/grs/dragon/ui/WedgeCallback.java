/* WedgeCallback.java
 *
 * Copyright  2001-2008  Goldin-Rudahl Associates
 *
 * Created by Sally Goldin, 6/6/2008
 *
 * $Id: WedgeCallback.java,v 1.3 2008/06/12 05:52:53 goldin Exp $
 * $Log: WedgeCallback.java,v $
 * Revision 1.3  2008/06/12 05:52:53  goldin
 * put limit on wedge, remove vertical control from UI
 *
 * Revision 1.2  2008/06/08 13:01:52  goldin
 * Change response panel to only allow four positions for a wedge, outside the image
 *
 * Revision 1.1  2008/06/06 09:58:20  goldin
 * new callback for Legend panel
 *
 *
 */

package com.grs.dragon.ui;
import com.grs.gui.*;
import javax.swing.*;

/** 
 *  This class implements the Callback interface. It has the effect
 *  of enabling or disabling the Vertical? checkbox on the Legend
 *  response panel, depending on whether the user selects to display
 *  a wedge or not.
 * @author  goldin*/
public class WedgeCallback implements Callback 
    {
    
      /** Primary method of a callback class.
       *  Enable or disable field based on the passed field's value.
       * @param  field Field whose value will determine the
       *   effects of the callback (display type field).
       */
    public void executeCallback(DragonField field)
        {
	DragonPanel parent = field.getTopLevelPanel();
	if (parent == null)  
	    {
	    return;
	    }
	String value = field.getFieldValue();
	if ((value == null) || (value.length() == 0))
	    return;
	// disable the relevant field
	DragonField verticalField = parent.getField("^VERTICAL");
        DragonField legPosField = parent.getField("^LEGPOS");
        DragonField wedgePosField = parent.getField("^WPOS");
        // set for Legend
	/** NOT NOW
        if (verticalField != null)
            verticalField.setEnabled(false);
	**/
        if (legPosField != null)
            legPosField.setEnabled(true);
        if (wedgePosField != null)
            wedgePosField.setEnabled(false);  
	// now enable, based on the value chosen
	if (value.startsWith("Y"))
	    {
	    /**
            if (verticalField != null)
	       {
	       verticalField.setEnabled(true);
	       verticalField.setFieldValue(verticalField.getDefaultValue());
	       verticalField.createFocusRequestor(200);
	       }
	    **/
            if (legPosField != null)
	       {
	       legPosField.setEnabled(false);
	       }
            if (wedgePosField != null)
	       {
	       wedgePosField.setEnabled(true);
	       wedgePosField.setFieldValue(wedgePosField.getDefaultValue());
	       }
	    }
	}

    protected static String cvsInfo = null;
    protected static void setCvsInfo()
        {
        cvsInfo = "\n@(#)  $Id: WedgeCallback.java,v 1.3 2008/06/12 05:52:53 goldin Exp $ \n";
	}
    }

// End of WedgeCallback.java
