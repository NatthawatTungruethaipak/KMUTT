/**
 *   DerivedGraphDatasource.java
 *   
 *     Created by S.Goldin
 *
 *    $Id: DerivedGraphDatasource.java,v 1.5 2007/01/05 07:41:57 rudahl Exp $
 *
 *    $Log: DerivedGraphDatasource.java,v $
 *    Revision 1.5  2007/01/05 07:41:57  rudahl
 *    added Whatis info
 *
 *    Revision 1.4  2004/04/04 08:27:23  rudahl
 *    Implement status display functionality
 *
 *    Revision 1.3  2004/03/09 10:20:08  rudahl
 *    Add graphing for interactively selected points
 *
 *    Revision 1.2  2004/03/02 10:39:44  rudahl
 *    convert XML to DOM, and output new data file
 *
 *    Revision 1.1  2004/02/24 12:25:11  rudahl
 *    Developing for Release 1
 *
 *
 */
package com.grs.evp;

import java.util.*;
import org.jdom.*;

/**
 * This class is used to copy and extend another
 * graph data source. It holds a reference to a parent
 * data source and uses that for most information.
 * However it can have additional data channels,
 * which it maintains in its own array list.
 */
public class DerivedGraphDatasource implements GraphDatasource
    {
    public static final int UNKNOWN = 0;
    public static final int GNUPLOT = 1;

    private int latestErrorNumber = 0;
    private String latestErrorMessage = null;

    private ArrayList myChannels = new ArrayList();

    /**
     * Datasource from which this one is "derived"
     */
    private GraphDatasource parentDatasource = null;

    private int parentSourceType = UNKNOWN;

    private Document localXmlDocument = null;
    
    /**
     * Private constructor with no args, for our own protection.
     */
    private DerivedGraphDatasource()
	{
	}

    /**
     * Constructor sets the parent data source reference
     * @param parent   Parent data source
     */
    public DerivedGraphDatasource(GraphDatasource parent)
	{
	parentDatasource = parent;
	if (parentDatasource instanceof GnuPlotGraphDatasource)
	    parentSourceType = GNUPLOT;
	}

    /**
     * Return number of channels (data columns) in
     * the data set. 
     * @return number of channels, or -1 if datasource is not initialized
     */
    public int getChannelCount()
	{
	return myChannels.size() + parentDatasource.getChannelCount();    
	}

    /**
     * Return number of samples in the data set. 
     * @return number of samples, or -1 if datasource is not initialized
     */
    public int getSampleCount()
        {
	return parentDatasource.getSampleCount();
	}    

    
    public String getSymbol()
        {
        return parentDatasource.getSymbol();
        }
    
    /**
     * Return the ChannelData object at specified index.
     * @param channelIndex   Index we're interested in
     * @return channel object or null if bad index or not initialized
     */
    public ChannelData getChannelData(int channelIndex)
	{
	ChannelData channel = null;
	if ((channelIndex < 0) || (channelIndex >= getChannelCount()))
	    {
	    latestErrorNumber = -2;
	    latestErrorMessage = "Bad channel index";	
	    }
	else if (channelIndex < parentDatasource.getChannelCount())
	    {
	    channel = parentDatasource.getChannelData(channelIndex);
	    }
	else
	    {
	    int index = channelIndex - parentDatasource.getChannelCount(); 
	    channel = (ChannelData) myChannels.get(index);
	    }
	return channel;	
	}

    /**
     * Add a new channel to the data source.
     * The new channel must be initialized by calling initMetaData
     * as a separate operation.
     */
    public ChannelData addChannel()
	{
	ChannelData channel = new ChannelData();
	myChannels.add(channel);
	return channel;
	}

    public void updateXmlDocument()
	{
	int base = parentDatasource.getChannelCount();    
	for (int column = 0; column < myChannels.size(); column++)
	    {
	    ChannelData channel = (ChannelData) myChannels.get(column);
	    updateXmlDocument(channel, base + column);
	    }
	}

   /**
    * Add information for a channel to the XML meta data.
    * This should not be called until initMetaData has
    * been called on the channel, and the data values
    * have been added to the new channel.
    * @param  channel   Channel whose metadata should be added 
    */
    private void updateXmlDocument(ChannelData channel, int columnNumber)
	{
	if (parentSourceType != GNUPLOT)
	    return;
	if (localXmlDocument == null)
	    {
	    Document parentDocument = 
             ((GnuPlotGraphDatasource) parentDatasource).getXmlDocument();
	    localXmlDocument = (Document) parentDocument.clone();
	    }
	Element channelElement = new Element("channel");
	channelElement = channelElement.setAttribute("column",
                                       String.valueOf(columnNumber));
	channelElement = channelElement.setAttribute("name",
						     channel.getName());
	channelElement = channelElement.setAttribute("type","float");
	
	Element floatElement = new Element("float");
	floatElement = floatElement.setAttribute("minAxis",
					 channel.getMinAxis());
	floatElement = floatElement.setAttribute("maxAxis",
					 channel.getMaxAxis());
	floatElement = floatElement.setAttribute("minVal",
					 channel.getMinAxis());
	floatElement = floatElement.setAttribute("maxVal",
					 channel.getMaxAxis());
	channelElement.addContent(floatElement);

	Element identificationElement = new Element("identification");
	Element generationElement = new Element("generation");
	Element sourceElement = new Element("source");
	sourceElement.setAttribute("value","EVP");
	Element sourcedateElement = new Element("sourcedate");
	sourcedateElement.setAttribute("value",new Date().toString());
	generationElement.addContent(sourceElement);
	generationElement.addContent(sourcedateElement);
	identificationElement.addContent(generationElement);
	channelElement.addContent(identificationElement);
	
	List children = localXmlDocument.getContent();
	Element datasetElement = (Element) children.get(0);
	datasetElement.addContent(channelElement);
	}

    /**
     * Get latest error number (if any)
     * @return negative number of latest error, or 0 if no error
     */
    public int getLatestErrorNumber()
	{
	return latestErrorNumber;
	}

    /**
     * Get latest error message (if any)
     * @return error message associated with latest error, or null if no error
     */
    public String getLatestErrorMessage()
	{
	return latestErrorMessage;
	}

    public GraphDatasource getParentDatasource()
	{
	return parentDatasource;
	}

    public Document getLocalXmlDocument()
	{
	return localXmlDocument;
	}

    public int getParentSourceType()
	{
	return parentSourceType;
	}

    /** 
     * Test driver routine.
     */
    public static void main(String args[])
	{
	GnuPlotGraphDatasource ds = new GnuPlotGraphDatasource();
	ds.init(args[0]);
	int num = ds.getLatestErrorNumber();
	if (num != 0)
	    {
	    System.out.println("Error: " + ds.getLatestErrorMessage());
	    }
	System.out.println("In the datasource there are " 
			   + ds.getChannelCount() 
			   + " channels");
	DerivedGraphDatasource derivedDs = new DerivedGraphDatasource(ds);
	try
	    {
	    ChannelData newChannel = derivedDs.addChannel();
	    newChannel.initMetaData("newChannel",ChannelData.FLOAT,
				null);
	    String sourceVals[] = derivedDs.getChannelData(1).getValues();
	    for (int j = 0; j < sourceVals.length; j++)
		{
		    newChannel.addValue("0" + sourceVals[j]);
		}
	    derivedDs.updateXmlDocument();
	    }
	catch (Exception ex)
	    {
	    System.out.println("Error adding channel data: " 
			       + ex.getMessage());
	    }
	try
	    {
	    GnuPlotFileWriter.write(derivedDs, "testGnuPlotWrite.dat");
	    }
	catch (Exception e)
	    {
	    System.out.println("Error in writing file: " + e.getMessage());
	    }
	}


    protected static String cvsInfo = null;
    protected static void setCvsInfo()
        {
        cvsInfo = "\n@(#)  $Id: DerivedGraphDatasource.java,v 1.5 2007/01/05 07:41:57 rudahl Exp $ \n";
	}
    }
