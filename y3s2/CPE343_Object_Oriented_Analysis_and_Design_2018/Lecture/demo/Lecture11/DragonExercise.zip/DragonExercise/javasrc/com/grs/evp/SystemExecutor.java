/**
 *   SystemExecutor.java
 *   
 *     Created by S.Goldin
 *
 *    $Id: SystemExecutor.java,v 1.2 2007/01/05 07:41:57 rudahl Exp $
 *
 *    $Log: SystemExecutor.java,v $
 *    Revision 1.2  2007/01/05 07:41:57  rudahl
 *    added Whatis info
 *
 *    Revision 1.1  2004/02/24 12:25:11  rudahl
 *    Developing for Release 1
 *
 *
 */
package com.grs.evp;

import java.io.*;

/**
 * Generic class to execute a system command or program in
 * a separate thread so that the UI doesn't freeze while 
 * we are doing the command.
 */
public class SystemExecutor extends Thread
    {

    private String latestErrorMessage = null;

    /**
     * Command to be executed.
     */
    private String command = null;

    /**
     *  listener to be notified when the run method completes.
     */   
    private ExecListener listener = null;

    /**
     * Main thread method, executes command previously 
     * established.
     */
    public void run() 
        {
	boolean bOk = false;
	if (command != null)
	    {
	    try
		{
	        Process proc = Runtime.getRuntime().exec(command);
		proc.waitFor();
		int exit = proc.exitValue();
		// System.out.println("Exit value: " + exit);
		if (exit != 0)
		    {
		    latestErrorMessage = "Error executing command " +
                                        command;
		    interrupt();
		    }
		bOk = true;
		}
	    catch (IOException ioe)
		{
		latestErrorMessage = ioe.getMessage();
		}
	    catch (InterruptedException ie)
	        {
	        if (latestErrorMessage == null)
		    latestErrorMessage = "Process Interrupted";
		}
	    }
	if (listener != null)
	    {
	    listener.notifyComplete(bOk);
	    }
	}         // end run

    public void setCommand(String cmd)
	{
	command = cmd;
	}

    public void setListener(ExecListener listener)
	{
	this.listener = listener;
	}

    public String getLatestErrorMessage()
	{
	return latestErrorMessage;
	}	

    protected static String cvsInfo = null;
    protected static void setCvsInfo()
        {
        cvsInfo = "\n@(#)  $Id: SystemExecutor.java,v 1.2 2007/01/05 07:41:57 rudahl Exp $ \n";
	}
    }

