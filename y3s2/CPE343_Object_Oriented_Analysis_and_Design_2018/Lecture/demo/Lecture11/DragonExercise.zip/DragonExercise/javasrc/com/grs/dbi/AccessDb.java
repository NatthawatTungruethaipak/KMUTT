/* AccessDb is a class to access the nugget Mysql DB
 *<P>
 * To support a new database flavor, this program does not have
 * to be modified.  Simply create the appropriate properties
 * file, named <TT>rdbms_&lt;databasename&gt;.properties</TT>.
 *<P>
 * This properties file contains the following information:
 *
 *<PRE>
 *     datasource.driver=       // Fully qualified class name of driver
 *     datasource.name=         // JDBC URL for database
 *     datasource.username=     // Username for database (may be blank)
 *     datasource.password=     // Password for database (may be blank)
 *     datasource.directory=    // Directory containing SQL strings
 *                              // to initialize database (may be blank)
 *</PRE>
 *
 * $Id: AccessDb.java,v 1.2 2007/01/05 07:41:57 rudahl Exp $
 * $Log: AccessDb.java,v $
 * Revision 1.2  2007/01/05 07:41:57  rudahl
 * added Whatis info
 *
 * Revision 1.1  2002/10/16 23:03:45  rudahl
 * initial depost from closet-java1.4.1
 *
 */

package com.grs.dbi;

import java.sql.*;
import java.util.*;
import java.text.*;
import java.lang.reflect.*;

public class AccessDb 
    {
    protected java.sql.Connection con = null;

	public AccessDb() throws DbiException
        {
        ResourceBundle bundle = ResourceBundle.getBundle("rdbms");
        String dataSource = null;
        String username   = null;
        String password   = null;
	String driver = bundle.getString("datasource.driver");
        try
	    {
	    Class.forName(driver);
            }
        catch (ClassNotFoundException e)
	    {
            System.err.println("AccessDb failed to load JDBC driver '"
			       +driver+"'");
	    e.printStackTrace();
	    throw new DbiException("unable to load JDBC driver '"+driver+"'");
            }
        try
	    {
            dataSource = bundle.getString("datasource.name");
	    if (dataSource == null)
                throw new DbiException("unable to retrieve datasourename "
				       +" from rdbms.properties");
            username  = bundle.getString("datasource.username");
	    //            password  = bundle.getString("datasource.password");
	    }
        catch (MissingResourceException e)
	    {
            System.err.println("AccessDb Unable to read resource to get data source");
	    throw new DbiException("unable to retrieve datasource.name ");
	    }
        try
	    {
	    String url = dataSource+"?user="+username;
	    //	    String url = dataSource+"?user="+username+"="+password+"=true";
            con = DriverManager.getConnection(url);
	    }
        catch (SQLException e)
	    {
	    System.err.println("AccessDb failed get DB connection");
            e.printStackTrace();
	    throw new DbiException("AccessDb failed get DB connection:\n   "
				   +e.getMessage());
	    }

        }

    public void finalize()
           throws SQLException
        {
	con.close();
	con = null;
	}

      /** get a single parameter from first matching records 
       *  from one of the DB tables.
       *  @param queryString    SQL search string
       *  @param fieldName	name of table column
       *  @return               string value from table, or ""
       */
    public String querySingleVal(String queryString, String fieldName)
		throws SQLException, DbiException, ClassNotFoundException,
		       NoSuchMethodException
        {
	java.sql.Statement select = con.createStatement();
	java.sql.ResultSet result = select.executeQuery(queryString);
	String retval = null;
	if (result.next())
	    retval = result.getString(fieldName);
	select.close();
	return retval;
	}

      /** get a single parameter from first matching records 
       *  from one of the DB tables.
       *  @param queryString    SQL search string
       *  @param fieldName	name of table column
       *  @return               string value from table, or ""
       */
    public int querySingleIntVal(String queryString, String fieldName)
		throws SQLException, DbiException, ClassNotFoundException,
		       NoSuchMethodException
        {
	java.sql.Statement select = con.createStatement();
	java.sql.ResultSet result = select.executeQuery(queryString);
	int retval = -1;
	if (result.next())
	    retval = result.getInt(fieldName);
	select.close();
	return retval;
	}

      /** get a set of records from one of the DB tables
       *  based on the sql query string
       *  @param selectString   string which is the 'where' clause of
       *                        an sql query, possibly including SORT, etc.
       *  @param recordType	subclass of DbRecord
       *  @return               vector of matching DbRecords
       */
    public Vector query(String selectString,String recordType)
		throws SQLException, DbiException, ClassNotFoundException,
		       NoSuchMethodException
        {
	Class recordClass = Class.forName(recordType);
	Vector res = new Vector();
	java.sql.Statement select = con.createStatement();
	java.sql.ResultSet result = null;
	String query = "";
	Method recordGetQueryString
	    = recordClass.getMethod("getQueryString",null);
	try
	    {
	    query = (String)recordGetQueryString.invoke(null,null);
	    //	    query = "SELECT * FROM "+table+"  WHERE "+queryString+";";
	    }
	catch (IllegalAccessException e)
	    {
	    System.err.println("IllegalAccessException on DbRecord="
			       +recordType);
	    e.printStackTrace();
	    throw new DbiException("IllegalAccessException on DbRecord="
				   +recordType+"\n   searchString='"
				   +selectString+"'");
	    }
	catch (InvocationTargetException e)
	    {
	    System.err.println("InvocationTargetException on DbRecord="
			       +recordType);
	    e.printStackTrace();
	    throw new DbiException("InvocationTargetException on DbRecord="
				   +recordType+"\n   searchString='"
				   +selectString+"'");
	    }
	try
	    {
	    query += "\n  WHERE "+selectString+";";
	    result = select.executeQuery(query);
	    }
	catch (SQLException e)
	    {
	    System.err.println("AccessDb::query SQL exception on query=\n   '"
			       +query+"'");
	    throw e;
	    }
	while (result.next())
	    {
	    try
		{
		DbRecord rec = (DbRecord)recordClass.newInstance();
		rec.init(result);
		res.addElement(rec);
		}
	    catch (InstantiationException e)
		{
		System.err.println("InstantiationException on DbRecord="
			       +recordType);
		e.printStackTrace();
		throw new DbiException("InstantiationException on DbRecord="
				       +recordType);
		}
	    catch (IllegalAccessException e)
		{
		System.err.println("IllegalAccessException2 on DbRecord="
				   +recordType);
		e.printStackTrace();
		throw new DbiException("IllegalAccessException2 on DbRecord="
				       +recordType);
		}
	    }
	select.close();
	//System.out.println("  language="+czLanguage+" key="+key
	//			       +" query="+query);
	return res;
	}

      /** insert a new record into DB
       *  @param dbRecord	DbRecord of data to insert
       *  @param recordType	subclass of DbRecord
       *  @return		insert status:	rowcount if OK 
       *					-1 is already present
       *					-2 is other error (?)
       */
    public int insert(DbRecord dbRecord, String recordType)
		throws SQLException, DbiException, ClassNotFoundException,
		       NoSuchMethodException
        {
	Class recordClass = Class.forName(recordType);
	int retval = 0;
	String command = "";
	Class[] classlist = new Class[] {getClass()};
	Method recordGetInsertString
	    = recordClass.getMethod("getInsertString",new Class[]{getClass()});
	try
	    {
	    command = (String)recordGetInsertString.invoke(dbRecord,
							   new Object[]{this});
	    System.out.println("insert '"+command+"'");
	    }
	catch (IllegalAccessException e)
	    {
	    System.err.println("IllegalAccessException on DbRecord="
			       +recordType);
	    e.printStackTrace();
	    throw new DbiException("IllegalAccessException on DbRecord="
				   +recordType);
	    }
	catch (InvocationTargetException e)
	    {
	    System.err.println("InvocationTargetException on DbRecord="
			       +recordType);
	    e.printStackTrace();
	    throw new DbiException("InvocationTargetException on DbRecord="
				   +recordType);
	    }
	retval = execute(command);
	if (retval > 0)
	    {
	    Method recordGetLatestIntKey
		= recordClass.getMethod("getLatestIntKey",null);
	    try
		{
		Integer i = (Integer)recordGetLatestIntKey.invoke(null,null);
		retval = i.intValue();
		}
	    catch (IllegalAccessException e)
		{
		throw new DbiException("IllegalAccessException on DbRecord="
				       +recordType);
		}
	    catch (InvocationTargetException e)
		{
		throw new DbiException("InvocationTargetException on DbRecord="
				       +recordType);
		}
	    }
	return retval;
	}

      /** execute an SQL command (update, insert, delete)
       *  @param command	command to execute
       *  @return		update status:	rowcount if OK 
       *					-1 is already present
       *					-2 is other error (?)
       */
    public int execute(String command) throws SQLException
        {
	java.sql.Statement select = con.createStatement();
	int retval = select.executeUpdate(command);
	select.close();
	return retval;
	}

      /** update a DB record
       *  @param dbRecord	DbRecord of data to update
       *  @param recordType	subclass of DbRecord
       *  @return		update status:	rowcount if OK 
       *					-1 is already present
       *					-2 is other error (?)
       */
    public int update(DbRecord dbRecord, String recordType)
		throws SQLException, DbiException, ClassNotFoundException,
		       NoSuchMethodException
        {
	Class recordClass = Class.forName(recordType);
	int retval = 0;
	String command = "";
	Method recordGetUpdateString
	    = recordClass.getMethod("getUpdateString",null);
	try
	    {
	    command = (String)recordGetUpdateString.invoke(dbRecord,null);
	    System.out.println("update '"+command+"'");
	    }
	catch (IllegalAccessException e)
	    {
	    System.err.println("IllegalAccessException on DbRecord="
			       +recordType);
	    e.printStackTrace();
	    throw new DbiException("IllegalAccessException on DbRecord="
				   +recordType);
	    }
	catch (InvocationTargetException e)
	    {
	    System.err.println("InvocationTargetException on DbRecord="
			       +recordType);
	    e.printStackTrace();
	    throw new DbiException("InvocationTargetException on DbRecord="
				   +recordType);
	    }
	retval = execute(command);
	return retval;
	}

      /** delete a DB record
       *  @param selectString   string which is the 'where' clause of
       *                        an sql query, possibly including SORT, etc.
       *  @param recordType	subclass of DbRecord
       *  @return		insert status:	rowcount if is OK 
       *					-1 is already present
       *					-2 is other error (?)
       */
    public int delete(String selectString, String recordType)
		throws SQLException, DbiException, ClassNotFoundException,
		       NoSuchMethodException
        {
	Class recordClass = Class.forName(recordType);
	java.sql.Statement select = con.createStatement();
	int retval = 0;
	String command = "";
	Method recordGetDeleteString
	    = recordClass.getMethod("getDeleteString",null);
	try
	    {
	    command = (String)recordGetDeleteString.invoke(null,null);
	    command += " WHERE "+selectString+";";
	    System.out.println("delete '"+command+"'");
	    }
	catch (IllegalAccessException e)
	    {
	    System.err.println("IllegalAccessException on DbRecord="
			       +recordType);
	    e.printStackTrace();
	    throw new DbiException("IllegalAccessException on DbRecord="
				   +recordType);
	    }
	catch (InvocationTargetException e)
	    {
	    System.err.println("InvocationTargetException on DbRecord="
			       +recordType);
	    e.printStackTrace();
	    throw new DbiException("InvocationTargetException on DbRecord="
				   +recordType);
	    }
	retval = select.executeUpdate(command);
	select.close();
	return retval;
	}

    public static void main(String args[])
	{
	int iArgno = 0;
	boolean bExplain = false;
	Properties p = System.getProperties();
	p.list(System.out);
	try
	    {
	    AccessDb access = new AccessDb();
	    int st;
	    /*
	    st = access.insert(new DbTaskRecord(true, // tState init 'r' or 'd'
						"tstCom", // task to be exec
						null,   // opt. input src
						null,   // opt. result dest
						null,   // optional stderr
						null,   // time to begin, or null
						"closet", // node which created task
						"*",    // '' or node or *
						null,   // special capabi reqd
						6,      // int value from 0-10
						null,   // date task must be done
						8,	// latePriority
						300,	// secs b4 1st taskAcc
						3600),  //max secs node is perm
			  "com.grs.nugget.DbTaskRecord");
	    System.out.println("Insert status="+st);
	    */
	    Vector v = access.query("tID >= 0","com.grs.nugget.DbTaskRecord");
	    System.out.println("found "+v.size()+" records");

	    for (int i=0; i<v.size(); i++)
		{
		DbRecord r = (DbRecord)v.elementAt(i);
		r.dump("AccessDb test using DbTaskRecord");
		}
	    st = access.delete("tID=89","com.grs.nugget.DbTaskRecord");
	    System.out.println("Delete status="+st);
	    }
        catch (Exception e)
	    {
            e.printStackTrace();
	    }
	}


    protected static String cvsInfo = null;
    protected static void setCvsInfo()
        {
        cvsInfo = "\n@(#)  $Id: AccessDb.java,v 1.2 2007/01/05 07:41:57 rudahl Exp $ \n";
	}
    }


