/* dbPrereqRecord is an object which represents a record from the
 * prerequisites table.
 *
 * $Id: DbPrereqRecord.java,v 1.1 2002/10/16 23:04:04 rudahl Exp $
 * $Log: DbPrereqRecord.java,v $
 * Revision 1.1  2002/10/16 23:04:04  rudahl
 * initial depost from closet-java1.4.1
 *
 */

package com.grs.nugget;

import java.sql.*;
import java.util.*;
import java.text.*;
import com.grs.dbi.*;

public class DbPrereqRecord extends DbRecord
    {
    public DbField tID 
	= new DbField("tID","INT NOT NULL","Task",DbField.DBV_INT,
		      "task which has prerequisites");
    public DbField prereqID 
	= new DbField("prereqID","INT NOT NULL","Task",DbField.DBV_INT,
		      "task which are prerequisites");

	/** This constructor, combined with init(ResultSet),
	 *   is used for reading from the DB
	 */
    public DbPrereqRecord() throws DbiException  { super(); init(); } 

    public void init(ResultSet result) throws SQLException, DbiException
	{
	super.init(result);
	}

	/** This constructor is used for creating a record to INSERT
	 *  into the DB.
	 */
    public DbPrereqRecord(int iTaskId,int iPrereqId)
		throws DbiException
	{
	init();
	if ((iTaskId <= 0) || (iPrereqId <= 0))
	    throw new DbiException("Unable to create INSERT record; "
				   +"missing args");
	tID.setIntValue(iTaskId);
	prereqID.setIntValue(iPrereqId);
	}

	/** There is no constructor for creating a record to UPDATE
	 *  the DB.
	 */
	/** Return a string which is the first part of an SQL query
	 *  appropriate to this class and associated DB table(s)
	 */ 
    public static String getQueryString() 
	{ return "SELECT * FROM prerequisites "; }

	/** Return a string which is the first part of an SQL query
	 *  appropriate to this class and associated DB table(s)
	 */ 
    public static String getDeleteString() 
	{ return "DELETE FROM prerequisites "; }

	/** Return a string which is the INSERT command for this record
	 *  and this class and associated DB table(s)
	 */ 
    public String getInsertString(AccessDb access) 
	throws DbiException, SQLException, ClassNotFoundException,
	       NoSuchMethodException

	{
	if ((tID.getIntValue() <= 0) || (prereqID.getIntValue() <= 0))
	    throw new DbiException("Invalid record to insert; "
				   +"has incorrect tID");
	String retval = "INSERT INTO prerequisites(\n"
	    +"tID,prereqID"
	    +")\n VALUES \n   ("
	    +tID.getIntValue()+","
	    +prereqID.getIntValue()+");";

	return retval;
	}

	/** There is no string which is the UPDATE command for this record
	 *  and this class and associated DB table(s)
	 */
    public void dump(String czTitle)
	{
	System.out.println("Dump of DbPrereqRecord "+czTitle);
	System.out.println(toString());
	}
    }
