/**
 *  StatusWindow
 *   
 *     Created by S.Goldin & K. Rudahl
 *
 *    $Id: StatusWindow.java,v 1.1 2004/04/04 08:27:10 rudahl Exp $
 *
 *    $Log: StatusWindow.java,v $
 *    Revision 1.1  2004/04/04 08:27:10  rudahl
 *    Start working on status display functionality
 *
 */

package com.grs.evp;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;


/**
 * This class displays information about the graphs at the
 * the current position of the vertical bar cursor.
 * @author  rudahl
 */
public class StatusWindow extends javax.swing.JFrame
{
    private static final String TITLE = "Symbol: ";
    private static final String XRANGE = "Range: ";
    private static final String XVALUE = "Cursor Location: ";
    private static final String YVALUE = "Cursor Value: ";
    private static final String YRANGE = "Data Range: ";
    private EVP parentApp = null;
    private JLabel titleLabel = null;
    private JLabel xLabel = null;
    private JLabel yValueLabel = null;
    private JLabel yRangeLabel = null;
    private Dimension prefSize = new Dimension(320,200);
    
    /** Creates a new instance of StatusWindow */
    public StatusWindow (EVP parent)
        {
        parentApp = parent;
        buildUI();
        }   
    
    private void buildUI()
        {
        JPanel outerPanel = new JPanel(new GridLayout(0,1));
        outerPanel.setBackground(Color.white);
        outerPanel.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
        JPanel xPanel = new JPanel(new GridLayout(0,1));
        xPanel.setBackground(Color.white);
        titleLabel = new JLabel(TITLE + " " + XRANGE);
        titleLabel.setBackground(Color.white);
        xPanel.add(titleLabel);
        xLabel = new JLabel(XVALUE);
        xLabel.setBackground(Color.white);
        xPanel.add(xLabel);
        outerPanel.add(xPanel, BorderLayout.NORTH);
        JPanel yPanel = new JPanel(new GridLayout(0,1));
        yPanel.setBackground(Color.white);
        yValueLabel = new JLabel(YVALUE);
        yValueLabel.setBackground(Color.white);
        yPanel.add(yValueLabel);
        yRangeLabel = new JLabel(YRANGE);
        yRangeLabel.setBackground(Color.white);  
        yPanel.add(yRangeLabel);
        outerPanel.add(yPanel, BorderLayout.SOUTH);
        getContentPane().add(outerPanel,BorderLayout.CENTER);
        pack();
        Point parentPos = parentApp.getLocation();
        setLocation(new Point(parentPos.x, parentPos.y+200));
        }
    
    public Dimension getPreferredSize()
        {
        return prefSize;
        }
    
    /**
     *  Update the values in the status display based
     *  on info supplied from the parent
     *  @param   mouseMode  Tells us the interactive mode (currently not used)
     *  @param   sampleNum  Which X position is at the cursor?
     */
    public void update(int mouseMode, int sampleNum)
        {
        String symbol = parentApp.getSymbol();
        String xRange = parentApp.getXRange();
        titleLabel.setText(TITLE + " " + symbol + "    " + XRANGE + " " + xRange);
        String xVal = parentApp.getXValue(sampleNum);
        xLabel.setText(XVALUE + " " + xVal);
        String yVal = parentApp.getYValue(sampleNum,1);
        yValueLabel.setText(YVALUE + " " + yVal);
        String yRange = parentApp.getYRange(1);
        yRangeLabel.setText(YRANGE + " " + yRange);
        pack();
        }
}
