/**
 *   GraphGenerator.java
 *   
 *     Created by S.Goldin
 *
 *    $Id: GraphGenerator.java,v 1.3 2007/01/05 07:41:57 rudahl Exp $
 *
 *    $Log: GraphGenerator.java,v $
 *    Revision 1.3  2007/01/05 07:41:57  rudahl
 *    added Whatis info
 *
 *    Revision 1.2  2004/03/09 10:20:08  rudahl
 *    Add graphing for interactively selected points
 *
 *    Revision 1.1  2004/02/24 12:25:11  rudahl
 *    Developing for Release 1
 *
 *
 */
package com.grs.evp;

import javax.swing.*;
import java.awt.*;

/**
 * Class that will create or read in an image
 * of a graph to be displayed and manipulated in
 * EVP.
 */
public class GraphGenerator extends JComponent 
			    implements ExecListener	     
    {
    /**
     * Status of latest plot.
     * 0 = not yet complete (or not started)
     * >0 = complete and successful
     * <0 = complete but error occurred.
     */ 
    private int plotStatus = 0;
    	
    private Image imageFromDisk = null;

    private SystemExecutor processor = null;

    /**
     * Get an image from a file.
     * @param filename  File holding image (JPG, PNG, etc)
     * @return image read or null if error occured.
     */
    public Image getGraphImage(String filename)
	{
	MediaTracker tracker = new MediaTracker(this);
	imageFromDisk = Toolkit.getDefaultToolkit().getImage(filename);
	tracker.addImage(imageFromDisk, 0);
	try
	    {
	    tracker.waitForAll();
	    }
	catch (InterruptedException e)
	    {
	       // don't do anything, but set imageFromDisk to null
	    imageFromDisk = null;
	    }
	return imageFromDisk;
	}

    /**
     * Create a data source initialized from the data in dataFileName.
     * Then create a control file, and run GnuPlot to create the
     * graph image. 
     * @param dataFileName   Data file to use for plotting
     * @param dataColumns    Column numbers for the Y axis ( 2-based)
     * @return               Reference to the data source created
     *                         and initialized. 
     * @throws               exception if there's an error in the process.
     */	
    public GnuPlotGraphDatasource createGnuPlotImage(String dataFileName, 
						     int[] dataColumns)
	                           throws Exception
	{
	GnuPlotGraphDatasource ds = new GnuPlotGraphDatasource();
	ds.init(dataFileName);
	int num = ds.getLatestErrorNumber();
	if (num != 0)
	    {
	    throw new Exception("Error: " + ds.getLatestErrorMessage());
	    }
	String controlFile = ds.createControlFile(dataColumns);
	if (controlFile == null)
	    {
	    throw new Exception("Error: "+ds.getLatestErrorMessage());
	    }
	plotStatus = 0;
	String plotCommand = "/usr/bin/gnuplot " + controlFile;
	processor = new SystemExecutor();
	processor.setCommand(plotCommand);
	processor.setListener(this);
	processor.run();
	int count = 0;
	while (plotStatus == 0)
	    count++;
	return ds;
	}

   /**
    * Method from the ExecListener interface, called when
    * plot is done.
    */
    public void notifyComplete(boolean bOk)
	{
	plotStatus = (bOk) ? 1 : -1;
	if (!bOk)
	    System.out.println(processor.getLatestErrorMessage());
	}

    public int getPlotStatus()
	{
	return plotStatus;
	}

    protected static String cvsInfo = null;
    protected static void setCvsInfo()
        {
        cvsInfo = "\n@(#)  $Id: GraphGenerator.java,v 1.3 2007/01/05 07:41:57 rudahl Exp $ \n";
	}
    }
