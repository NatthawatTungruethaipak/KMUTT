/* GeoTiffCallback.java
 *
 *    ~~ Copyright 2010 Kurt Rudahl and Sally Goldin
 *
 *	All rights are reserved. Copying or other reproduction of
 *	this program except for archival purposes is prohibited
 *	without the prior written consent of Goldin-Rudahl Associates.
 *
 *			  RESTRICTED RIGHTS LEGEND
 *
 *	Use, duplication, or disclosure by the U.S. Government
 *	is subject to restrictions as set forth in
 *	paragraph (b) (3) (B) of the Rights in Technical
 *	Data and Computer Software clause in DAR 7-104.9(a).
 *
 *	The moral right of the copyright holder is hereby asserted
 *   ~~ EndC
 *
 *
 * $Id: GeoTiffCallback.java,v 1.2 2010/12/24 12:43:21 goldin Exp $
 * $Log: GeoTiffCallback.java,v $
 * Revision 1.2  2010/12/24 12:43:21  goldin
 * Get callback working
 *
 * Revision 1.1  2010/12/20 11:20:36  goldin
 * Working on callback for ORDER field
 *
 *
 */

package com.grs.dragon.ui;
import com.grs.gui.*;
import javax.swing.*;

/** 
 *  This class implements the Callback interface. It has the effect
 *  of enabling or disabling the Band Order field on the
 *  Export Images panel. The field should be enabled if and only
 *  if the user has entered exactly three bands and
 *  the user has selected the GeoTiff output type.
 *  The callback will be associated with both the file field and
 *  the output type field
 * @author  goldin*/
public class GeoTiffCallback implements Callback 
    {
    
      /** Primary method of a callback class.
       *  Enable or disable fields based on the passed field's value.
       * @param  field Field whose value will determine the
       *   effects of the callback.
       */
    public void executeCallback(DragonField field)
        {
        String fileContents ="";
	String type = "";
	DragonPanel parent = field.getTopLevelPanel();
	if (parent == null)  
	    {
	    return;
	    }
	// get the relevant fields
	DMultiFileField fileField = (DMultiFileField) field;
	DragonField typeField = parent.getField("^FT");
	DragonField orderField = parent.getField("^ORDER");
	if ((fileField == null) || (orderField == null) || (typeField == null))
            {
	    return;
	    }
	fileContents = fileField.getMultiFieldValue();
	type = typeField.getFieldValue();
	if ((fileContents == null) || (fileContents.length() == 0) ||
            (type == null) || (type.length() == 0))
	    {
	    return;
	    }
	if (!type.startsWith("G"))
	    return;
        String filenames[] = fileContents.split("\n");
	if (filenames.length == 3)
	    {
	    orderField.setEnabled(true);
	    orderField.setFieldValue("B");
	    }
	else
	    {
	    orderField.setEnabled(false);
	    }
	}

    protected static String cvsInfo = null;
    protected static void setCvsInfo()
        {
        cvsInfo = "\n@(#)  $Id: GeoTiffCallback.java,v 1.2 2010/12/24 12:43:21 goldin Exp $ \n";
	}
    }

// End of GeoTiffCallback.java

