/**
 *  GenericImageFileWriter
 *
 *  Copyright 2002 by Goldin-Rudahl Associates
 *
 *  Created 3/7/2002 by Sally Goldin
 *
 *  $Id: GenericImageFileWriter.java,v 1.1 2002/03/08 00:39:05 goldin Exp $
 *  $Log: GenericImageFileWriter.java,v $
 *  Revision 1.1  2002/03/08 00:39:05  goldin
 *  Begin development of image file classes
 *
 */

package com.grs.imgfiles;
import java.awt.*;
import java.awt.image.*;
import javax.swing.*;
import java.io.*;

/**
 * This simple subclass of image file writer writes
 * the image data to three bare binary (1 byte/pix) 
 * data files, with no header.
 */
public class GenericImageFileWriter extends ImageFileWriter
    {
      /**
       * Explicit constructor, just calls superclass
       */
    public GenericImageFileWriter(Image image, String filename)
        {
	super(image,filename);
	}

      /**
       * This is the primary method for this class. It
       * uses the filename passed in the constructor to
       * create three filenames, and writes the correct data
       * to each one. Since this is top to bottom, left to right
       * image, we can write all the data in a single
       * operation; we don't need to treat it row by row.
       * Returns true if ok, false if not.
       */
    public boolean writeImage()
        {
	boolean bOk = true;
	String fnameRoot = null;
	String fnameExt = null;
	int pos = imgFilename.lastIndexOf(".");
	if (pos >= 0)
	    {
	    fnameRoot = imgFilename.substring(0,pos);
	    fnameExt = imgFilename.substring(pos);
	    }
	else
	    {
	    fnameRoot = imgFilename;
	    fnameExt = ".GEN";
	    }
	String redFname = fnameRoot + "R" + fnameExt;  
	String greenFname = fnameRoot + "G" + fnameExt;  
	String blueFname = fnameRoot + "B" + fnameExt;  
	int datalen = imgPixels.length;
	createComponentArrays();  // base class method populates rBytes etc.
	try
	    {
	    BufferedOutputStream out = new BufferedOutputStream
                         (new FileOutputStream(redFname));
	    out.write(rBytes,0, datalen);
	    out.close();
	    out = new BufferedOutputStream
                         (new FileOutputStream(greenFname));
	    out.write(gBytes,0, datalen);
	    out.close();
	    out = new BufferedOutputStream
                         (new FileOutputStream(blueFname));
	    out.write(bBytes,0, datalen);
	    out.close();
	    }
	catch (IOException ioe)
	    {
            bOk = false;	      
	    }
	finally
	    {
	    return bOk;
	    }
	}

      /**
       * Test driver method
       * Assumes input image file (jpg) and output name passed on cmd line
       */
    public static void main(String args[])
        {
	if (args.length < 2)
	    {
	    System.out.println(
              "Usage: java GenericImageFileWriter <inputJpg> <outputfile>");
	    System.exit(0);
	    }
	File testFile = new File(args[0]);
	if (!testFile.exists())
	    {
	    System.out.println("Input image file " + args[0] +
			       " does not exist.");
	    System.exit(0);
	    }
	Image baseImage = new ImageIcon(args[0]).getImage();
	if (baseImage == null)
	    {
	    System.out.println("Error reading image file");
	    System.exit(0);
	    }
	GenericImageFileWriter imgWriter = 
            new GenericImageFileWriter(baseImage,args[1]);
	if (!imgWriter.isInitialized())
	    {
	    System.out.println("Error in ImageFileWriter constructor");
	    System.exit(0);
	    }
	System.out.println("Image is " + imgWriter.getWidth() + " by " +
			   imgWriter.getHeight() + " pixels ");
	imgWriter.writeImage();
	System.out.println("Done");
	System.exit(0);
	}
    }
