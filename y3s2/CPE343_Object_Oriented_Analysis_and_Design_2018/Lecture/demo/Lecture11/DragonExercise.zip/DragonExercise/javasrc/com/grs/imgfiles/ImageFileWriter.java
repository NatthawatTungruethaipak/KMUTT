/**
 *  ImageFileWriter
 *
 *  Copyright 2002 by Goldin-Rudahl Associates
 *
 *  Created 3/7/2002 by Sally Golding
 *
 *  $Id: ImageFileWriter.java,v 1.1 2002/03/08 00:39:05 goldin Exp $
 *  $Log: ImageFileWriter.java,v $
 *  Revision 1.1  2002/03/08 00:39:05  goldin
 *  Begin development of image file classes
 *
 */

package com.grs.imgfiles;
import java.awt.*;
import java.awt.image.*;

/**
 * This is the abstract base class for a set of classes that
 * know how to write Java Images to image files of various
 * formats. 
 */
public abstract class ImageFileWriter extends PixelGrabber
    {
      /**
       * Filename where we want to save the image data
       */
    protected String imgFilename = null;

      /**
       * Image dimensions in pixels
       */
    protected int imgWidth = 0;
    protected int imgHeight = 0;

      /**
       * Image Data array
       */
    protected int imgPixels[] = null;

      /**
       * Component arrays - useful for some formats -
       * initialized by createComponentArrays
       */
    protected byte rBytes[] = null;
    protected byte gBytes[] = null;
    protected byte bBytes[] = null;
      
      /**
       * Flag to indicate whether the writer has got its data.
       */
    protected boolean bInitialized = false;

      /**
       * Constructor gets all the data from the passed image,
       * initializes the width and the height.
       * @param image  The image to serve as the source of the data.
       * @param filename Filename (possibly a prefix) where img data
       *                 should be written, including path.
       */
    public ImageFileWriter(Image image, String filename)
        {
	super(image,0,0,-1,-1,true);
	imgFilename = filename;
	try 
	    {
	    boolean bOk = grabPixels();
	    if (bOk == false)
	        return;
            Object pixarray = getPixels();
	    imgWidth = getWidth();
	    imgHeight = getHeight();
	    imgPixels = (int[]) pixarray;
	    bInitialized = true;
	    }
	catch (InterruptedException ie)
	    {
	    return;
	    }
	}

      /**
       * Method that does the writing. This must be implemented
       * for each subclass. Returns true if successful, else false.
       */
    public abstract boolean writeImage();
        

      /**
       * Utility method useful for many image formats.
       * separates the imgPixel data into R, G, and B arrays.
       * Assumes that we are using the default RGB color model.
       */
    protected void createComponentArrays()
        {
	int datalen = imgPixels.length;
	rBytes = new byte[datalen];
	gBytes = new byte[datalen];
	bBytes = new byte[datalen];
	for (int i = 0; i < datalen; i++)
	    {
	    int dataval = imgPixels[i];
	    rBytes[i] = (byte) ((dataval & 0x00FF0000) >> 16);
	    gBytes[i] = (byte) ((dataval & 0x0000FF00) >> 8);
	    bBytes[i] = (byte) (dataval & 0x000000FF);
	    }
	}

      /**
       * Access methods
       */
    public boolean isInitialized()
        {
	return bInitialized;
	}

    public int getImgWidth()
        {
	return imgWidth;
	}

    public int getImgHeight()
        {
	return imgHeight;
	} 
    }
