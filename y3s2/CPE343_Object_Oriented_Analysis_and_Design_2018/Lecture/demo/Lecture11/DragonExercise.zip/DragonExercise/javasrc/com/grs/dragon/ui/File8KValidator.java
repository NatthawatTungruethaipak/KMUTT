/* File8KValidator.java
 *
 * ~~ Copyright  2008-2010  by Sally Goldin & Kurt Rudahl
 * ~~ EndC
 *
 * Created by Sally Goldin, 8 Sept 2008
 *
 * $Id: File8KValidator.java,v 1.2 2010/11/19 13:07:37 rudahl Exp $
 * $Log: File8KValidator.java,v $
 * Revision 1.2  2010/11/19 13:07:37  rudahl
 * upped limit for GEOM ops to 32K
 *
 * Revision 1.1  2008/09/08 10:34:03  goldin
 * New validator to prohibit files of > 8000x8000 size in vector ops
 * 2010-11-19 ktr revised to 32K
 */

package com.grs.dragon.ui;
import javax.swing.*;
import java.awt.*;
import com.grs.gui.*;
import java.io.*;

/** 
*   This classimplements the Validator interface. It is used
*   to validate the correctness of files, given the constraints
*   associated with the file field. This is a specialized subclass
*   which rejects images that are larger than 8000 x 8000.
*/
public class File8KValidator extends FileValidator 
    {
 
     /**
       * Constructor simply calls superclass
       */
    public File8KValidator()
        {
	super();    
	}

    /** Returns true if current field value is valid, else false.
    * @param  field Field whose value is to be validated.
    */
    public boolean isValid(DragonField field)
        {
        boolean bOk = super.isValid(field);
        if (bOk)
            {
	    DImageHeader thisHeader = null;
            DragonUI mainApp = DragonUI.currentApplication;
	    String value = field.getFieldValue();
	    if ((value != null) || (value.length() > 0))
		{
   	        // determine if there is a current header and if so,
	        // if that is what the user requested
                DImageHeader header = mainApp.getMemoryHeader();
                if ((header != null) && (header.isInitialized()) &&
	           (value.equals("=M")))
                    {
                    thisHeader = header;
                    }
		else 
		    {
		    if (value.startsWith("=")) 
			value = 
			    DragonUI.currentApplication.getStatusManager().getMemoryFileEquivalent(value);
		    thisHeader = new DImageHeader(value);
		    }
		if (thisHeader != null)
                    {
		    if ((thisHeader.getNLines() > 32000) ||
			(thisHeader.getNLines() > 32000))
			{
			bOk = false;
		        lastErrorKey = "%e7000.26";
		        lastErrorFile = value;
			}
                    }
		}
            }
	return bOk;
	}

		       

    protected static String cvsInfo = null;
    protected static void setCvsInfo()
        {
        cvsInfo = "\n@(#)  $Id: File8KValidator.java,v 1.2 2010/11/19 13:07:37 rudahl Exp $ \n";
	}
    }

// End of File8KValidator.java

