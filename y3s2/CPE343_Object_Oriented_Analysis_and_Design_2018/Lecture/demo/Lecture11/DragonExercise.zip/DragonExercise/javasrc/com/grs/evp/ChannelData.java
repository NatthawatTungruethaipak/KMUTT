/**
 *   ChannelData.java
 *   
 *     Created by S.Goldin
 *
 *    $Id: ChannelData.java,v 1.2 2007/01/05 07:41:57 rudahl Exp $
 *
 *    $Log: ChannelData.java,v $
 *    Revision 1.2  2007/01/05 07:41:57  rudahl
 *    added Whatis info
 *
 *    Revision 1.1  2004/02/24 12:25:11  rudahl
 *    Developing for Release 1
 *
 *
 */
package com.grs.evp;

import java.util.*;

/**
 * This class holds data and metadata for one column
 * of a data source. The same structure is used regardless
 * of where the data originally came from.
 */
public class ChannelData
    {
    /**
     * constants used to identify data types
     */
    public static final int DATE = 1;
    public static final int FLOAT = 2;
    public static final int INTEGER = 3;

    /* The following member data items represent metaData about the 
     * channel.
     */

    /**
     * If true, meta data has been initialized.
     */
    boolean bMetaInitialized = false;

    /**
     *  Name of the data in this channel, as specified by the
     *  the data source. e.g. "Price"
     */
    private String name = null;

    /**
     *  Intrinsic type of the data in the column (all stored as Strings)
     */
    private int dataType = 0;

    /**
     * Ancillary data used for plotting
     */
    private String minAxis = null;
    private String maxAxis = null;
    private String minVal = null;
    private String maxVal = null;
	
    /**
     * Format information for date or time times
     */
    private String dateFormat = null;

    /**
     * Actual data for the column
     */
    private ArrayList dataValues = new ArrayList();

    /** 
     * Reference to owning GraphDatasource
     */
    private GraphDatasource owner = null;

    /**
     * Initialize the meta data information
     * @param name       name of the channel based on data source
     * @param dataType   type of the channel based on data source
     * @param dateFormat format of the date strings if dataType == DATE, 
     *			 or null
     */
    public void initMetaData(String name, int dataType, String dateFormat)
	throws Exception
	{
	if (bMetaInitialized)
	    {
	    throw new Exception("Channel is already initialized"); 
	    }
	this.name = name;
	this.dataType = dataType;
	this.dateFormat = dateFormat;
	bMetaInitialized = true;
	}

    /**
     * Add next value to the data set. Once the first one has been
     * added, the channel is considered to be 'initialized'
     * @param value	  string value of next element
     */
    public void addValue(String value)
	{
	dataValues.add(value);
	}
		
    /**
     * Return specified data element as a string
     * @param index of data element
     * @return string value of element
     * @throws exception if invalid index
     */
    public String getValue(int index) throws Exception
	{
	if (! isInitialized() || (index < 0) || (index >= getCount()))
	    throw new Exception("Invalid index "+index
				      +" or channel not initialized");
	return (String)dataValues.get(index);
	}

    /**
     * Return all data elements as a string array
     * @return string array of values
     * @throws exception if not initialized
     */
    public String[] getValues() throws Exception
	{
	if (! isInitialized())
	    throw new Exception("Channel not initialized");
	String results[] = new String[getCount()];
	results = (String[]) dataValues.toArray(results);
	return results;
	}

    /**
     * Return all data elements as a double array if appropriate
     * @return array of values as doubles
     * @throws exception if not initialized or wrong type
     */
    public double[] getNumericValues() throws Exception
	{
	if (! isInitialized())
	    throw new Exception("Channel not initialized");
	if (dataType != FLOAT)
	    throw new Exception("Channel wrong data type");
	int size = getCount();
	int j=0;
	double retvals[] = new double[size];
	try
	    {
	    for (j=0; j<size; j++)
	        {
		retvals[j] = Double.parseDouble((String)dataValues.get(j));
		}
	    }
	catch(NumberFormatException e)
	    {
	    throw new Exception("Bad numeric value element "+j
				+" has value '"+(String)dataValues.get(j)+"'");
	    }
	return retvals;
	}

    /**
     * Check to see if the channel has been fully intialized (meta data
     * and data values).
     * @return true if both data and meta data initialized
     */
    public boolean isInitialized()
	{
	return (isMetaInitialized() && areValuesInitialized());    
	}

    /**
     * Return number of values in the channel data.
     * @return number of values in the channel data.
     */
    public int getCount()
	{
	return dataValues.size();
	}

    public boolean isMetaInitialized()
	{
	return bMetaInitialized;
	}

    public boolean areValuesInitialized()
	{
	return (getCount() > 0);
	}

    public String getName()
	{
	return name;
	}

    public int getDataType()
	{
	return dataType;    
	}

    public String getDateFormat()
	{
	return dateFormat;    
	}

    public String getMinVal()
	{
	return minVal;    
	}

    public void setMinVal(String value)
	{
	minVal = value;    
	}

    public String getMaxVal()
	{
	return maxVal;
	}

    public void setMaxVal(String value)
	{
	maxVal = value;    
	}

    public String getMinAxis()
	{
	return minAxis;    
	}

    public void setMinAxis(String value)
	{
	minAxis = value;    
	}

    public String getMaxAxis()
	{
	return maxAxis;
	}

    public void setMaxAxis(String value)
	{
	maxAxis = value;    
	}

    public GraphDatasource getOwner()
        {
	return owner;
	}

    public void setOwner(GraphDatasource owner)
        {
	this.owner = owner;
	}


    protected static String cvsInfo = null;
    protected static void setCvsInfo()
        {
        cvsInfo = "\n@(#)  $Id: ChannelData.java,v 1.2 2007/01/05 07:41:57 rudahl Exp $ \n";
	}
    }
