/**
 *  EVP.java
 *   
 *     Created by S.Goldin
 *
 *    $Id: EVP.java,v 1.7 2007/01/05 07:41:57 rudahl Exp $
 *
 *    $Log: EVP.java,v $
 *    Revision 1.7  2007/01/05 07:41:57  rudahl
 *    added Whatis info
 *
 *    Revision 1.6  2004/04/04 08:27:23  rudahl
 *    Implement status display functionality
 *
 *    Revision 1.5  2004/03/25 12:52:21  rudahl
 *    Rework scaling to be more consistent and refactor into child classes
 *
 *    Revision 1.4  2004/03/24 08:39:03  rudahl
 *    added vert bar cursor functionality
 *
 *    Revision 1.3  2004/03/09 10:20:08  rudahl
 *    Add graphing for interactively selected points
 *
 *    Revision 1.2  2004/02/24 16:05:05  rudahl
 *    fixed error report
 *
 *    Revision 1.1  2004/02/24 12:25:11  rudahl
 *    Developing for Release 1
 *
 *
 */

package com.grs.evp;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.text.*;

public class EVP extends JFrame
    {
    private static Dimension prefSize = new Dimension(700,560);
    private EvpBasePanel basePanel = null;
    private GraphPainter lastPainter = null; 
    private GraphDatasource dataSource = null;
    private double xScale = 0;
    private double XSampleCoords[] = null;
    private static SimpleDateFormat dateFormat 
	= new SimpleDateFormat("yyyy-M-d");
    private static DecimalFormat decimalFormat
	= new DecimalFormat("0.00");
    private Image currentImage = null;
    private GraphPainter painter = null;
    private StatusWindow statusWindow = null;

    // used to draw simple interactive graph
    private int lastSampleNum = -1;
    private double lastEnteredValue = 0.0;
    private boolean bInteractiveGraph = false;
    private int igMinY = 30;
    private int igMaxY = 130;

    private DerivedGraphDatasource derivedDataSource = null;

    public EVP()
        {
        super();
	setTitle("Equity Visualization Platform");
	buildMenu();
	basePanel = new EvpBasePanel(this);
	basePanel.setLayout(new BorderLayout());
	getContentPane().add(basePanel, BorderLayout.CENTER);
	setSize(prefSize);
	setVisible(true);
        statusWindow = new StatusWindow(this);
	}

    public Dimension getPreferredSize()
	{
	return prefSize;
	}

    private void buildMenu()
	{
	JMenu fileMenu = new JMenu("File");
	AddGraphAction addGraphAction = new AddGraphAction(this);
	JMenuItem addGraphItem = new JMenuItem(addGraphAction);
	fileMenu.add(addGraphItem);

	JCheckBoxMenuItem interactiveItem 
              = new JCheckBoxMenuItem(new InteractiveAction(this));
	interactiveItem.setState(false);
	fileMenu.add(interactiveItem);
	
	JMenuItem exitItem = new JMenuItem("Exit");
	exitItem.addActionListener(new ActionListener()
            {
	    public void actionPerformed(ActionEvent e)
		{
		System.exit(0);
		}
            });
	fileMenu.add(exitItem);
	JMenuBar menuBar = new JMenuBar();
	menuBar.add(fileMenu);
	setJMenuBar(menuBar);
	}

    public void generatePlot(String filename)
        {
	GnuPlotGraphDatasource dataSource = null;
	GraphGenerator graphGenerator = new GraphGenerator();
	try
	    {
            dataSource = graphGenerator.createGnuPlotImage(filename,
						       new int[] {2});
	    this.dataSource = dataSource;
	    basePanel.setCursorSampleNum(2);
	    Image image = 
		graphGenerator.getGraphImage(dataSource.getPlotFileName());
	    painter = new GraphPainter(this);
	    painter.setPaintParameters(image,0.0,0.0);
	    addGraph(painter);
	    computeSampleXGraphCoords();
	    this.currentImage = image;
            statusWindow.update(basePanel.getMouseMode(),2);
            statusWindow.setVisible(true);
	    }   
	catch (Exception e)
	    {
	    String errmsg = "Error ";
	    if ((dataSource != null)
		    && (dataSource.getLatestErrorMessage() != null))
		errmsg += dataSource.getLatestErrorMessage();
	    else
		errmsg += "undetected error in EVP.generatePlot: "
		    + e.getMessage();
	    System.out.println(errmsg);
	    }

        }

    public void addGraph(GraphPainter painter)
	{
	    // if you don't remove the last one, you get the new one
            // showing up behind the first one (at least this is what
            // it looked like)
	if (lastPainter != null)
	    {
	    basePanel.remove(lastPainter);
	    }
        lastPainter = painter;
	basePanel.add(painter,BorderLayout.CENTER);    
	pack();
	}
    

    /**
     * Calculate the values for the array XSampleCoords. This
     * array holds the X graph coordinates at each sample point.
     * We need to do this because the samples on the X axis are
     * not necessarily evenly spaced.
     * @throws  Exception if any of the data is bad
     */
    protected void computeSampleXGraphCoords()
	               throws Exception
	{
	if ((dataSource == null) || (dataSource.getSampleCount() <= 0))
	    return;
	int sampleCount = dataSource.getSampleCount();
	XSampleCoords = new double[sampleCount];
	ChannelData xChannel = dataSource.getChannelData(0);
	boolean bDate = (xChannel.getDataType() == ChannelData.DATE);
	String minAxis = xChannel.getMinAxis();
	String maxAxis = xChannel.getMaxAxis();
	double xMin = convertValue(minAxis,bDate);
	double xMax = convertValue(maxAxis,bDate);
	double graphWidth = (double) (painter.getImageWidth() - 
                                      painter.getGraphOrigin().x);
	double pixScale = graphWidth / (xMax - xMin);
	for (int i = 0; i < sampleCount; i++)
	    {
	    double value = convertValue(xChannel.getValue(i),bDate);
	    XSampleCoords[i] = (value - xMin) * pixScale;
	    }
	}

    /**
     * Convert a string value from a data source to a double.
     * If bDate is false, simply converts from a string to a double.
     * Otherwise, converts to the number of minutes since epoch,
     * assuming that the date format is yyyy-MM-dd.
     * @param valueString   String to convert
     * @param bDate         True if this string should be treated as a date
     * @return              See above.
     * @throws               Exception if value has unexpected format.
     */
    protected double convertValue(String valueString, boolean bDate)
	                           throws Exception
	{
	double retValue = -1.0;
	if (bDate)
	    {
	    ParsePosition ppos = new ParsePosition(0);
	    Date thisDate = dateFormat.parse(valueString,ppos);
	    if (thisDate == null)
		{
		throw new Exception("Bad date value in convertValue: '" 
                                    + valueString 
				    + "'");
		}
	    retValue = (double) (thisDate.getTime()/ 60000);
	    }
	else
	    {
	    try
		{
		retValue = Double.parseDouble(valueString);
		}
	    catch (NumberFormatException nfe)
		{
		throw new Exception("Bad double value in convertValue: '" 
                                    + valueString 
				    + "'");
		}
	    }
	return retValue;
	}

    	
    public double getXSampleCoord(int sampleNum)
	{
	return XSampleCoords[sampleNum];
	}

    /**
     * Transform an x coordinate in the data area of a graph
     * to a sample number, assuming that xScale represents the
     * number of pixels per sample along the X axis of the graph.
     * @param  dataX   X coordinate within graph 
     * @return         sample number that this x corresponds to, or negative
     *                 if outside the graph       
     */
    public int mapToSampleNumber(int dataX)
        {
	int sampleNum = -1;
	int sampleCount = dataSource.getSampleCount();
	double minDistance = (double) painter.getImageWidth();
	int i = 0;
	double dataXd = (double) dataX;
	for (i = 0; i <  sampleCount; i++)
	    {
	    double diff = Math.abs(dataXd - XSampleCoords[i]);
	    //	    System.out.println("  At sample " + i + " diff is " + diff 
	    //	       + " and minDistance is " 
	    //	       + minDistance);
	    if (diff > minDistance)
		break;
	    minDistance = diff;
	    }
	sampleNum = i-1 ;
	return sampleNum;
        }

    /**
     * Convert coordinates in the data area of the graph to image
     * coordinates, assuming use of the global origin  
     * @param dataX          X coordinate in graph area 
     * @param dataY          Y coordinate in graph area
     * @return               Point in "image space" that corresponds 
     *                          to the data point (dataX,dataY)
     */
    public Point dataToImageCoords(int dataX, int dataY) 
        {
	// ~~ needs to change when we have more than one painter
	    //	System.out.println("dataToImageCoords - input is " 
	    //		       + dataX + "," +  dataY);
   
	Point imagePt =  painter.Graph2Image(new Point(dataX,dataY));
	// System.out.println("result is " + imagePt);
	return imagePt;
        }

    /**
     * Prompt the user for a value to be drawn on the graph.
     * @return           Value entered by user.
     */
    protected double getNewGraphValue()
	{
	double retValue =-1.0;
	boolean bOk = false;
	while (!bOk)
	    {
	    String inputValue = JOptionPane.showInputDialog(this, 
				 "Enter a value between 0.0 and 1.0",
				 "Enter Data",
				 JOptionPane.PLAIN_MESSAGE);
	    if (inputValue != null)
		{
		try
		    {
		    retValue = Double.parseDouble(inputValue);
		    if ((retValue >= 0.0) && (retValue <= 1.0))
			bOk = true;
		    }
		catch (NumberFormatException nfe)
		    {
		    }
		}
	    else
		{
		    bOk = true;    
		}
	    }
	return retValue;
	}

    /**
     *  Repaint the images plus any data from the derived data source.
     */
    public void paint(Graphics g)
	{
	super.paint(g);
	if (derivedDataSource != null)
	    {
	    try
		{
		int lastSNum = -1;
		double lastEVal = 0.0;
		ChannelData channel 
		    = derivedDataSource.getChannelData(
				   dataSource.getChannelCount());
		double values[] = channel.getNumericValues();
		for (int i = 0; i < values.length; i++)
		    {
		    plotGraphPoint(i,values[i],lastSNum,lastEVal,Color.black);
		    lastSNum = i;
		    lastEVal = values[i];
		    }
		}
	    catch (Exception e)
		{
		}
	    }
	}

   /**
    * Draw two line segments of the interactive graph, 
    * horizontally from
    * (graphCoord(lastSampleNum), lastEnteredValue) to
    * (graphCoord(sampleNum), lastEnteredValue) and
    * then vertically to (graphCoord(sampleNum,enteredValue).
    */
    public void plotGraphPoint(int sampleNum,
				  double enteredValue, 
				  int lastSampleNum,
				  double lastEnteredValue,
				  Color drawColor)

	{
	/**
	System.out.println("PlotGraphPoint: sampleNum = " 
		    + sampleNum + " value = "
		    + enteredValue + ":  lastSampleNum="
		    + lastSampleNum + " lastEnteredValue="
	   	    + lastEnteredValue 
	   	    + " color is" + drawColor);
	*/
	Point lastPoint = null;
	int imageHeight = painter.getImageHeight();
        // ~~ change when we have multiple images. 
	if (lastSampleNum < 0)
	    {
	    lastPoint = dataToImageCoords(0,igMinY);
	    }
	else
	    {
	    lastPoint = dataToImageCoords((int) XSampleCoords[lastSampleNum], 
					  (int)(lastEnteredValue 
						* (igMaxY - igMinY) + igMinY)); 
	    }
        lastPoint.y = imageHeight - lastPoint.y; // flip to Java coords
        
	Point thisPoint 
          = dataToImageCoords((int) XSampleCoords[sampleNum], 
			      (int) (enteredValue 
				     * (igMaxY - igMinY) + igMinY));
        thisPoint.y = imageHeight - thisPoint.y; // flip to Java coords
	Graphics2D g = (Graphics2D) painter.getGraphics();
	g.setColor(drawColor);
	g.drawLine(lastPoint.x,lastPoint.y, thisPoint.x, lastPoint.y);
	g.drawLine(thisPoint.x,lastPoint.y, thisPoint.x, thisPoint.y);
	}

   /**
    * Set data values in the derived data set channel.
    * @param sampleNum       Sample index for which value was supplied
    * @param enteredValue    Value to be stored 
    * @param lastSampleNum   Sample index for previously-supplied value.
    *                        Must be < sampleNum
    * @param lastEnteredValue Previous value in the graph
    */
    public void stuffValue(int sampleNum,
			      double enteredValue, 
			      int lastSampleNum,
			      double lastEnteredValue
			      )
	{
	if ((derivedDataSource == null) || (sampleNum <= lastSampleNum))
	    return;
	ChannelData channel 
	    = derivedDataSource.getChannelData(dataSource.getChannelCount());
	StringBuffer valueBuffer = new StringBuffer();
	StringBuffer oldValueBuffer = new StringBuffer();
	FieldPosition fp = new FieldPosition(0);
	FieldPosition ofp = new FieldPosition(0);
	valueBuffer = decimalFormat.format(enteredValue,
					   valueBuffer,
					   fp);
	String theValue = valueBuffer.toString();
	oldValueBuffer = decimalFormat.format(lastEnteredValue,
					   oldValueBuffer,
					   ofp);
	String oldValue = oldValueBuffer.toString();
	for (int i = lastSampleNum + 1; i < sampleNum; i++)
	    {
	    channel.addValue(oldValue);
	    }
	channel.addValue(theValue);
	}


    public void notifyMouseChange(int mouseMode,int sampleNum)
        {
        statusWindow.update(mouseMode,sampleNum);
        }
    
    /**
     *  Returns the symbol associated with the first datasource
     */
    public String getSymbol()
        {
        return dataSource.getSymbol();
        }
    
    /**
     * Returns the x range (time range) associated with the
     * first datasource (should be the same for all concurrently
     * graphed datasources).
     */
    public String getXRange()
        {
        StringBuffer rangeString = new StringBuffer();
        ChannelData timeChannel = dataSource.getChannelData(0);
        rangeString.append(timeChannel.getMinAxis() + " - ");
        rangeString.append(timeChannel.getMaxAxis());
        return rangeString.toString();
        }   
    
    public String getXValue(int sampleNum)
        {
        String xval = "--";
        try 
            {
            ChannelData timeChannel = dataSource.getChannelData(0);
            xval = timeChannel.getValue(sampleNum);
            }
        catch (Exception e)
            {
            }
        return xval;
        }
    
    
    public String getYValue(int sampleNum, int channelNum)
        {   
        String yval = "--";
        try
            {
            ChannelData channel = dataSource.getChannelData(channelNum);
            yval = channel.getValue(sampleNum);
            }
        catch (Exception e)
            {
            }
        return yval;    
        }
    
   /**
    * Returns the y range associated with the specified channel of
    * datasource (~~ TODO must change when we have multiple graphs/window)
    */
    public String getYRange(int channelNum)
        {
        StringBuffer rangeString = new StringBuffer();
        ChannelData channel = dataSource.getChannelData(channelNum);
        rangeString.append(channel.getMinVal() + " - ");
        rangeString.append(channel.getMaxVal());
        return rangeString.toString();
        }   
    /**
     *  Turn on interactive graphing mode.
     */
    public void startInteractiveGraph()
	{
	basePanel.setMouseMode(EvpBasePanel.INTERACTIVE_GRAPH_MODE);
	bInteractiveGraph = true;
	derivedDataSource = null;
	repaint();
	derivedDataSource = new DerivedGraphDatasource(dataSource);
	try
	    {
	    ChannelData newChannel = derivedDataSource.addChannel();
	    newChannel.initMetaData("Interactive",ChannelData.FLOAT,
				null);
	    newChannel.setMinVal("0.0");
	    newChannel.setMinAxis("0.0");
	    newChannel.setMaxVal("1.0");
	    newChannel.setMaxAxis("1.0");
	    }
	catch (Exception e)
	    {
	    System.out.println("Error in startInteractiveGraph: "
			       + e.getMessage());
	    }
	}    

   /**
    * Indicate whether we are the process of creating an
    * interactive graph.
    */
    public boolean isInteractiveGraph()
	{
	return bInteractiveGraph;
	}

    /**
     *  Turn off interactive graphing mode.
     *  @param filename     Filename to which derived channel should be written
     */
    public void finishInteractiveGraph(String filename)
	{
	basePanel.setMouseMode(EvpBasePanel.NO_MODE);
	bInteractiveGraph = false;
	if (filename != null)
	    {
	    int sampleCount = derivedDataSource.getSampleCount();
	    plotGraphPoint(sampleCount-1,lastEnteredValue,
			   lastSampleNum,lastEnteredValue,Color.black);
	    stuffValue(sampleCount-1,lastEnteredValue,
		       lastSampleNum,lastEnteredValue);
	    derivedDataSource.updateXmlDocument();
	    try
		{
		GnuPlotFileWriter.write(derivedDataSource,filename);
		}
	    catch (Exception e)
		{
		System.out.println("Error in writing file: " + e.getMessage());
		}
	    }
	else
	    {
	    derivedDataSource = null;
	    repaint();
	    }
	lastSampleNum = -1;
	lastEnteredValue = 0.0;
	}    

    public void setLastEnteredValue(double value )
	{
	lastEnteredValue = value;
	}

    public double getLastEnteredValue()
	{
	return lastEnteredValue;
	}

    public void setLastSampleNum(int value )
	{
	lastSampleNum = value;
	}

    public int getLastSampleNum()
	{
	return lastSampleNum;
	}


    /**
     * Get a reference to a specific graph data source.
     */
    public GraphDatasource getDatasource(int index)
	{
	return dataSource;
	}

    public static void main(String args[])
	{
	EVP evp = new EVP();
	evp.pack();
	}

    protected static String cvsInfo = null;
    protected static void setCvsInfo()
        {
        cvsInfo = "\n@(#)  $Id: EVP.java,v 1.7 2007/01/05 07:41:57 rudahl Exp $ \n";
	}
    }
