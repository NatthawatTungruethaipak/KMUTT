/* 
 * HeaderCallback.java
 *
 * Copyright Goldin-Rudahl Associates
 *
 * Created by Sally Goldin, 10/23/2001
 *
 * $Id: HeaderCallback.java,v 1.7 2007/08/27 11:35:57 goldin Exp $
 * $Log: HeaderCallback.java,v $
 * Revision 1.7  2007/08/27 11:35:57  goldin
 * Add functionality to header table processing, e.g. sorting
 *
 * Revision 1.6  2007/08/26 10:52:27  goldin
 * Working on interfacing new table field to the HEA operation
 *
 * Revision 1.5  2006/02/11 07:15:31  goldin
 * Enable classnames tab even if no classnames yet
 *
 * Revision 1.4  2005/12/23 10:40:31  goldin
 * Don't assume that index into labels is class number
 *
 * Revision 1.3  2001/11/30 18:01:21  goldin
 * Moved most of the UI basic components to the com.grs.gui package
 *
 * Revision 1.2  2001/11/05 13:59:15  goldin
 * Put UI code in a package
 *
 * Revision 1.1  2001/10/12 11:41:05  goldin
 * New callbacks for HEA panel
 *
 */

package com.grs.dragon.ui;
import com.grs.gui.*;
import java.util.*;
import javax.swing.*;

/** 
 *  This class is an abstract base class which holds some common
 *  code used by both the ImgHeaderCallback and HeaFileTypeCallback
 *  classes.
 * @author  goldin*/
public abstract class HeaderCallback implements Callback 
    {
    protected static final String clsFieldName = "^CNMTAB";

      /** Primary method of a callback class.
       */
    public abstract void executeCallback(DragonField field);

    protected void processClassNames(DragonPanel parent,
				DImageHeader header)
        {
	String classnames = header.getConcatenatedClassnames();
        DragonField fld;
	fld = parent.getField(clsFieldName);
	if (fld != null)
            {
	    fld.setEnabled(true);
	    fld.setFieldValue(classnames);
	    fld.setEnabled(true); // to check button enabling 
	    }
	}

    protected void clearClassNames(DragonPanel parent,
				   DImageHeader header)
        {
        DragonField fld;
	fld = parent.getField(clsFieldName);
	if (fld != null)
	    fld.clearField();
	}
    }


