/**
 *  AddGraphAction.java
 *   
 *     Created by S.Goldin
 *
 *    $Id: AddGraphAction.java,v 1.1 2004/02/24 12:25:11 rudahl Exp $
 *
 *    $Log: AddGraphAction.java,v $
 *    Revision 1.1  2004/02/24 12:25:11  rudahl
 *    Developing for Release 1
 *
 *
 */
package com.grs.evp;

import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.io.File;

public class AddGraphAction extends AbstractAction
{
    private EVP parentFrame = null;
    private JFileChooser chooser = new JFileChooser();

    /**
     * Create a menu item/action to add a dataset and graph.
     * @param parentFrame  Reference to the EVP on whose menu this resides
     */
    public AddGraphAction(EVP parentFrame)
        {
	super("Add dataset");
	this.parentFrame = parentFrame;
	chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
        }

    public void actionPerformed(ActionEvent event)
	{
	if (chooser.showOpenDialog(parentFrame) == JFileChooser.APPROVE_OPTION)
	    {
	    File file = chooser.getSelectedFile();
	    String filename = file.getAbsolutePath();
	    if (filename != null)	
		{
		parentFrame.generatePlot(filename);
		}
	    }
	}
}

