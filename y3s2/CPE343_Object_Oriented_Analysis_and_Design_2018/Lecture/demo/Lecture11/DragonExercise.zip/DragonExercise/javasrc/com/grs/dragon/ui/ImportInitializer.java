/**
 * ImportInitializer.java
 * 
 * Copyright  2001-2008  by Sally Goldin and Kurt Rudahl
 *
 * Created by Sally Goldin, 6/12/2008
 *
 * $Id: ImportInitializer.java,v 1.1 2008/06/12 10:30:58 goldin Exp $
 * $Log: ImportInitializer.java,v $
 * Revision 1.1  2008/06/12 10:30:58  goldin
 * add importinitializer
 *
 *
 *
 */
package com.grs.dragon.ui;
import com.grs.gui.*;

/** 
 * This class provides a method which enables or disables the 'Reduce
 * control on the auto-import panel depending on the Dragon Version.
 */
public class ImportInitializer implements Initializer
    {
      /**
       * Set the initial value of the passed field as appropriate
       * @param field DragonField whose value is to be set.
       */
    public void setInitialValue(DragonField field)
        {
	// get product info from properties file and save
	String versionSelector = System.getProperty("versionSelector");

        if ((versionSelector != null) &&
            (versionSelector.compareToIgnoreCase("PROFESSIONAL") == 0))
            field.setEnabled(false);
        else 
            field.setEnabled(true);
	}

    protected static String cvsInfo = null;
    protected static void setCvsInfo()
        {
        cvsInfo = "\n@(#)  $Id: ImportInitializer.java,v 1.1 2008/06/12 10:30:58 goldin Exp $ \n";
	}
    }
