/* ClassNameTableValidator.java
 *
 * Copyright  2007 by Sally Goldin and Kurt Rudahl
 *
 * $Id: ClassNameTableValidator.java,v 1.5 2007/12/06 09:23:38 goldin Exp $
 * $Log: ClassNameTableValidator.java,v $
 * Revision 1.5  2007/12/06 09:23:38  goldin
 * mark issue for future review
 *
 * Revision 1.4  2007/10/23 13:26:14  goldin
 * Fix null ptr exception if no labels to validate in HEA
 *
 * Revision 1.3  2007/09/01 09:16:41  goldin
 * Add code to detect duplicate class numbers in class table
 *
 * Revision 1.2  2007/08/27 11:35:57  goldin
 * Add functionality to header table processing, e.g. sorting
 *
 * Revision 1.1  2007/08/27 11:25:20  goldin
 * Moved from gui package - dragon-specific
 *
 * Revision 1.1  2007/08/26 08:53:01  goldin
 * Add validation capabilities to the DTableField control
 *
 */

package com.grs.dragon.ui;
import javax.swing.*;
import java.awt.*;
import java.util.Vector;
import com.grs.gui.*;

/** 
 * This class provides validation for the class name/class number table that 
 * appears in HEA. The first column must be a string with a max number of characters,
 * while the second column must be an integer between 0 and 255.
 */
public class ClassNameTableValidator extends TableValidator 
    {
    /* The only method we need to implement is the isValid method */

     /**
      * Method that knows how to validate each column
      * this table. Note that we can assume that row and col are
      * valid because this is checked in the base class. 
      * @param tableField   DTableField object used to get values
      * @param row          Row to check
      * @param col          Column to check
      * @return true if valid, false if not.
      */
    protected boolean isValid(DTableField tableField, int row, int col)
	{
	boolean bValid = true;
	String newValue = null;
        if ((row >=0) && (col >= 0))
	    newValue = tableField.getValueAt(row,col);
        switch (col)
	    {
            case 0:
		bValid = validateClassName(newValue);
		break;
	    case 1:
                bValid = validateDataVal(newValue);
		break;
            default:
                // Called at OK - check for duplicates
                bValid = checkForDupes(tableField);
            }
        return bValid;
        } 

     /**
      * Factorization. Return true if class name is correct.
      * @param value  String value to validate
      * @return True if good value, false otherwise
      */
    protected boolean validateClassName(String value)
        {
	return true;  /* What is the max length? We should check it. */  
        }


     /**
      * Factorization. Return true if data value for class name is correct,
      * i.e. is an integer between 0 and 255.
      * @param value  String value to validate
      * @return True if good value, false otherwise
      */
    protected boolean validateDataVal(String value)
        {
        StringBuffer workBuffer = new StringBuffer();
	boolean bValid = true;
	lastErrorKey = null;
        extraInfo = null;
	int intValue = 0;
	if (value.length() > 0)
	    {
	    try
	        {
		intValue = Integer.parseInt(value.trim());
		/* ~~~ TODO - need to allow larger values for a 16 bit image? */
                if ((intValue < 0) || (intValue > 255))
                    {
		    bValid = false;
		    lastErrorKey = TextKeys.OUTSIDE_RANGE;
		    workBuffer.append(" (0 - 255)");
		    extraInfo = workBuffer.toString();
		    }
		}
	    catch (NumberFormatException nfe)
	        {
		bValid = false;
		lastErrorKey = TextKeys.BADINTEGER;
		}
	    }
	return bValid;
        }

      /**
       * Factorization - check to make sure that the 
       * values in the data value field are all unique.
       * @param tableField  Field to check
       * @return true if no duplicates, false if duplicates
       *           are found.
       */
    protected boolean checkForDupes(DTableField tableField)
        {
	boolean bValid = true;
        if (tableField.getRowCount() == 0)
	    return true;
        tableField.sortTable();
        Vector<Vector> rows = tableField.getFieldValueAsVector();
        String lastValue = null;
        for (int r = 0; r < rows.size(); r++)
            {
	    Vector<String> thisRow = rows.get(r);
            String currentValue = thisRow.get(1); /* second column must be unique */
            if ((lastValue != null) && (currentValue.compareTo(lastValue) == 0))
		{
		bValid = false;
		lastErrorKey = "%e7000.19";
		break;
                }
	    lastValue = currentValue;
            }
        return bValid;
        }


    protected static String cvsInfo = null;
    protected static void setCvsInfo()
        {
        cvsInfo = "\n@(#)  $Id: ClassNameTableValidator.java,v 1.5 2007/12/06 09:23:38 goldin Exp $ \n";
	}
    }

// End of ClassNameTableValidator.java

