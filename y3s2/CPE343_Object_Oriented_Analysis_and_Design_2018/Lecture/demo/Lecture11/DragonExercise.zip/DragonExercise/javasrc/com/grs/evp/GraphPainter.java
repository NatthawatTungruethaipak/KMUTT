/**
 *   GraphPainter.java
 *   
 *     Created by S.Goldin
 *
 *    $Id: GraphPainter.java,v 1.2 2004/03/25 12:52:21 rudahl Exp $
 *
 *    $Log: GraphPainter.java,v $
 *    Revision 1.2  2004/03/25 12:52:21  rudahl
 *    Rework scaling to be more consistent and refactor into child classes
 *
 *    Revision 1.1  2004/02/24 12:25:11  rudahl
 *    Developing for Release 1
 *
 *
 */
package com.grs.evp;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.AffineTransform;

/**
 * Class that will render the image
 * of a graph to be displayed and manipulated in
 * EVP.
 */
public class GraphPainter extends JComponent
{
    private Image imageToPaint = null;
    private double xCoord =0.0;
    private double yCoord = 0.0;
    private int iX = 0;
    private int iY = 0;
    private JFrame parentWindow = null;
    // origin of graph (0,0 on it's axes) with respect
    // to lower left corner of the image
    private Point graphOrigin = new Point(28,22);
    // Note that we assume that the graph fills up the
    // whole image to the right, i.e. that the width
    // of the graph is the width of the image - graphOrigin.x

    /**
     * Constructor sets a reference to the parent, so we can
     * get its dimensions later.
     */
    public GraphPainter(JFrame parentWindow)
	{
	this.parentWindow = parentWindow;
	}

    /**
     * Override paint to display the image, if any.
     * If image is null, do nothing.
     * @param gContext Graphics context supplied by Java
     */
    public void paint(Graphics gContext)
	{
	Graphics2D g2d = (Graphics2D) gContext;
	if (imageToPaint != null)
	    {
	    AffineTransform xForm = new AffineTransform();
	    xForm.setToTranslation(xCoord,yCoord);
	    g2d.drawImage(imageToPaint,xForm,null);
	    }
	else
	    {
	    g2d.setColor(Color.red);
	    g2d.fillRect(0,0,60,100);
 	    }
	}

    /**
     * Set the three arguments needed to do the painting.
     * @param image  Image to display
     * @param x      Starting x
     * @param y      Starting y
     */
    public void setPaintParameters(Image image, double x, double y)
	{
	imageToPaint = image;
	xCoord = x;
	yCoord = y;
	iX = (int) x;
	iY = (int) y;
	}

    /**
     *  Return the offset of the LOWER LEFT corner of
     *  the image, relative to the current size of the
     *  panel. Will return 0,0 if the image has not
     *  yet been set.
     */
    public Point getImageOrigin()
        {
	Point pt = new Point(0,0);
	if (imageToPaint != null)
	    {
	    pt.x = iX;
	    pt.y = getHeight() - (imageToPaint.getHeight(this) + iY);
	    }
	return pt;
	}

    /**
     * Set the graph origin for this graph image.
     * Currently not used since all our graphs have the same
     * origin, which is set on construction.
     */
    public void setGraphOrigin(Point origin)
        {
	graphOrigin = origin;
        }

    public Point getGraphOrigin()
        {
	return graphOrigin;
	}

    public int getImageWidth()
        {
        int width = 0;
	if (imageToPaint != null)
	    {
            width = imageToPaint.getWidth(this);
	    }
	return width;
	}

    public int getImageHeight()
        {
        int height = 0;
	if (imageToPaint != null)
	    {
            height = imageToPaint.getHeight(this);
	    }
	return height;
	}

    /**
     *  Transform a point in the painter coordinate system
     *  (JPanel, but with Y origin at bottom) to the
     *  Image coordinate system. Returns the closest point (maybe
     *  on the edge of the image.
     *  @param   pt      Painter point to transform.
     *  @return          Point in the Image coordinate system
     */
    public Point Paint2Image(Point pt)
        {        
        Point newPt = new Point(0,0);
        Point imgOrigin = getImageOrigin();
	newPt.x = pt.x - imgOrigin.x;
	if (newPt.x < 0)
	    newPt.x = 0;
	if (newPt.x > imageToPaint.getWidth(this))
	    newPt.x = imageToPaint.getWidth(this) - 1;
	newPt.y = pt.y - imgOrigin.y;
	if (newPt.y < 0)
	    newPt.y = 0;
	if (newPt.y > imageToPaint.getHeight(this))
	    newPt.y = imageToPaint.getHeight(this) - 1;
	return newPt;
        }

    /**
     *  Transform a point in the image coordinate system
     *  to one in the painter coordinate sytem 
     *  (JPanel, but with Y origin at bottom)
     *  @param   pt      Image point to transform.
     *  @return          Point in the Painter coordinate system
     */
    public Point Image2Paint(Point pt)
        {        
        Point newPt = new Point(0,0);
        Point imgOrigin = getImageOrigin();
	newPt.x = pt.x + imgOrigin.x;
	newPt.y = pt.y + imgOrigin.y;
	return newPt;
        }

    /**
     *  Transform a point in the image coordinate system
     *  to the graph coordinate system. Returns the closest point (maybe
     *  on the edge of the graph)
     *  @param   pt      Image point to transform.
     *  @return          Point in the Graph coordinate system
     */
    public Point Image2Graph(Point pt)
        {        
        Point newPt = new Point(0,0);
        Point gOrigin = getGraphOrigin();
	newPt.x = pt.x - gOrigin.x;
	if (newPt.x < 0)
	    newPt.x = 0;
	// we assume that the graph fills the whole image on the left so
	// we don't need to clip at the upper boundary.
	newPt.y = pt.y - gOrigin.y;
	if (newPt.y < 0)
	    newPt.y = 0;
	// similarly with the Y coordinate.
	return newPt;
        }

    /**
     *  Transform a point in the graph coordinate system
     *  to one in the image coordinate sytem 
     *  @param   pt      Graph point to transform.
     *  @return          Point in the Image coordinate system
     */
    public Point Graph2Image(Point pt)
        {        
        Point newPt = new Point(0,0);
        Point gOrigin = getGraphOrigin();
	newPt.x = pt.x + gOrigin.x;
	newPt.y = pt.y + gOrigin.y;
	return newPt;
        }

}
