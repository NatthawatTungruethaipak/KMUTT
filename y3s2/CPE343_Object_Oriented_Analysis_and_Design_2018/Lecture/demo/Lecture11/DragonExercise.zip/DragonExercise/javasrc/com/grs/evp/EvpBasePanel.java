/**
 *  EvpBasePanel.java
 *   
 *     Created by S.Goldin & K. Rudahl
 *
 *    $Id: EvpBasePanel.java,v 1.4 2007/01/05 07:41:57 rudahl Exp $
 *
 *    $Log: EvpBasePanel.java,v $
 *    Revision 1.4  2007/01/05 07:41:57  rudahl
 *    added Whatis info
 *
 *    Revision 1.3  2004/04/04 08:27:23  rudahl
 *    Implement status display functionality
 *
 *    Revision 1.2  2004/03/25 12:52:21  rudahl
 *    Rework scaling to be more consistent and refactor into child classes
 *
 *    Revision 1.1  2004/03/24 08:39:03  rudahl
 *    added vert bar cursor functionality
 *
 *
 */

package com.grs.evp;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;

/**
 * This class holds all the graphs in the
 * EVP application, and handles the display and dragging of the 
 * vertical cursor and the display of corresponding
 * data in the status box.
 */
public class EvpBasePanel extends JPanel
    {
    public static final int NO_MODE = 0;
    public static final int VCURSOR_MODE = 1;
    public static final int INTERACTIVE_GRAPH_MODE = 2;

    private EVP parentApp = null;
    private int cursorSampleNum = -1;
    private Color cursorColor = Color.black;
    private int mouseMode = NO_MODE; 
    private int currentMouseButton = -1;
    /**
     * Array of graph painter components, in
     * the order they are added to the panel,
     * independent of any to be added Z ordering control
     */
    protected ArrayList painters = new ArrayList();
    	
    /**
     * Create the panel, giving it a reference
     * to the parent application so that it can
     * call parent methods.
     */
    public EvpBasePanel(EVP parent)
	{
	parentApp = parent;
	this.addMouseListener(new VCursorMouseAdapter(this));
	this.addMouseMotionListener(new VCursorMouseMotionAdapter(this));
 	}


    /**
     *  Override add to add to the array list
     */
    public void add(Component comp, Object constraints)
	{
	super.add(comp,constraints);  
	System.out.println("Added component " + comp);
	if (comp instanceof GraphPainter)
	    painters.add(comp);
	}

    /**
     *  Repaint the images plus any data from the derived data source.
     */
    public void paint(Graphics g)
	{
	super.paint(g);
	if (cursorSampleNum >= 0)
	    {
	    // for now, assume a single graph painter.
	    GraphPainter gPainter = (GraphPainter) painters.get(0);
	    int h = this.getHeight();
	    Point graphPoint = 
               new Point((int) parentApp.getXSampleCoord(cursorSampleNum),0); 
	    Point p = 
                Paint2BP(gPainter,
	         gPainter.Image2Paint(gPainter.Graph2Image(graphPoint)));
	    // Don't bother to flip Y b/c we're only interested in X posn.
            g.setColor(cursorColor);
	    g.drawLine(p.x,0,p.x,h);
	    }
	}

    /**
     * Allows external classes to set position of the cursor.
     */
    public void setCursorSampleNum(int sample)
	{
	cursorSampleNum = sample;
	}

    
    public void setMouseMode(int mode)
	{
	mouseMode = mode;
	}

    
    public int getMouseMode()
        {
        return mouseMode;
        }   

    /**
     * Transform a Y coordinate in Java conventions (0 at top)
     * to one using our conventions (0 at bottom).
     * @param yJava          The Y coordinate to flip
     * @param objectHeight   Height of the object whose coords we are using
     * @return               Y coord in a lower-left anchored coord syst.
     */
    protected int flipY(int yJava, int objectHeight)
	{
	int newY = objectHeight - yJava;
        return (newY < 0) ? 0 : newY;
	}
  
   /**
    * Given a point in the BasePanel coordinate system,
    * transform it to a point in the GraphPainter coordinate
    * system of a particular GraphPainter. This assumes
    * that ALL coordinate systems have a Y axis that
    * starts at the bottom of the component or panel,
    * not at the top as in Java.
    * @param painter        GraphPainter whose coordinate
    *                       should be used as the result.
    * @param pt             Point to transform, in BasePanel coords.
    * @return               Point in the coordinate system of the
    *                           painter which is CLOSEST to the
    *                           passed point.
    */
    public Point BP2Paint(GraphPainter painter, Point pt)
	{
	Point newPt = new Point(0,0);
	int painterH = painter.getHeight();
	int painterW = painter.getWidth();
	int painterOriginX = painter.getX(); // in Java BP coords
	int painterOriginY = this.getHeight() - 
              flipY(painter.getY(),painter.getHeight());
	newPt.x = pt.x - painterOriginX;
	if (newPt.x < 0)
	    newPt.x = 0;
	if (newPt.x >= painterW)
	    newPt.x = painterW - 1;
        newPt.y = pt.y - painterOriginY;
	if (newPt.y < 0)
	    newPt.y = 0;
	if (newPt.y >= painterH)
	    newPt.y = painterH - 1;
	return newPt;
	}

   /**
    * Given a point in coordinate system of a particular GraphPainter,
    * transform it to a point in the BasePanel coordinate system.
    * This assumes that ALL coordinate systems have a Y axis that
    * starts at the bottom of the component or panel,
    * not at the top as in Java.
    * @param painter        GraphPainter whose coordinate
    *                       system is assumed to include pt.
    * @param pt             Point to transform, in GraphPainter coords.
    * @return               Point in the base panel coordinate system 
    */
    public Point Paint2BP(GraphPainter painter, Point pt)
	{
	Point newPt = new Point(0,0);
	int painterH = painter.getHeight();
	int painterW = painter.getWidth();
	int painterOriginX = painter.getX(); // in BP coords
	int painterOriginY = 
          this.getHeight() - flipY(painter.getY(), painter.getHeight());
	newPt.x = pt.x + painterOriginX;
        newPt.y = pt.y + painterOriginY;
	return newPt;
	}


   /**
    * Check whether a particular point in BasePanel coordinates
    * is inside a specific GraphPainter (assumed to be a child
    * of the base panel).
    * @param  painter      GraphPainter to be evaluated
    * @param  BPpoint      Point to check
    * @return  true if point is inside or on border of this painter.
    */
    protected boolean insidePainter(GraphPainter painter,Point BPpoint)
        {
	boolean bInside = false;
	int painterH = painter.getHeight();
	int painterW = painter.getWidth();
	int painterOriginX = painter.getX(); // in BP coords
	int painterOriginY = this.getHeight() -
               flipY(painter.getY(), painter.getHeight());
        if ((BPpoint.x >= painterOriginX) 
	    && (BPpoint.x <= painterOriginX + painterW)
	    && (BPpoint.y >= painterOriginY)
	    && (BPpoint.y <= painterOriginY + painterH))
	    {
	    bInside = true;
	    }
        return bInside;      
	}

    /**
     * Find the graph painter in which the point pt (BasePanel coords) 
     * is contained. Return null if not inside any graph painter.
     * ~~ Modify this to handle Z order if we have overlapping graph painters.
     * @param pt   Point whose graph we want to locate.
     * @return  graph painter in which this point is located or null if none.
     */
     protected GraphPainter findGraphPainter(Point pt)
	{
	GraphPainter foundPainter = null;
	Iterator it = painters.iterator();
	while ((it.hasNext()) && (foundPainter == null))
	    {
	    GraphPainter painter = (GraphPainter) it.next();
	    if (insidePainter(painter,pt))
		foundPainter = painter;
	    }
	return foundPainter;
	}

   /**
    * Inner class for handling mouse events in this
    * type of panel
    */
    class VCursorMouseAdapter extends MouseAdapter
        {
	JPanel basePanel = null;
	
	public VCursorMouseAdapter(JPanel base)
	    {
	    super();
	    basePanel = base;
	    }

	public void mousePressed(MouseEvent me)
            {
	    int button = me.getButton();
	    currentMouseButton = button;
	    switch (button)
		{
		case MouseEvent.BUTTON1:
		    {
		    if (mouseMode != VCURSOR_MODE)
			break;
                    // we need to map this point, in
                    // BasePanel coords, to Graph coords.
		    Point BPpoint = new Point(me.getX(),
					      flipY(me.getY(),getHeight()));
		    GraphPainter gPainter = findGraphPainter(BPpoint);
		    if (gPainter != null)
			{
			Point result = gPainter.Image2Graph(
                                   gPainter.Paint2Image(
				   BP2Paint(gPainter,BPpoint)));
			System.out.println("Mouse pressed at: " +
				     me.getX() + ", " + me.getY() 
				     + " -- data coords=" + result);  
                       
			int newSampleNum =  
                              parentApp.mapToSampleNumber(result.x);
                        if (newSampleNum != cursorSampleNum)
                            {
                            cursorSampleNum = newSampleNum;
                            parentApp.notifyMouseChange(mouseMode,cursorSampleNum);    
                            basePanel.repaint();
                            }
			}
		    break;
	            }
		case MouseEvent.BUTTON3:
		    {
		    // ~~ temporary - eventually this will be handled
		    //    by a menu action
		    if (mouseMode != INTERACTIVE_GRAPH_MODE)
			{
		        mouseMode = (mouseMode == VCURSOR_MODE) 
			    ? NO_MODE : VCURSOR_MODE;
                        parentApp.notifyMouseChange(mouseMode,cursorSampleNum);    
                        }
		    break;
		    }
		default:
		    break;
		}
	    }
        
	public void mouseReleased(MouseEvent me)
            {
	    int button = me.getButton();
	    currentMouseButton = -1;
	    if ((button != MouseEvent.BUTTON1)
		|| (mouseMode != INTERACTIVE_GRAPH_MODE)) 
		return;
                    // we need to map this point, in
                    // BasePanel coords, to Graph coords.
	    Point BPpoint = new Point(me.getX(),
				      flipY(me.getY(),getHeight()));
	    GraphPainter gPainter = findGraphPainter(BPpoint);
	    if (gPainter != null)
		 {
		 Point result = gPainter.Image2Graph(
				   gPainter.Paint2Image(
				   BP2Paint(gPainter,BPpoint)));
		 System.out.println("Mouse released at: " +
				  me.getX() + ", " + me.getY() 
				  + " -- data coords=" + result);  
		 int sampleNum = parentApp.mapToSampleNumber(result.x);
		 String value = "";
		 if (sampleNum >= 0)
		     {
		     try
			 {
		         value = 
                             parentApp.getDatasource(0).getChannelData(1).getValue(sampleNum);
			 }
		     catch (Exception e)
			 {
			 e.printStackTrace();
			 }   
		     }
		 if (sampleNum > parentApp.getLastSampleNum())
		     {
		     double enteredValue = parentApp.getNewGraphValue();
		     if (enteredValue >= 0)
			 {
			 parentApp.stuffValue(sampleNum, enteredValue, 
					      parentApp.getLastSampleNum(), 
			 parentApp.getLastEnteredValue());
			 // the call below may not be necessary,
			 // since the paint() method seems to be
			 // called whenever we select a point.
			 // However, we're leaving it in for safety.
			 parentApp.plotGraphPoint(sampleNum, enteredValue,
						  parentApp.getLastSampleNum(), 
						  parentApp.getLastEnteredValue(),
						  Color.black);
			 parentApp.setLastEnteredValue(enteredValue);
			 parentApp.setLastSampleNum(sampleNum);
			 }
		     }
		 else 
		     {
		     Toolkit.getDefaultToolkit().beep();
		     }
		 }
	    }

        }  // end of mouse adapter class

   /**
    * Inner class for handling mouse motion events in this
    * type of panel
    */
    class VCursorMouseMotionAdapter extends MouseMotionAdapter
        {
	JPanel basePanel = null;
	
	public VCursorMouseMotionAdapter(JPanel base)
	    {
	    super();
	    basePanel = base;
	    }

	public void mouseDragged(MouseEvent me)
            {
	    int button = me.getButton();
	    switch (currentMouseButton)
		{
		case MouseEvent.BUTTON1:
		    {
		    if (mouseMode != VCURSOR_MODE)
			break;
		    Point BPpoint = new Point(me.getX(),
				      flipY(me.getY(),getHeight()));
		    GraphPainter gPainter = findGraphPainter(BPpoint);
		    if (gPainter != null)
			{
			Point result = gPainter.Image2Graph(
				       gPainter.Paint2Image(
				         BP2Paint(gPainter,BPpoint)));
			int sampleNum = parentApp.mapToSampleNumber(result.x);
			if (sampleNum != cursorSampleNum)
			    {
			    //	System.out.println("Mouse moved to: " +
			    //	   me.getX() + ", " + me.getY() 
			    //	   + " -- data coords=" + result
			    //	   + " sample="+sampleNum
			    //	   + " cursample="+cursorSampleNum);  
                            cursorSampleNum = sampleNum;
                            parentApp.notifyMouseChange(mouseMode,cursorSampleNum);    
                            basePanel.repaint();
			    }
			}
		    break;
	            }
		default:
		    break;
		}
	    }
        
        }  // end of mouse motion adapter class


    protected static String cvsInfo = null;
    protected static void setCvsInfo()
        {
        cvsInfo = "\n@(#)  $Id: EvpBasePanel.java,v 1.4 2007/01/05 07:41:57 rudahl Exp $ \n";
	}
    }  // end of EvpBasePanel class

