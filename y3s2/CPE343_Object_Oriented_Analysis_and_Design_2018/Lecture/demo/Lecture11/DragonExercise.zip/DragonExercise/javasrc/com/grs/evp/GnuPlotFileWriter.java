/**
 *   GnuPlotFileWriter.java
 *   
 *     Created by S.Goldin
 *
 *    $Id: GnuPlotFileWriter.java,v 1.3 2007/01/05 07:41:57 rudahl Exp $
 *
 *    $Log: GnuPlotFileWriter.java,v $
 *    Revision 1.3  2007/01/05 07:41:57  rudahl
 *    added Whatis info
 *
 *    Revision 1.2  2004/03/02 10:39:44  rudahl
 *    convert XML to DOM, and output new data file
 *
 *    Revision 1.1  2004/02/24 12:25:11  rudahl
 *    Developing for Release 1
 *
 *
 */
package com.grs.evp;

import java.io.*;
import java.util.*;
import com.grs.util.XMLDomIO;
import com.grs.util.Smallfile;
import org.jdom.Document;

/**
 * This class knows how to write a GraphDatasource into
 * a file with gnuplot data format plus XML metadata at
 * the end.
 */
public class GnuPlotFileWriter 
    {
    /**
     * Write the contents ofthe datasource to the specified
     * file.
     * @param datasource   Datasource we want to output
     * @param outputFile   File to write the data to
     * @throws             Exception if error in access or writing
     */
    public static void write(GraphDatasource datasource,
			     String outputFile) 
	                     throws Exception, IOException
	                        
	{
	BufferedWriter writer = new BufferedWriter(
						   new FileWriter(outputFile));
	int numChannels = datasource.getChannelCount();
	int sampleCount = datasource.getSampleCount();
	for (int samp = 0; samp < sampleCount; samp++)
	    {
	    for (int ch = 0; ch < numChannels; ch++)
		{
		writer.write(datasource.getChannelData(ch).getValue(samp));
		writer.write("\t");
		}
	    writer.write("\n");
	    }
	outputMetaData(datasource,writer);
	writer.close();
	}

    private static void outputMetaData(GraphDatasource datasource,
				       BufferedWriter writer) 
	                        throws Exception
	{
	GnuPlotGraphDatasource realDS = null;
	Document xmlDocument = null;
	if (datasource instanceof DerivedGraphDatasource)
	    {
	    DerivedGraphDatasource derivedDS = 
		(DerivedGraphDatasource) datasource;
	    xmlDocument = derivedDS.getLocalXmlDocument();
	    // if the derived DS does not have a GNUPLOT parent
	    // then xmlDocument will be null.
	    }
	else if (datasource instanceof GnuPlotGraphDatasource)
	    {
	    realDS = (GnuPlotGraphDatasource) datasource; 
	    xmlDocument = realDS.getXmlDocument();
	    }
	if (xmlDocument != null)
	    {
	    XMLDomIO.writeXMLFile(xmlDocument,"test.xml");
	    }
	Vector v = Smallfile.rsf("test.xml",null);
	int vectSize = v.size();
	for (int j=0; j<vectSize; j++)
	    {
	    String s = (String)v.get(j);
	    writer.write("# "+s+"\n");
	    }
	}

    protected static String cvsInfo = null;
    protected static void setCvsInfo()
        {
        cvsInfo = "\n@(#)  $Id: GnuPlotFileWriter.java,v 1.3 2007/01/05 07:41:57 rudahl Exp $ \n";
	}
    }
