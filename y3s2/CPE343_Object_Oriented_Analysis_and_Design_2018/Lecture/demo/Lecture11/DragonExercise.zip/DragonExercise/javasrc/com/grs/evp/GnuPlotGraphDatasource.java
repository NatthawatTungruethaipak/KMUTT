/**
 *   GnuPlotGraphDatasource.java
 *   
 *     Created by S.Goldin
 *
 *    $Id: GnuPlotGraphDatasource.java,v 1.4 2007/01/05 07:41:57 rudahl Exp $
 *
 *    $Log: GnuPlotGraphDatasource.java,v $
 *    Revision 1.4  2007/01/05 07:41:57  rudahl
 *    added Whatis info
 *
 *    Revision 1.3  2004/03/09 10:20:08  rudahl
 *    Add graphing for interactively selected points
 *
 *    Revision 1.2  2004/03/02 10:39:44  rudahl
 *    convert XML to DOM, and output new data file
 *
 *    Revision 1.1  2004/02/24 12:25:11  rudahl
 *    Developing for Release 1
 *
 *
 */
package com.grs.evp;

import java.util.*;
import java.io.*;
import org.jdom.JDOMException;
import org.jdom.Document;

/**
 *  This class implements the GraphDatasource interface.
 *  It reads and initializes channel data objects from a GnuPlot
 *  input data file. 
 */

public class GnuPlotGraphDatasource implements GraphDatasource
    {
    private ArrayList channels = new ArrayList();	
    private int latestErrorNumber = 0;
    private String latestErrorMessage = null;
    private String sourceDataFileName = null;

    /**
     * Data read from GnuPlot data file meta data section
     */
    private String symbol = null;
    private int firstSample = 0;
    private int sampleCount = 0;

    /**
     * Reference to meta data XML document
     */
    private Document xmlDocument = null;

    /**
     * Initialize the datasource based on the filename.
     * @param filename GnuPlot file to read
     * @return true if successful, false if some error occurred.
     */
    public boolean init(String filename)
	{
	boolean bOk = true;
	sourceDataFileName = filename;
	String inputLine = null;
	StringBuffer metaDataBuffer = new StringBuffer();
	boolean bInMetaData = false;
	try
	    {
	    BufferedReader reader = new BufferedReader(
		new FileReader(filename));
	    int lineNum = -1;
	    while ((inputLine = reader.readLine()) != null)
	        {
		lineNum++;
		String parts[] = inputLine.split("[ \t]+");
		//System.out.println("Line is '" + inputLine + "'\n with " 
		//		   + parts.length + " parts");
		if ((parts.length == 0) 
		     || (inputLine.length() < 3)
		     || (parts[0].startsWith("#")  
		         && ((parts.length > 1) 
			     && !parts[1].startsWith("<?xml"))
		         && !bInMetaData) )
		    {
		    continue;
		    }
		else if (parts[0].startsWith("#"))
		    {
		    bInMetaData = true;
		    metaDataBuffer.append(inputLine.substring(2));
		    metaDataBuffer.append("\n");
		    }
 		else  // processing data values for channels
		    {
		    int i;
		    int colCount = channels.size();
		    if (colCount == 0)
			{
			colCount = parts.length;
			for (i = 0; i < colCount; i++)
			    {
			    addChannel();
			    }
			}
		    if (parts.length < colCount)
			{
			latestErrorMessage = 
			    "Incomplete data line at line number " 
			    + lineNum + ": '"
			    + inputLine + "'";
			latestErrorNumber = -30;
			}

		    else for (i = 0; i < colCount; i++)
		        {
			ChannelData whichChannel = 
			    (ChannelData) channels.get(i);
			whichChannel.addValue(parts[i]);
			}
		    }
	        }
	    reader.close();
	    bOk = processXmlMetaData(metaDataBuffer);
	    }
	catch (FileNotFoundException fnf)
	    {
	    bOk = false;
	    latestErrorMessage = "Can't find or open file " + filename;
	    latestErrorNumber = -3;
	    }
	catch (Exception e)
	    {
	    bOk = false;
	    latestErrorMessage = "Init error: " 
		+  e.getClass().getName()
		+ " " + e.getMessage();
	    latestErrorNumber = -4;
	    }
	return bOk;
	}

    /**
     * Extract meta data about channels from XML fragment at
     * the end of the file.
     * @param dataBuffer  Buffer holding XML contents to parse
     * @return            true if successful. If not successful 
     *                    will set error number and message.
     */
    private boolean processXmlMetaData(StringBuffer dataBuffer)
	{
	boolean bOk = false;
	InputStreamReader isr 
	    = new InputStreamReader(
		new ByteArrayInputStream(dataBuffer.toString().getBytes()));
	EvpXmlProcessor xmlProcessor = new EvpXmlProcessor(this);
	try
	    {
	    xmlProcessor.parse(isr);
	    xmlDocument = xmlProcessor.getXmlDocument();
	    bOk = true;
	    }
	catch (JDOMException je)
	    {
	    latestErrorNumber = -5;
	    latestErrorMessage = "XML Processing Error: " + je.getMessage();
	    }
	catch (IOException ioe)
	    {
	    latestErrorNumber = -6;
	    latestErrorMessage = "IO Error Processing XML: " + ioe.getMessage();
	    }
	catch (Exception e)
	    {
	    latestErrorNumber = -7;
	    latestErrorMessage = "Exception " 
		                 + e.getClass().getName() + " "
		                 + e.getMessage();
	    }
	return bOk;
	}

    /**
     * Return number of channels (data columns) in
     * the data set. 
     * @return number of channels, or -1 if datasource is not initialized
     */
    public int getChannelCount()
	{
	return channels.size();    
	}

    /**
     * Return the ChannelData object at specified index.
     * @param channelIndex   Index we're interested in
     * @return channel object or null if bad index or not initialized
     */
    public ChannelData getChannelData(int channelIndex)
	{
	ChannelData channel = null;
	if ((channelIndex < 0) || (channelIndex >= getChannelCount()))
	    {
	    latestErrorNumber = -2;
	    latestErrorMessage = "Bad channel index";	
	    }
	else
	    {
	    channel =  (ChannelData) channels.get(channelIndex); 
	    }
	return channel;
	}

    /**
     * Add a new channel to the data source.
     * The new channel must be initialized by calling initMetaData
     * as a separate operation.
     */
    public ChannelData addChannel()
	{
	ChannelData channel = new ChannelData();
	channels.add(channel);
	return channel;
	}

    /**
     * Create a control file for running GnuPlot with this
     * data. The control file name will be the same as the 
     * source data file name, on the same path, with the 
     * string .ctl appended to the entire filename (i.e. 
     * we don't remove any suffix from the original filename).
     * @param dataChanNums	indices of Y-axis channels. Index 1 is X-axis,
     *				so these numbers are 2-based.
     * @return 			Name and path of constructed control file, 
     *				or null if some error occurred, 
     *				in which case caller should
     *			        check the latestErrorMessage.
     */
    public String createControlFile(int[ ] dataChanNums)
	{
	String controlFileName = null;
	String plotFileName = null;
	if (sourceDataFileName == null)
	    {
	    latestErrorMessage = "Data source is not yet initialized.";
	    latestErrorNumber = -10;
	    }
	else
	    {
	    controlFileName = getControlFileName();
	    try
		{
		ChannelData tmCh = getChannelData(0);
		BufferedWriter writer 
		   = new BufferedWriter(new FileWriter(controlFileName));
		writer.write("set nokey\n");
		writer.write("set data style line\n");
		writer.write("set terminal png color\n");
		writer.write("set title \"\"\n");
		writer.write("set output \"" + getPlotFileName() + "\"\n");
		writer.write("set lmargin 4\n");
		writer.write("set rmargin 0\n");
		writer.write("set size 1,1\n");

		writer.write("set xdata time\n");
		writer.write("set timefmt \"" + tmCh.getDateFormat() + "\"\n");
		writer.write("set xrange [\"" + tmCh.getMinAxis()
			       + "\":\"" + tmCh.getMaxAxis() + "\"]\n");
		writer.write("set format x \"%m/%d\"\n");
		StringBuffer plot = new StringBuffer();
		plot.append("plot ");
		for (int j=0; j<dataChanNums.length; j++)
		    {
		    ChannelData dataCh = getChannelData(dataChanNums[j] -1);
    //		    System.out.println("j="+j+" dataChan="+dataChanNums[j]
    //		       +" dataCh="+dataCh);
		    if (j == 0)
			writer.write("set yrange ["+dataCh.getMinAxis()
				       +":"+dataCh.getMaxAxis()+"]\n");
		    else
			plot.append(", ");
		    plot.append("'" + sourceDataFileName + "'");
		    plot.append(" using 1:" + dataChanNums[j]);
		    }
		plot.append("\n");
		writer.write(plot.toString());
		writer.close();
		}
	    catch (IOException e)
		{
		latestErrorMessage = "Error creating control file "
		    +controlFileName+"; "+e.getMessage();
		latestErrorNumber = -11;
		controlFileName = null;
		}
	    }
	return controlFileName;
	}

    public String getSourceDataFileName()
	{
	return sourceDataFileName;
	}

    /**
     * Get latest error number (if any)
     * @return negative number of latest error, or 0 if no error
     */
    public int getLatestErrorNumber()
	{
	return latestErrorNumber;
	}

    public void setLatestErrorNumber(int error)
	{
	latestErrorNumber = error;   
	}

    /**
     * Get latest error message (if any)
     * @return error message associated with latest error, or null if no error
     */
    public String getLatestErrorMessage()
	{
	return latestErrorMessage;
	}

    public void setLatestErrorMessage(String message)
	{
	latestErrorMessage = message;
	}

    public void setSymbol(String symbol)
	{
	this.symbol = symbol;
	}

    public String getSymbol()
	{
	return symbol;
	}

    public void setFirstSample(int first)
	{
	firstSample = first;
	}

    public int getFirstSample()
	{
	return firstSample;
	}

    public void setSampleCount(int count)
	{
	sampleCount = count;
	}

    public int getSampleCount()
	{
	return sampleCount;
	}

    public String getControlFileName()
	{
	return (sourceDataFileName == null) ? null 
	    : sourceDataFileName + ".ctl";
	}

    public String getPlotFileName()
	{
	return (sourceDataFileName == null) ? null 
	    : sourceDataFileName + ".png";
	}

    public Document getXmlDocument()
        {
	return xmlDocument;
        }

    public static void main(String args[])
	{
	int i;
	GnuPlotGraphDatasource ds = new GnuPlotGraphDatasource();
	ds.init(args[0]);
	int num = ds.getLatestErrorNumber();
	if (num != 0)
	    {
	    System.out.println("Error: " + ds.getLatestErrorMessage());
	    }
	System.out.println("In the datasource there are " 
			   + ds.getChannelCount() 
			   + " channels");
	int[] dataChannelNums = { 2 };
	/*
	String controlFile = ds.createControlFile(dataChannelNums);
	if (controlFile == null)
	    {
	    System.out.println("Error: "+ds.getLatestErrorMessage());
	    }
	else
	    System.out.println("Control file = '"+controlFile+"'");
	*/
	int colIndex = 0;
	for (colIndex = 0; colIndex < ds.getChannelCount(); colIndex++)
	    {
	    ChannelData channel = ds.getChannelData(colIndex);
	    if (channel == null)
	        {
		num = ds.getLatestErrorNumber();
		if (num != 0)
	            {
		    System.out.println("Error: " + ds.getLatestErrorMessage());
		    }
		}
	    else
	        {
		System.out.println("Channel " + colIndex + " name is " 
				   + channel.getName());
		System.out.println("   dataType is " + channel.getDataType());
		System.out.println("   format is " + channel.getDateFormat());
		System.out.println("   min axis is " + channel.getMinAxis());
		System.out.println("   max axis is " + channel.getMaxAxis());
		System.out.println("   min value is " + channel.getMinVal());
		System.out.println("   max value is " + channel.getMaxVal());
		try
		    {
		    if (channel.getDataType() == ChannelData.FLOAT)
	                {
			double values[] = channel.getNumericValues();
			for (i = 0; i < values.length; i++)
			    {
			    System.out.println("Value " + i + "=" + values[i]);
			    }
			}
		    else if (channel.getDataType() == ChannelData.DATE)
	                {
			for (i = 0; i < channel.getCount(); i++)
		            {
			    System.out.println("Value " + i + " = "
					       + channel.getValue(i));
			    }
			}
		    }
		catch (Exception e)
		    {
		    System.out.println("Exception thrown: " + e.getMessage());
		    }
		}
	    }
	}

    protected static String cvsInfo = null;
    protected static void setCvsInfo()
        {
        cvsInfo = "\n@(#)  $Id: GnuPlotGraphDatasource.java,v 1.4 2007/01/05 07:41:57 rudahl Exp $ \n";
	}
    }
