/**
 * Legend.java
 *
 *  Copyright 2008 by Sally Goldin & Kurt Rudahl
 *
 *  Created by Sally Goldin, 1/4/2008
 *
 *  $Id: Legend.java,v 1.9 2008/07/11 08:25:12 goldin Exp $
 *  $Log: Legend.java,v $
 *  Revision 1.9  2008/07/11 08:25:12  goldin
 *  Bug fixes
 *
 *  Revision 1.8  2008/06/14 10:37:53  goldin
 *  Modify the wedge to draw more quickly
 *
 *  Revision 1.7  2008/06/13 10:28:37  goldin
 *  Fix bug in fontname parsing
 *
 *  Revision 1.6  2008/06/12 05:52:53  goldin
 *  put limit on wedge, remove vertical control from UI
 *
 *  Revision 1.5  2008/06/08 12:11:04  rudahl
 *  working on Legend
 *
 *  Revision 1.4  2008/06/07 07:11:48  rudahl
 *  improve tracing, legend
 *
 *  Revision 1.3  2008/03/01 12:28:17  goldin
 *  Further work on the Legend and Wedge
 *
 *  Revision 1.2  2008/01/11 11:51:53  goldin
 *  Continued work on the legend
 *
 *  Revision 1.1  2008/01/04 11:48:09  goldin
 *  Begin work on Java based legend
 *
 *
 */
package com.grs.dragon.viewport;

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import com.grs.gui.*;
import com.grs.metricCanvas.*;
//import com.grs.dragon.viewport.viewProg;

/**
 * This class implements a frameless window that can
 * show a legend or a color wedge. If the wedge view
 * is chosen, the wedge can be either horizontally or vertically 
 * oriented.  This class will be instantiated from the viewport,
 * but there is nothing VP-specific in it at the moment.
 */
public class Legend extends JWindow implements MouseMotionListener
{
    protected final static String DFLT_FACE = "Lucida Sans Unicode";
    protected final static int DFLT_STYLE = Font.PLAIN;
    protected final static int DFLT_SIZE =14;

    /* Text source for any messages */
    protected I18NTextSource textSource = null;

    /* Name of color file */
    protected String clfFileName = null;

    /* Color file processor for managing colors */
    protected ColorFileProcessor clfProcessor =  null;

    /* values index */
    protected Hashtable<String,Integer> labelToValueMap = null;

    /* number of values to be displayed. */
    protected int m_valueCount = 256;

    /* wedge ? */
    protected boolean m_bIsWedge = false;

    /* Array of ColorGridCanvas cells corresponding to
     * different labels/values 
     */
    protected ColorGridCanvas gridCells[] = null; 

    /* Array of labels 
     */
    protected JLabel m_labelObjects[] = null;

    /* copy of label strings array */
    protected String m_legendLabels[] = null;

    /* Font to use for labels */
    protected Font m_labelFont = null;

    /**
     * Constructor builds a legend but does not display
     * it.
     * @param  bIsWedge  If true, this is a wedge.
     * @param  bVertical If true, vertical, else horizontal.
     *                   Ignored if bIsWedge is false.
     * @param  colorFileName  Name of the color file currently in
     *                   use.
     * @param  valuesIndex Array of index values to display
     *                   The number of items in this array will
     *                   determine the number of boxes in the legend.
     *                   Not used for the wedge.
     * @param  labels    Array of labels corresponding to the values
     * @param  fontName  Name of font to use
     * @param  minVal    Minimum value in the image - not used right now
     * @param  maxVal    Maximum value in the image - used for Wedge only
     *  
     */
public Legend(boolean bIsWedge, boolean bVertical, String colorFileName,
		  int valuesIndex[], String labels[], String fontName,
	          int minVal, int maxVal)
    {
    super();
    String family = DFLT_FACE;
    int style = DFLT_STYLE;
    int size = DFLT_SIZE; 
    clfFileName = colorFileName;
    viewProg.logViewport("Legend::ctor (en) ");
    clfProcessor = new ColorFileProcessor(clfFileName);
    labelToValueMap = new Hashtable<String,Integer>();
    m_bIsWedge = bIsWedge;
    m_legendLabels = labels;
    if (!bIsWedge)
	{
	m_valueCount = valuesIndex.length;  
	for (int i = 0; i < m_valueCount; i++)
	    {
	    labelToValueMap.put(labels[i],new Integer(valuesIndex[i]));
            } 
    //    addMouseMotionListener(this);
	if ((fontName != null) && (fontName.length() > 0))
	    {
	    String token1, token2, token3, sizeToken;
	    StringTokenizer tokenizer = new StringTokenizer(fontName,"-");
	    token1 = tokenizer.nextToken();
	    if (token1 != null)
		family = token1;
	    token2 = tokenizer.nextToken();
	    token3 = tokenizer.nextToken();
	    if (token2.compareTo(token3) == 0)
		{
		sizeToken = token2;
                style = Font.PLAIN;
		}
	    else
		{
		sizeToken = token3;
		if (token2.compareTo("I") == 0)
		    style = Font.ITALIC;
		else if (token2.compareTo("B") == 0)
		    style = Font.BOLD;
		else
		    style = Font.BOLD + Font.ITALIC;
		}
	    try
		{
		size = Integer.parseInt(sizeToken);
		}
	    catch (NumberFormatException nfe)
		{
		}
	    }
    //viewProg.logViewport("Family is " + family + " size is " + size +
    //		  " style is " + style);
    //System.out.println("Family is " + family + " size is " + size +
    //                   " style is " + style);
	m_labelFont = new Font(family, style, size);
	}
    else 
        {
	if (maxVal == 0)
            {
	    m_valueCount = 256; // This will change if we ever have
                                // the ability to have more than 256 colors in a file 
	    }
        else if (maxVal < 17)
            {
	    m_valueCount = 17;
            }
	else
	    {
	    m_valueCount = 256;
	    }
	}
    try 
        {
        buildUI(bIsWedge,bVertical,labels);
	}
    catch (Exception ex)
        {
	viewProg.logViewport("Exception trying to build UI: " + ex.getMessage());
        }

    viewProg.logViewport("Legend::ctor (ex)");
    }

    /**
     * Factorization, creates the visible legend structure.
     * @param bIsWedge  If true this is a wedge.
     * @param bVertical If wedge and true, make it vertical 
     *                  Normal legend is always vertical.
     * @param labels    Array of strings to use as labels
     */
protected void buildUI(boolean bIsWedge, boolean bVertical,
		       String labels[])
    {
    int width;
    int height;
    int hgutter;
    int vgutter;
    int rows = 1;
    int cols = 1;
    int sliceSize = 2;
    JPanel legendPanel = new JPanel(new BorderLayout()); 
    legendPanel.setBorder(new BevelBorder(BevelBorder.RAISED));
    legendPanel.setBackground(Color.WHITE);
    JPanel innerPanel;
    if (bIsWedge)
	{
	if (m_valueCount < 256)
	    sliceSize = 30;
        if (bVertical)
	    {
	    width = 30;
	    height = sliceSize;
	    hgutter = 0;
	    vgutter = 0;
	    rows = m_valueCount;
	    innerPanel = new JPanel(new GridLayout(0,1));
	    }
	else
	    {
	    width = sliceSize;
	    height = 30;
	    hgutter = 0;
	    vgutter = 0;
	    cols = m_valueCount;
	    innerPanel = new JPanel(new GridLayout(1,0));
	    }
	}
    else
	{
	width = 20;
	height = 20;
	hgutter = 2;
	vgutter = 2;
	innerPanel = new JPanel(new GridLayout(0,1));
	m_labelObjects = new JLabel[m_valueCount];
	}
    innerPanel.setBorder(new EmptyBorder(5,5,5,5)); 
    innerPanel.setBackground(Color.WHITE);
    if (bIsWedge)
        {
	gridCells = new ColorGridCanvas[1]; 
	ColorGridCanvas cg = new ColorGridCanvas(rows,cols,width,height,
						 hgutter,vgutter);
	gridCells[0] = cg;
        innerPanel.add(cg);
        } 
    else 
        { 
        gridCells = new ColorGridCanvas[m_valueCount];
        for (int i = 0; i < m_valueCount; i++)
	   {
	   JPanel rowPanel = new JPanel(new BorderLayout());
	   rowPanel.setBackground(Color.WHITE);
	   ColorGridCanvas cg = new ColorGridCanvas(1,1,width,height,
						 hgutter,vgutter);
        
	   gridCells[i] = cg;
	   rowPanel.add(cg,BorderLayout.WEST);
	   JLabel newLabel = new JLabel(labels[i]);
	   m_labelObjects[i] = newLabel;   
	   newLabel.setHorizontalAlignment(SwingConstants.LEFT);
	   newLabel.setFont(m_labelFont);
	   newLabel.setBackground(Color.WHITE);
	   JPanel lPanel = new JPanel(new BorderLayout());
	   lPanel.setBackground(Color.WHITE);
	   lPanel.setBorder(new EmptyBorder(2,6,2,2));
	   lPanel.add(newLabel,BorderLayout.WEST); 
	   rowPanel.add(lPanel,BorderLayout.CENTER);
	   innerPanel.add(rowPanel);
	   }
	}
    legendPanel.add(innerPanel,BorderLayout.CENTER);
    this.getContentPane().add(legendPanel);
    pack();
    }
 
public void showLegend()
    {
    viewProg.logViewport("Legend::showLegend (en)");
    this.setColors();
    this.setVisible(true);
    //viewProg.logViewport("Legend::showLegend 1");
    HashMap<RenderingHints.Key,Object> renderMap 
                    = new HashMap<RenderingHints.Key,Object>();
    renderMap.put(RenderingHints.KEY_ANTIALIASING,
		  RenderingHints.VALUE_ANTIALIAS_ON);
    renderMap.put(RenderingHints.KEY_TEXT_ANTIALIASING,
		  RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
    renderMap.put(RenderingHints.KEY_RENDERING,
		  RenderingHints.VALUE_RENDER_QUALITY);
    renderMap.put(RenderingHints.KEY_FRACTIONALMETRICS,
		  RenderingHints.VALUE_FRACTIONALMETRICS_ON);
    //viewProg.logViewport("Legend::showLegend 2");
    if ((! m_bIsWedge) && (m_labelObjects != null))
	{
	for (int i = 0; i < m_valueCount; i++)
	    {
	    Graphics2D g = (Graphics2D) m_labelObjects[i].getGraphics();
	    g.setRenderingHints(new RenderingHints(renderMap));
	    }
        }
    repaint();
    viewProg.logViewport("Legend::showLegend (ex)");
    }

public void hideLegend()
    {
    setVisible(false);
    }   

   /**
    * Set or reset the colors associated with the legend.
    * This assumes that clfProcessor has been initialized
    * with the appropriate colors 
    */
public void setColors()
    {
    Color colorArray[] = clfProcessor.getRemappedColors(); 
    if (m_bIsWedge)
        {
	gridCells[0].setGridColors(colorArray);
        }
    else
        {
	for (int i = 0; i < m_valueCount; i++)
	   {
           int val = 0;
           if (m_bIsWedge)
	       {
	       val = i;
	       }
	    else
	       {
	       String label = m_legendLabels[i];
	       Integer value = labelToValueMap.get(label);
	       val = value.intValue();
	       }
	   gridCells[i].setOneColor(0,colorArray[val]);
	   gridCells[i].replotColors();
	   gridCells[i].repaint();
	   }
	}
    } 

    /**
     * Explicitly position the legend at a particular X,Y
     * spot on the screen. 
     * @param x  X coordinate of new position 
     * @param y  Y coordinate of new position
     */ 
public void setPosition(int x, int y)
    {
    this.setLocation(x,y);
    }

    /**
     * Change the color file used to display the legend.
     * Does not redraw the legend; use setColors for this.
     */  
public void setColorFileName(String colorFileName)
     {
     clfProcessor.init(colorFileName);
     }

    /**
     * Mouse Listener methods 
     */
    public void mouseDragged(MouseEvent e)
        {
	Point current = this.getLocationOnScreen();
	Point p = e.getPoint();
        this.setLocation(current.x + p.x, current.y + p.y);
        }

    public void mouseMoved(MouseEvent e)
        {
        }

    /**
     * Explicitly get rid of the legend so that it can be
     * recreated with new parameters.
     */  
public static void destroyLegend(Legend oldLegend)
     { 
     oldLegend.dispose();
     }

    /**
     * Test function
     */
public static void main(String args[])
    {
    int vals[] = {0,5,10,80, 150,170,240};
    String labels[] = {"AAA","BBB","Ccc","D _DDDD", "Eeeeeeeee", 
                       "Fff", "G-------g"}; 
    if (args.length < 1)
	{
	System.out.println("Usage: java legend <colorfile> [newclf x y]");
	System.exit(0);
        }
    /* first argument is color file */
    String colorFile = args[0];
    System.out.println("color file is " + colorFile);
   
    Legend lg = new Legend(false,false, colorFile, vals, labels,
                           "Desdemona--I--24--24",0,0);
    lg.setColors();
    lg.setVisible(true);

    if (args.length >= 2)
	{
	String newColorFile = args[1];
        System.out.println("about to set new color file - in 10 seconds");
        try {
            Thread.sleep(10000);
	    }
	catch (InterruptedException ie) 
            {
	    System.out.println("Interrupted");
	    }
        lg.setColorFileName(newColorFile);
        lg.setColors();
        }

    if (args.length == 4)
        {
        try
	    {
	    int x = Integer.parseInt(args[2]);
	    int y = Integer.parseInt(args[3]);
	    lg.setPosition(x,y);
	    }
	catch (NumberFormatException nfe)
	    {
	    System.out.println("X or Y coordinates are invalid integers");
	    }
        }

    System.out.println("about to destroy the legend - in 10 seconds");
    try {
	Thread.sleep(10000);
        }
    catch (InterruptedException ie) 
	{
	System.out.println("Interrupted");
	}
    Legend.destroyLegend(lg);

    System.out.println("About to create wedge");
    Legend wedge = new Legend(true,true, colorFile, null, null,null,0,255);
    wedge.setPosition(500,350);
    wedge.showLegend();

    if (args.length >= 2)
	{
	String newColorFile = args[1];
        System.out.println("about to set new color file - in 10 seconds");
        try {
            Thread.sleep(10000);
	    }
	catch (InterruptedException ie) 
            {
	    System.out.println("Interrupted");
	    }
        wedge.setColorFileName(newColorFile);
        wedge.setColors();
        }

    System.out.println("about to destroy the wedge - in 10 seconds");
    try {
	Thread.sleep(10000);
        }
    catch (InterruptedException ie) 
	{
	System.out.println("Interrupted");
	}
    Legend.destroyLegend(wedge);
    }

    protected static String cvsInfo = null;
    protected static void setCvsInfo()
        {
        cvsInfo = "\n@(#)  $Id: Legend.java,v 1.9 2008/07/11 08:25:12 goldin Exp $ \n";
	}

}
