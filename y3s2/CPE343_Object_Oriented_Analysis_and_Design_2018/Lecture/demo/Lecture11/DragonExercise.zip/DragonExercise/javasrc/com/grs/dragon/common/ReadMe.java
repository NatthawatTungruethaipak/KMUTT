/* ReadMe.java
 *
 *    ~~ Copyright 2010 Kurt Rudahl and Sally Goldin
 *
 *	All rights are reserved. Copying or other reproduction of
 *	this program except for archival purposes is prohibited
 *	without the prior written consent of Goldin-Rudahl Associates.
 *
 *			  RESTRICTED RIGHTS LEGEND
 *
 *	Use, duplication, or disclosure by the U.S. Government
 *	is subject to restrictions as set forth in
 *	paragraph (b) (3) (B) of the Rights in Technical
 *	Data and Computer Software clause in DAR 7-104.9(a).
 *
 *	The moral right of the copyright holder is hereby asserted
 *   ~~ EndC
 *
 * $Id: ReadMe.java,v 1.2 2013/01/03 13:53:04 rudahl Exp $
 * $Log: ReadMe.java,v $
 * Revision 1.2  2013/01/03 13:53:04  rudahl
 * build linux kit
 *
 * Revision 1.1  2010/12/06 11:12:29  goldin
 * Factor readme display code out of installer and put here
 *
 *
 */
package com.grs.dragon.common;
import java.io.*;

/**
 * This class runs in a separate thread. It invokes a copy of the
 * registered web browser with the README file loaded.
 * It is used by both the installer and the main UI.
 * Refactored out of Installer.java on 5 Dec 2010 by SEG.
 */
public class ReadMe extends Thread
    {

    private String homeDirectory = null;

   /**
    * Constructor sets the value of homedirectory,
    * which is the location of the readme file.   
    */
    public ReadMe(String directory)
	{
	homeDirectory = directory;
	}
       
   /**
    * Main thread method invokes the registered browser
    */
    public void run() 
        {
	boolean bError = false;
	String readmeFile = homeDirectory + File.separator + "readme.html";
	StringBuffer cmd = new StringBuffer(512);
        String OS = System.getProperty("os.name");
	String shellCmd;
	if (OS.toUpperCase().indexOf("WIN") >= 0)
	    {
	    shellCmd = System.getProperty("SHELL","cmd");
	    cmd.append(shellCmd + " /c " + readmeFile);
	    }
	else
	    shellCmd = System.getProperty("SHELL","sh");
	try {
	    Process proc = 
		Runtime.getRuntime().exec(cmd.toString());
	    }
	catch (IOException ioe)
	    {
	    System.out.println(ioe.getMessage());
	    }
	}         // end run

    protected static String cvsInfo = null;
    protected static void setCvsInfo()
        {
        cvsInfo = "\n@(#)  $Id: ReadMe.java,v 1.2 2013/01/03 13:53:04 rudahl Exp $ \n";
	}

    }  // end ReadMe class
