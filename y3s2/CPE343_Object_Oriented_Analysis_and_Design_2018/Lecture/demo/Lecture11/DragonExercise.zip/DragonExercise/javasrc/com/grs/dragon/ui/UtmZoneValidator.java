/* UtmZoneValidator.java
 *
 *    ~~ Copyright 2011 Kurt Rudahl and Sally Goldin
 *
 *	All rights are reserved. Copying or other reproduction of
 *	this program except for archival purposes is prohibited
 *	without the prior written consent of Goldin-Rudahl Associates.
 *
 *			  RESTRICTED RIGHTS LEGEND
 *
 *	Use, duplication, or disclosure by the U.S. Government
 *	is subject to restrictions as set forth in
 *	paragraph (b) (3) (B) of the Rights in Technical
 *	Data and Computer Software clause in DAR 7-104.9(a).
 *
 *	The moral right of the copyright holder is hereby asserted
 *   ~~ EndC
 *
 *
 * Created by Sally Goldin, 16 January 2011
 *
 *  $Id: UtmZoneValidator.java,v 1.2 2011/01/16 14:12:49 goldin Exp $
 *  $Log: UtmZoneValidator.java,v $
 *  Revision 1.2  2011/01/16 14:12:49  goldin
 *  add new fields for HEA
 *
 *  Revision 1.1  2011/01/16 09:31:35  goldin
 *  updates to add new fields to HEA
 *
 *
 */

package com.grs.dragon.ui;
import javax.swing.*;
import java.awt.*;
import com.grs.gui.*;

/** 
 * This class provides validation for UTM zones which must have
 * the form 'ddN' or 'ddS', where 'dd' is a number between 1 and 60 inclusive.
 */
public class UtmZoneValidator implements Validator 
    {
    protected String lastErrorKey = null;
    protected String extraInfo = null;

     /**
      * Method to validate the value in the field.
      * Blank is okay.
      * @param field   DragonField object used to get values
      * @return true if valid, false if not.
      */
    public boolean isValid(DragonField field)
	{
	boolean bValid = true;
	String value = null;
	value = field.getFieldValue();
	if (value.length() > 0)
	    {
	    value = value.toUpperCase().trim();
	    String hemisphere = value.substring(value.length()-1);
	    String number = value.substring(0,value.length()-1);
	    if ((value.length() > 3) || (value.length() < 2))
		{
		bValid = false;
		}
	    else if ((hemisphere.compareTo("N") != 0) &&
		(hemisphere.compareTo("S") != 0))
		{
		bValid = false;    
		} 
	    else
		{
		try
  	           {
		   int intValue = Integer.parseInt(number);
		   if ((intValue < 1) || (intValue > 60))
		       {
		       bValid = false;
		       }
		   }
		catch (NumberFormatException nfe)
		   {
		   bValid = false;
		   }
		}
	    if (!bValid)
		{
		lastErrorKey = "%q3200.14.5";
		}
	    }
        return bValid;
        } 

      /**
       * Asks the validator to display an error box showing
       * information on the last error.
       */
    public void displayLastError()
        {
        if (lastErrorKey == null)  // no error
	    return;
	Toolkit.getDefaultToolkit().beep();
	ErrorDisplay errDisplay = 
	    ApplicationManager.getErrorDisplay();
	extraInfo = "";
	errDisplay.showError(TextKeys.ERROR, lastErrorKey, extraInfo);
	lastErrorKey = null;
	}

      /**
       * Return true if there is an unreported error.
       */
    public boolean isErrorOutstanding()
        {
	return (lastErrorKey != null);
	}


    protected static String cvsInfo = null;
    protected static void setCvsInfo()
        {
        cvsInfo = "\n@(#)  $Id: UtmZoneValidator.java,v 1.2 2011/01/16 14:12:49 goldin Exp $ \n";
	}
    }

// End of UtmZoneValidator.java

