export CLASSPATH=/home/goldin/KMUTT/CPE372/web/demos/Lecture11/DragonExercise/javasrc:/home/goldin/KMUTT/CPE372/web/demos/Lecture11/DragonExercise/xml4j_1_1_9.jar


